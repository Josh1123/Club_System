﻿Public Class frmMainMenu

    Private Sub NewStudentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewStudentToolStripMenuItem.Click
        frmNewStudent.Show()                    'Displays new student form
    End Sub

    Private Sub ListStudentToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ListStudentToolStripMenuItem.Click
        frmListStudent.Show()                   'Dispalys list student from
    End Sub

    Private Sub UpdateAndDeleteStudentsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UpdateAndDeleteStudentsToolStripMenuItem.Click
        frmDeletedStudents.Show()               'Displays deleted student form
    End Sub

    Private Sub NewLicenceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewLicenceToolStripMenuItem.Click
        frmNewLicence.Show()                    'Displays new licence form
    End Sub

    Private Sub ViewLicenceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewLicenceToolStripMenuItem.Click
        frmListLicence.Show()                   'Displays list licence form
    End Sub


    Private Sub NewLocationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewLocationToolStripMenuItem.Click
        frmNewLocation.Show()                   'Displays New location form
    End Sub

    Private Sub EditAndDeleteLocationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditAndDeleteLocationToolStripMenuItem.Click
        frmUpdateLocation.Show()                'Displays Update Location form
    End Sub

    Private Sub NewLessonToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewLessonToolStripMenuItem.Click
        frmNewLesson.Show()                     'Display New Lesson form
    End Sub

    Private Sub UpdateAndDeleteLessonToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UpdateAndDeleteLessonToolStripMenuItem.Click
        frmUpdateLesson.Show()                  'Display Update Lesson form
    End Sub


    Private Sub ViewAttendanceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ViewAttendanceToolStripMenuItem.Click
        frmLocationAttendance.Show()            'Display Location Attendance form
    End Sub

    Private Sub AttendLessonToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AttendLessonToolStripMenuItem.Click
        frmAttendLesson.Show()                  'Displays Attend Lesson Form
    End Sub

    Private Sub frmMainMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim StudentRecord As StudentType                    'Declares a vraiable to store the record structure for my students
        Dim LicenceRecord As LicenceType                    'Declares a variable to store the record structure for my licences
        Dim LicenceRecordPosition As Integer                'Declares a variable to store and calculate the position that a licene is located
        Dim RecordPosition As Integer                          'Declares a variable to store and calculate my student record position
        Dim TempLicenceRecordPosition As Integer            'Declares a variable to store the licences in a temporary location
        Dim LastLicencePosition As Integer                  'Declares a variable to find the most recent licence belonging to a student
        Dim LicenceFound As Boolean                         'Declares a variable to find a Licence
        Dim ColsFormat As String = "{0,-15} {1,-20} {2,-20} {3,-30} {4,-30} {5,-20} {6,-20} {7,-10}" 'Declares a varable to store the lcation of my headings to be displayed
        LicenceRecordPosition = 0                           'Set Licence record position as 0
        LicenceFound = False                                'Sets licence found to false
        TempLicenceRecordPosition = 0                       'Sets Temp Licence position to 0
        RecordPosition = 0                                  'Sets record poition to 0
        lstExpiredLicences.Items.Clear()                       'Clears the list box
        lstExpiredLicences.Items.Add(String.Format(ColsFormat, "Student ID", "Licence ID", "First Name", "Last Name", "Address", "Post Code", "Home Number", "Mobile Number"))     'Adds headings to list box
        FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord))  'Opens Student File
        Do While Not EOF(1)                                 'Repeats until the end of the student file
            RecordPosition = RecordPosition + 1             'Adds 1 to record position
            FileGet(1, StudentRecord, RecordPosition)       'Reads student record from student file at record position
            FileOpen(2, "Licence.dat", OpenMode.Random, , , Len(LicenceRecord)) 'Opens licence file
            Do While Not EOF(2) And Not LicenceFound                            'Repeats until lience found or end of licence file
                LicenceRecordPosition = LicenceRecordPosition + 1               'Adds 1 to licence record position
                FileGet(2, LicenceRecord, LicenceRecordPosition)                'Reads licence record as licene position from licence file
                If LicenceRecord.StudentID = StudentRecord.StudentID Then       'If student Ids match
                    LicenceFound = True                                         'Lience has been found
                End If
            Loop                                                                'Ends loop
            FileClose(2)                                                        'Closes licence file
            If LicenceFound Then                                                'If licence has been found
                LicenceRecordPosition = 0                                       'Sets licence position to 0
                FileOpen(2, "Licence.dat", OpenMode.Random, , , Len(LicenceRecord)) 'Opens licence file
                Do While Not EOF(2)                                             'Loops through Lience file
                    LicenceRecordPosition = LicenceRecordPosition + 1           'Adds 1 to Licence position
                    FileGet(2, LicenceRecord, LicenceRecordPosition)            'Reads licence record from licence file at licence position
                    If LicenceRecord.StudentID = StudentRecord.StudentID Then   'If Student Ids match
                        FileOpen(3, "TempLicence.dat", OpenMode.Random, , , Len(LicenceRecord)) 'Open Temp File
                        TempLicenceRecordPosition = TempLicenceRecordPosition + 1               'Adds 1 to temp position
                        FilePut(3, LicenceRecord, TempLicenceRecordPosition)                    'Puts licence record in temp file at temp position
                        FileClose(3)                                                            'Closes temp file
                    End If
                Loop
                FileClose(2)                                                                'Closes lience file
                FileOpen(3, "TempLicence.dat", OpenMode.Random, , , Len(LicenceRecord))     'Opens temp file
                LastLicencePosition = LOF(3) / Len(LicenceRecord)                           'Calculates end of temp file
                FileGet(3, LicenceRecord, LastLicencePosition)                              'Gets last reord in temp file
                FileClose(3)                                                                'Closes temp file

                If StudentRecord.Deleted = False Then                                       'If student not deleted
                    If LicenceRecord.DateExpired < Today Then                               'If Date from licence Record
                        With StudentRecord                                                  'Saves having to type StudentRecord.etc
                            lstExpiredLicences.Items.Add(String.Format(ColsFormat, .StudentID, LicenceRecord.LicenceID, .FirstName, .LastName, .Address, .PostCode, .HomeNumber, .MobileNumber)) 'Adds record to list box
                        End With
                    End If
                End If
            End If
            LicenceRecordPosition = 0                                                       'Sets Lience Position to 0
            LicenceFound = False                                                            'Sets lience found to false
        Loop
        FileClose(1)                                                                        'Closes student file
        Kill("TempLicence.dat")
    End Sub

    Private Sub lstExpiredLicences_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstExpiredLicences.SelectedIndexChanged
        frmNewLicence.Show()                                                                'Displays New Licence form
    End Sub
End Class
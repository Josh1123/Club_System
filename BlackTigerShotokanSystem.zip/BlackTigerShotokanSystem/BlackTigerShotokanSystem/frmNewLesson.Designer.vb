﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNewLesson
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmbLocationID = New System.Windows.Forms.ComboBox()
        Me.lblLocationID = New System.Windows.Forms.Label()
        Me.lblSession2 = New System.Windows.Forms.Label()
        Me.lblSession1 = New System.Windows.Forms.Label()
        Me.lblTimeFinish2 = New System.Windows.Forms.Label()
        Me.lblTimeFinish1 = New System.Windows.Forms.Label()
        Me.lblTimeStart2 = New System.Windows.Forms.Label()
        Me.lblTimeStart1 = New System.Windows.Forms.Label()
        Me.grpLessonDetails = New System.Windows.Forms.GroupBox()
        Me.txtSession1 = New System.Windows.Forms.TextBox()
        Me.txtSession2 = New System.Windows.Forms.TextBox()
        Me.txtTimeFinish2 = New System.Windows.Forms.TextBox()
        Me.txtTimeFinish1 = New System.Windows.Forms.TextBox()
        Me.txtTimeStart1 = New System.Windows.Forms.TextBox()
        Me.txtTimeStart2 = New System.Windows.Forms.TextBox()
        Me.btnSaveLesson = New System.Windows.Forms.Button()
        Me.grpLessonDetails.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmbLocationID
        '
        Me.cmbLocationID.BackColor = System.Drawing.Color.Gainsboro
        Me.cmbLocationID.FormattingEnabled = True
        Me.cmbLocationID.Location = New System.Drawing.Point(88, 30)
        Me.cmbLocationID.Name = "cmbLocationID"
        Me.cmbLocationID.Size = New System.Drawing.Size(121, 21)
        Me.cmbLocationID.TabIndex = 0
        '
        'lblLocationID
        '
        Me.lblLocationID.AutoSize = True
        Me.lblLocationID.Location = New System.Drawing.Point(18, 33)
        Me.lblLocationID.Name = "lblLocationID"
        Me.lblLocationID.Size = New System.Drawing.Size(62, 13)
        Me.lblLocationID.TabIndex = 1
        Me.lblLocationID.Text = "Location ID"
        '
        'lblSession2
        '
        Me.lblSession2.AutoSize = True
        Me.lblSession2.Location = New System.Drawing.Point(6, 72)
        Me.lblSession2.Name = "lblSession2"
        Me.lblSession2.Size = New System.Drawing.Size(53, 13)
        Me.lblSession2.TabIndex = 2
        Me.lblSession2.Text = "Session 2"
        '
        'lblSession1
        '
        Me.lblSession1.AutoSize = True
        Me.lblSession1.Location = New System.Drawing.Point(6, 21)
        Me.lblSession1.Name = "lblSession1"
        Me.lblSession1.Size = New System.Drawing.Size(53, 13)
        Me.lblSession1.TabIndex = 3
        Me.lblSession1.Text = "Session 1"
        '
        'lblTimeFinish2
        '
        Me.lblTimeFinish2.AutoSize = True
        Me.lblTimeFinish2.Location = New System.Drawing.Point(362, 72)
        Me.lblTimeFinish2.Name = "lblTimeFinish2"
        Me.lblTimeFinish2.Size = New System.Drawing.Size(69, 13)
        Me.lblTimeFinish2.TabIndex = 4
        Me.lblTimeFinish2.Text = "Time Finish 2"
        '
        'lblTimeFinish1
        '
        Me.lblTimeFinish1.AutoSize = True
        Me.lblTimeFinish1.Location = New System.Drawing.Point(362, 21)
        Me.lblTimeFinish1.Name = "lblTimeFinish1"
        Me.lblTimeFinish1.Size = New System.Drawing.Size(69, 13)
        Me.lblTimeFinish1.TabIndex = 5
        Me.lblTimeFinish1.Text = "Time Finish 1"
        '
        'lblTimeStart2
        '
        Me.lblTimeStart2.AutoSize = True
        Me.lblTimeStart2.Location = New System.Drawing.Point(172, 72)
        Me.lblTimeStart2.Name = "lblTimeStart2"
        Me.lblTimeStart2.Size = New System.Drawing.Size(64, 13)
        Me.lblTimeStart2.TabIndex = 6
        Me.lblTimeStart2.Text = "Time Start 2"
        '
        'lblTimeStart1
        '
        Me.lblTimeStart1.AutoSize = True
        Me.lblTimeStart1.Location = New System.Drawing.Point(172, 21)
        Me.lblTimeStart1.Name = "lblTimeStart1"
        Me.lblTimeStart1.Size = New System.Drawing.Size(64, 13)
        Me.lblTimeStart1.TabIndex = 7
        Me.lblTimeStart1.Text = "Time Start 1"
        '
        'grpLessonDetails
        '
        Me.grpLessonDetails.Controls.Add(Me.txtSession1)
        Me.grpLessonDetails.Controls.Add(Me.lblTimeStart1)
        Me.grpLessonDetails.Controls.Add(Me.txtSession2)
        Me.grpLessonDetails.Controls.Add(Me.lblTimeFinish1)
        Me.grpLessonDetails.Controls.Add(Me.txtTimeFinish2)
        Me.grpLessonDetails.Controls.Add(Me.lblTimeFinish2)
        Me.grpLessonDetails.Controls.Add(Me.lblTimeStart2)
        Me.grpLessonDetails.Controls.Add(Me.txtTimeFinish1)
        Me.grpLessonDetails.Controls.Add(Me.lblSession1)
        Me.grpLessonDetails.Controls.Add(Me.txtTimeStart1)
        Me.grpLessonDetails.Controls.Add(Me.txtTimeStart2)
        Me.grpLessonDetails.Controls.Add(Me.lblSession2)
        Me.grpLessonDetails.Location = New System.Drawing.Point(12, 72)
        Me.grpLessonDetails.Name = "grpLessonDetails"
        Me.grpLessonDetails.Size = New System.Drawing.Size(543, 106)
        Me.grpLessonDetails.TabIndex = 8
        Me.grpLessonDetails.TabStop = False
        Me.grpLessonDetails.Text = "Lesson Details"
        '
        'txtSession1
        '
        Me.txtSession1.BackColor = System.Drawing.Color.Gainsboro
        Me.txtSession1.Location = New System.Drawing.Point(65, 18)
        Me.txtSession1.Name = "txtSession1"
        Me.txtSession1.Size = New System.Drawing.Size(100, 20)
        Me.txtSession1.TabIndex = 9
        '
        'txtSession2
        '
        Me.txtSession2.BackColor = System.Drawing.Color.Gainsboro
        Me.txtSession2.Location = New System.Drawing.Point(65, 69)
        Me.txtSession2.Name = "txtSession2"
        Me.txtSession2.Size = New System.Drawing.Size(100, 20)
        Me.txtSession2.TabIndex = 10
        '
        'txtTimeFinish2
        '
        Me.txtTimeFinish2.BackColor = System.Drawing.Color.Gainsboro
        Me.txtTimeFinish2.Location = New System.Drawing.Point(437, 69)
        Me.txtTimeFinish2.Name = "txtTimeFinish2"
        Me.txtTimeFinish2.Size = New System.Drawing.Size(100, 20)
        Me.txtTimeFinish2.TabIndex = 11
        '
        'txtTimeFinish1
        '
        Me.txtTimeFinish1.BackColor = System.Drawing.Color.Gainsboro
        Me.txtTimeFinish1.Location = New System.Drawing.Point(437, 18)
        Me.txtTimeFinish1.Name = "txtTimeFinish1"
        Me.txtTimeFinish1.Size = New System.Drawing.Size(100, 20)
        Me.txtTimeFinish1.TabIndex = 12
        '
        'txtTimeStart1
        '
        Me.txtTimeStart1.BackColor = System.Drawing.Color.Gainsboro
        Me.txtTimeStart1.Location = New System.Drawing.Point(242, 18)
        Me.txtTimeStart1.Name = "txtTimeStart1"
        Me.txtTimeStart1.Size = New System.Drawing.Size(100, 20)
        Me.txtTimeStart1.TabIndex = 13
        '
        'txtTimeStart2
        '
        Me.txtTimeStart2.BackColor = System.Drawing.Color.Gainsboro
        Me.txtTimeStart2.Location = New System.Drawing.Point(242, 69)
        Me.txtTimeStart2.Name = "txtTimeStart2"
        Me.txtTimeStart2.Size = New System.Drawing.Size(100, 20)
        Me.txtTimeStart2.TabIndex = 14
        '
        'btnSaveLesson
        '
        Me.btnSaveLesson.BackColor = System.Drawing.Color.Red
        Me.btnSaveLesson.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSaveLesson.Location = New System.Drawing.Point(209, 201)
        Me.btnSaveLesson.Name = "btnSaveLesson"
        Me.btnSaveLesson.Size = New System.Drawing.Size(80, 34)
        Me.btnSaveLesson.TabIndex = 9
        Me.btnSaveLesson.Text = "Save Lesson"
        Me.btnSaveLesson.UseVisualStyleBackColor = False
        '
        'frmNewLesson
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(582, 247)
        Me.Controls.Add(Me.btnSaveLesson)
        Me.Controls.Add(Me.lblLocationID)
        Me.Controls.Add(Me.cmbLocationID)
        Me.Controls.Add(Me.grpLessonDetails)
        Me.Name = "frmNewLesson"
        Me.Text = "New Lesson"
        Me.grpLessonDetails.ResumeLayout(False)
        Me.grpLessonDetails.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmbLocationID As System.Windows.Forms.ComboBox
    Friend WithEvents lblLocationID As System.Windows.Forms.Label
    Friend WithEvents lblSession2 As System.Windows.Forms.Label
    Friend WithEvents lblSession1 As System.Windows.Forms.Label
    Friend WithEvents lblTimeFinish2 As System.Windows.Forms.Label
    Friend WithEvents lblTimeFinish1 As System.Windows.Forms.Label
    Friend WithEvents lblTimeStart2 As System.Windows.Forms.Label
    Friend WithEvents lblTimeStart1 As System.Windows.Forms.Label
    Friend WithEvents grpLessonDetails As System.Windows.Forms.GroupBox
    Friend WithEvents txtSession1 As System.Windows.Forms.TextBox
    Friend WithEvents txtSession2 As System.Windows.Forms.TextBox
    Friend WithEvents txtTimeFinish2 As System.Windows.Forms.TextBox
    Friend WithEvents txtTimeFinish1 As System.Windows.Forms.TextBox
    Friend WithEvents txtTimeStart1 As System.Windows.Forms.TextBox
    Friend WithEvents txtTimeStart2 As System.Windows.Forms.TextBox
    Friend WithEvents btnSaveLesson As System.Windows.Forms.Button
End Class

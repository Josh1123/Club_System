﻿Public Class frmAttendLesson

    Private Sub frmAttendLesson_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim LocationRecord As LocationType                                      'Decalares a variable to store the record structure for my locations
        Dim StudentRecord As StudentType                                        'Decalares a variable to store the record structure for my Students
        Dim StudentRecordPosition As Integer                                    'Declares a variable to calculate and store the liaction a student can be found at
        Dim RecordPosition As Integer                                           'Decalres a variable to save and store the location of my location records
        StudentRecordPosition = 0                                               'Sets student record position as 0
        RecordPosition = 0                                                      'Sets record position as 0
        FileOpen(4, "Location.dat", OpenMode.Random, , , Len(LocationRecord))   'Opens location file
        Do While Not EOF(4)                                                     'Loops until the end of location file
            RecordPosition = RecordPosition + 1                                 'Adds 1 to Record Position
            FileGet(4, LocationRecord, RecordPosition)                          'Reads Location record from location file at record position
            cmbLocationID.Items.Add(LocationRecord.LocationID)                  'Adds location ID to Combo Box
        Loop
        FileClose(4)                                                            'Closes Location File

        FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord))     'Opens Student File
        Do While Not EOF(1)                                                     'Loops until end of student file
            StudentRecordPosition = StudentRecordPosition + 1                   'Adds 1 to student record position
            FileGet(1, StudentRecord, StudentRecordPosition)                    'Reads student rceord from student file at student record position
            cmbStudentID.Items.Add(StudentRecord.StudentID)                     'Adds student ID from student record to combo box
        Loop
        FileClose(1)                                                            'Closes Student file
    End Sub

    Private Sub cmbLocationID_SelectedValueChanged(sender As Object, e As EventArgs) Handles cmbLocationID.SelectedValueChanged
        Dim LessonRecord As LessonType                                          'Declares a variable to store the record structure for my lessons
        Dim RecordPosition As Integer                                           'Declares a record to calculate and save the location of my lessons 
        RecordPosition = 0                                                      'Sets record position as 0
        cmbSesison.Items.Clear()
        FileOpen(6, "Lesson.dat", OpenMode.Random, , , Len(LessonRecord))       'Opens lessson file
        Do While Not EOF(6)                                                     'Loops through Leeson file until end of file
            RecordPosition = RecordPosition + 1                                 'Adds 1 to rceord position
            FileGet(6, LessonRecord, RecordPosition)                            'Gets lesson record from lesson file at record position
            If LessonRecord.LocationID = cmbLocationID.SelectedItem() Then      'If Location IDs (from combo box and lesson record) Match
                With LessonRecord                                               'Saves haaving to type lesson.etc
                    cmbSesison.Items.Add(.Session1)                             'Adds session1 to combo box
                    cmbSesison.Items.Add(.Session2)                             'Adds session2 to combo box
                End With
            End If
        Loop                                                                    'Ends loop
        FileClose(6)                                                            'Closes Lesson file
    End Sub

    Private Sub btnAttend_Click(sender As Object, e As EventArgs) Handles btnAttend.Click
        Dim AttendanceRecord As AttendanceType                                                  'Decalres a variable to save and store the rceord structure for my attendance
        Dim LastRecordPosition As Integer                                                       'Declares a variable to calculate and store the last record position in teh attendance file
        Dim AllValid As Boolean                                                                 'Declares a variable to validate my attendence
        LastRecordPosition = 0                                                                  'Sets last record position as 0
        AllValid = ValidateAttendance(cmbStudentID, txtDateOfSession)                           'Calls public function Validate Attendance
        If AllValid Then                                                                        'If Entry Passes Validation
            FileOpen(7, "Attendance.dat", OpenMode.Random, , , Len(AttendanceRecord))           'Opens Attendance File
            With AttendanceRecord                                                               'Saves time having to type out AttendanceRecord.etc..
                .Session = cmbSesison.SelectedItem()                                            'Adds details from form to record
                .DateAttended = txtDateOfSession.Text                                           'Adds details from form to record                                           
                .StudentId = cmbStudentID.SelectedItem()                                        'Adds details from form to record
            End With
            LastRecordPosition = LOF(7) / Len(AttendanceRecord)                                 'Finsd the location of the the last record in the file
            LastRecordPosition = LastRecordPosition + 1                                         'Adds one to last record position to find the place to write the new record
            MsgBox("Student Has Attended the Session")                                          'Displays Message saying record has been saved
            FilePut(7, AttendanceRecord, LastRecordPosition)                                    'Writes Attendance record to attendance file at last record position
        End If
        FileClose(7)                                                                            'Closes Attendace file
    End Sub
End Class
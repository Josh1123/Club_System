﻿Public Class frmNewStudent
    Public Sub GenerateStudID()                                                   'Declares a sub Program generate student ID
        If Len(txtLastName.Text) > 1 And Len(txtFirstName.Text) > 0 Then          'If last name is longer then 1 character and first name is longer the 0 characters
            lblGenerateID.Text = GenerateStudentID(txtFirstName.Text, txtLastName.Text) 'Calls public function generate student ID
        End If
    End Sub
    Private Sub txtFirstName_TextChanged(sender As Object, e As EventArgs) Handles txtFirstName.TextChanged
        Call GenerateStudID()                                                       'Calls sub program GenertaeStudID
    End Sub

    Private Sub txtLastName_TextChanged(sender As Object, e As EventArgs) Handles txtLastName.TextChanged
        Call GenerateStudID()                                                       'Calls sub program GenertaeStudID
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim StudentRecord As StudentType                                            'Declares a variable to save the record structure for my students
        Dim LastRecordPosition As Integer                                           'Declares a variable to calculate and store the location of teh last record in the student file
        Dim AllValid As Boolean                                                     'Declares a variable to help validate user entry
        Dim Gender As Char                                                          'Declares a variable to store the gender from user entry
        AllValid = ValidateStudent(txtFirstName, txtLastName, txtDateOfBirth.Text, txtAddress, txtPostCode, txtMobileNumber, txtEmail)  'Calls public function ValidateStudent
        If AllValid Then                                                            'If user entry passes validation
            FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord))     'Opens student file
            With StudentRecord                                                      'Saves having to type Studentrecord.etc
                .StudentID = lblGenerateID.Text                                     'Adds details from form to student record
                .FirstName = txtFirstName.Text                                      'Adds details from form to student record
                .LastName = txtLastName.Text                                        'Adds details from form to student record
                If radMale.Checked Then                                             'If male
                    Gender = "M"                                                    'Sets gender as M
                End If
                If radFemale.Checked Then                                           'If Female
                    Gender = "F"                                                    'Sets Gender as F
                End If
                .Gender = Gender                                                    'Adds details from form to student record
                .DateOfBirth = txtDateOfBirth.Text                                  'Adds details from form to student record
                .Address = txtAddress.Text                                          'Adds details from form to student record
                .PostCode = txtPostCode.Text                                        'Adds details from form to student record
                .HomeNumber = txtTeleNumber.Text                                    'Adds details from form to student record
                .MobileNumber = txtMobileNumber.Text                                'Adds details from form to student record
                .Email = txtEmail.Text                                              'Adds details from form to student record
                .Deleted = False                                                    'Adds details from form to student record
            End With
            LastRecordPosition = LOF(1) / Len(StudentRecord)                        'Calculates the location of the last rceord in the student file
            LastRecordPosition = LastRecordPosition + 1                             'Adds one to the last record position to find the location to write the new record
            FilePut(1, StudentRecord, LastRecordPosition)                           'Writes the student record to the student file at last rceord position
            MsgBox("Student Record has been added to the student file")             'Displays mwessage saying that the student has been added to the system
        End If
        FileClose(1)                                                                'Closes student file
    End Sub
End Class
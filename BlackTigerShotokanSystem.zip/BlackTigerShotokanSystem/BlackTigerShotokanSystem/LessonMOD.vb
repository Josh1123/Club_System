﻿Module LessonMOD
    Public Structure LessonType
        <VBFixedString(9)> Dim Session1 As String                   'All the variables are self documenting so each store the data contains to its name
        <VBFixedString(9)> Dim Session2 As String
        <VBFixedString(6)> Dim LocationID As String
        <VBFixedString(6)> Dim TimeStart1 As String
        <VBFixedString(6)> Dim TimeFinish1 As String
        <VBFixedString(6)> Dim TimeStart2 As String
        <VBFixedString(6)> Dim TimeFinish2 As String
    End Structure
    Public Function ValidateLesson(ByVal TimStar1 As TextBox, ByVal TimStar2 As TextBox, ByVal TimFin1 As TextBox, ByVal TimFin2 As TextBox) As Boolean     'Declares a function to validate the user entr for my lessons
        Dim Valid As Boolean                    'Declares a variable to help validate my user entry
        Valid = True                            'Sets valid as true
        If InStr(TimStar1.Text, ":") = 0 Then   'If time start does not contain a :
            Valid = False                       'Sets Valid as False
            MsgBox("Please ensure that Time Start contains :")
        ElseIf InStr(TimFin1.Text, ":") = 0 Then    'If time start does not contain a :
            Valid = False                           'Sets Valid as False
            MsgBox("Plesae ensure that Time finish contains :") 'Displays Error Message
        ElseIf TimFin1.Text <> "" Then              'If time finish not blank
            If CDate(TimFin1.Text).Hour > 21 Then   'If time finish 1 > 9pm
                Valid = False                       'Sets Valid as False
                MsgBox("Lessons must finish before 21:00")  'Displays Error Message
            End If
        End If
        If TimStar2.Text <> "" Then                 'If time start not blank
            If InStr(TimStar2.Text, ":") = 0 Then   'If time start does not contain a :
                Valid = False                       'Sets Valid as False
                MsgBox("Please ensure that Time start contains :")      'Displays Error Message   '
            End If
        End If
        If TimFin2.Text <> "" Then                  'If time finish 2 not blank
            If InStr(TimFin2.Text, ":") = 0 Then    'If time start does not contain a :
                Valid = False                       'Sets Valid as False
                MsgBox("Plesae ensure that Time finish contains :") 'Displays Error Message
            End If
        End If
        If TimFin2.Text <> "" And Valid = True Then 'If valid and time finish 2 not blank
            If CDate(TimFin2.Text).Hour > 21 Then   'If time finish 2 > 9pm
                Valid = False                       'Sets Valid as False
                MsgBox("Lessons must finish before 21:00")      'Displays Error Message
            End If
        End If
        Return Valid                                'Returns Valid to main program
    End Function
End Module

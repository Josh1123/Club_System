﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNewLicence
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnSaveLicence = New System.Windows.Forms.Button()
        Me.btnViewLicence = New System.Windows.Forms.Button()
        Me.lblGenerateLicenceID = New System.Windows.Forms.Label()
        Me.lblLicenceID = New System.Windows.Forms.Label()
        Me.lblStudentID = New System.Windows.Forms.Label()
        Me.lblMedicalYN = New System.Windows.Forms.Label()
        Me.lblMedication = New System.Windows.Forms.Label()
        Me.lblCurrentGrade = New System.Windows.Forms.Label()
        Me.lblDateIssued = New System.Windows.Forms.Label()
        Me.lblDateExpired = New System.Windows.Forms.Label()
        Me.lblPaid = New System.Windows.Forms.Label()
        Me.txtMedication = New System.Windows.Forms.TextBox()
        Me.txtGrade = New System.Windows.Forms.TextBox()
        Me.txtDateIssued = New System.Windows.Forms.TextBox()
        Me.txtDateExpired = New System.Windows.Forms.TextBox()
        Me.cmbStudentID = New System.Windows.Forms.ComboBox()
        Me.radNo = New System.Windows.Forms.RadioButton()
        Me.radYes = New System.Windows.Forms.RadioButton()
        Me.ckbPaid = New System.Windows.Forms.CheckBox()
        Me.txtMedicalProblems = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnSaveLicence
        '
        Me.btnSaveLicence.BackColor = System.Drawing.Color.Red
        Me.btnSaveLicence.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSaveLicence.Location = New System.Drawing.Point(41, 437)
        Me.btnSaveLicence.Name = "btnSaveLicence"
        Me.btnSaveLicence.Size = New System.Drawing.Size(99, 47)
        Me.btnSaveLicence.TabIndex = 0
        Me.btnSaveLicence.Text = "Save Licence"
        Me.btnSaveLicence.UseVisualStyleBackColor = False
        '
        'btnViewLicence
        '
        Me.btnViewLicence.BackColor = System.Drawing.Color.Black
        Me.btnViewLicence.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnViewLicence.ForeColor = System.Drawing.Color.White
        Me.btnViewLicence.Location = New System.Drawing.Point(191, 437)
        Me.btnViewLicence.Name = "btnViewLicence"
        Me.btnViewLicence.Size = New System.Drawing.Size(99, 47)
        Me.btnViewLicence.TabIndex = 1
        Me.btnViewLicence.Text = "View Licence"
        Me.btnViewLicence.UseVisualStyleBackColor = False
        '
        'lblGenerateLicenceID
        '
        Me.lblGenerateLicenceID.BackColor = System.Drawing.Color.Gainsboro
        Me.lblGenerateLicenceID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGenerateLicenceID.Location = New System.Drawing.Point(191, 23)
        Me.lblGenerateLicenceID.Name = "lblGenerateLicenceID"
        Me.lblGenerateLicenceID.Size = New System.Drawing.Size(120, 23)
        Me.lblGenerateLicenceID.TabIndex = 2
        '
        'lblLicenceID
        '
        Me.lblLicenceID.AutoSize = True
        Me.lblLicenceID.Location = New System.Drawing.Point(38, 24)
        Me.lblLicenceID.Name = "lblLicenceID"
        Me.lblLicenceID.Size = New System.Drawing.Size(59, 13)
        Me.lblLicenceID.TabIndex = 3
        Me.lblLicenceID.Text = "Licence ID"
        '
        'lblStudentID
        '
        Me.lblStudentID.AutoSize = True
        Me.lblStudentID.Location = New System.Drawing.Point(38, 74)
        Me.lblStudentID.Name = "lblStudentID"
        Me.lblStudentID.Size = New System.Drawing.Size(58, 13)
        Me.lblStudentID.TabIndex = 4
        Me.lblStudentID.Text = "Student ID"
        '
        'lblMedicalYN
        '
        Me.lblMedicalYN.AutoSize = True
        Me.lblMedicalYN.Location = New System.Drawing.Point(38, 130)
        Me.lblMedicalYN.Name = "lblMedicalYN"
        Me.lblMedicalYN.Size = New System.Drawing.Size(90, 13)
        Me.lblMedicalYN.TabIndex = 5
        Me.lblMedicalYN.Text = "Medical Problems"
        '
        'lblMedication
        '
        Me.lblMedication.AutoSize = True
        Me.lblMedication.Location = New System.Drawing.Point(3, 209)
        Me.lblMedication.Name = "lblMedication"
        Me.lblMedication.Size = New System.Drawing.Size(144, 26)
        Me.lblMedication.TabIndex = 6
        Me.lblMedication.Text = "                 If Yes, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Name any Medication Taken"
        '
        'lblCurrentGrade
        '
        Me.lblCurrentGrade.AutoSize = True
        Me.lblCurrentGrade.Location = New System.Drawing.Point(38, 276)
        Me.lblCurrentGrade.Name = "lblCurrentGrade"
        Me.lblCurrentGrade.Size = New System.Drawing.Size(73, 13)
        Me.lblCurrentGrade.TabIndex = 7
        Me.lblCurrentGrade.Text = "Current Grade"
        '
        'lblDateIssued
        '
        Me.lblDateIssued.AutoSize = True
        Me.lblDateIssued.Location = New System.Drawing.Point(38, 317)
        Me.lblDateIssued.Name = "lblDateIssued"
        Me.lblDateIssued.Size = New System.Drawing.Size(105, 13)
        Me.lblDateIssued.TabIndex = 8
        Me.lblDateIssued.Text = "Date Licence Issued"
        '
        'lblDateExpired
        '
        Me.lblDateExpired.AutoSize = True
        Me.lblDateExpired.Location = New System.Drawing.Point(38, 356)
        Me.lblDateExpired.Name = "lblDateExpired"
        Me.lblDateExpired.Size = New System.Drawing.Size(109, 13)
        Me.lblDateExpired.TabIndex = 9
        Me.lblDateExpired.Text = "Date Licence Expired"
        '
        'lblPaid
        '
        Me.lblPaid.AutoSize = True
        Me.lblPaid.Location = New System.Drawing.Point(38, 401)
        Me.lblPaid.Name = "lblPaid"
        Me.lblPaid.Size = New System.Drawing.Size(34, 13)
        Me.lblPaid.TabIndex = 10
        Me.lblPaid.Text = "Paid?"
        '
        'txtMedication
        '
        Me.txtMedication.BackColor = System.Drawing.Color.Gainsboro
        Me.txtMedication.Location = New System.Drawing.Point(191, 215)
        Me.txtMedication.Name = "txtMedication"
        Me.txtMedication.Size = New System.Drawing.Size(120, 20)
        Me.txtMedication.TabIndex = 11
        '
        'txtGrade
        '
        Me.txtGrade.BackColor = System.Drawing.Color.Gainsboro
        Me.txtGrade.Location = New System.Drawing.Point(191, 273)
        Me.txtGrade.Name = "txtGrade"
        Me.txtGrade.Size = New System.Drawing.Size(120, 20)
        Me.txtGrade.TabIndex = 12
        '
        'txtDateIssued
        '
        Me.txtDateIssued.BackColor = System.Drawing.Color.Gainsboro
        Me.txtDateIssued.Location = New System.Drawing.Point(191, 314)
        Me.txtDateIssued.Name = "txtDateIssued"
        Me.txtDateIssued.Size = New System.Drawing.Size(120, 20)
        Me.txtDateIssued.TabIndex = 13
        '
        'txtDateExpired
        '
        Me.txtDateExpired.BackColor = System.Drawing.Color.Gainsboro
        Me.txtDateExpired.Enabled = False
        Me.txtDateExpired.Location = New System.Drawing.Point(191, 353)
        Me.txtDateExpired.Name = "txtDateExpired"
        Me.txtDateExpired.Size = New System.Drawing.Size(120, 20)
        Me.txtDateExpired.TabIndex = 14
        '
        'cmbStudentID
        '
        Me.cmbStudentID.BackColor = System.Drawing.Color.Gainsboro
        Me.cmbStudentID.FormattingEnabled = True
        Me.cmbStudentID.Location = New System.Drawing.Point(191, 71)
        Me.cmbStudentID.Name = "cmbStudentID"
        Me.cmbStudentID.Size = New System.Drawing.Size(120, 21)
        Me.cmbStudentID.TabIndex = 15
        '
        'radNo
        '
        Me.radNo.AutoSize = True
        Me.radNo.Location = New System.Drawing.Point(272, 128)
        Me.radNo.Name = "radNo"
        Me.radNo.Size = New System.Drawing.Size(39, 17)
        Me.radNo.TabIndex = 19
        Me.radNo.TabStop = True
        Me.radNo.Text = "No"
        Me.radNo.UseVisualStyleBackColor = True
        '
        'radYes
        '
        Me.radYes.AutoSize = True
        Me.radYes.Location = New System.Drawing.Point(191, 128)
        Me.radYes.Name = "radYes"
        Me.radYes.Size = New System.Drawing.Size(43, 17)
        Me.radYes.TabIndex = 18
        Me.radYes.TabStop = True
        Me.radYes.Text = "Yes"
        Me.radYes.UseVisualStyleBackColor = True
        '
        'ckbPaid
        '
        Me.ckbPaid.AutoSize = True
        Me.ckbPaid.Location = New System.Drawing.Point(222, 397)
        Me.ckbPaid.Name = "ckbPaid"
        Me.ckbPaid.Size = New System.Drawing.Size(53, 17)
        Me.ckbPaid.TabIndex = 20
        Me.ckbPaid.Text = "Paid?"
        Me.ckbPaid.UseVisualStyleBackColor = True
        '
        'txtMedicalProblems
        '
        Me.txtMedicalProblems.BackColor = System.Drawing.Color.Gainsboro
        Me.txtMedicalProblems.Location = New System.Drawing.Point(191, 170)
        Me.txtMedicalProblems.Name = "txtMedicalProblems"
        Me.txtMedicalProblems.Size = New System.Drawing.Size(120, 20)
        Me.txtMedicalProblems.TabIndex = 22
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 164)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(141, 26)
        Me.Label1.TabIndex = 21
        Me.Label1.Text = "                 If Yes, " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Name any Medical Problems"
        '
        'frmNewLicence
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(330, 514)
        Me.Controls.Add(Me.txtMedicalProblems)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ckbPaid)
        Me.Controls.Add(Me.radNo)
        Me.Controls.Add(Me.radYes)
        Me.Controls.Add(Me.cmbStudentID)
        Me.Controls.Add(Me.txtDateExpired)
        Me.Controls.Add(Me.txtDateIssued)
        Me.Controls.Add(Me.txtGrade)
        Me.Controls.Add(Me.txtMedication)
        Me.Controls.Add(Me.lblPaid)
        Me.Controls.Add(Me.lblDateExpired)
        Me.Controls.Add(Me.lblDateIssued)
        Me.Controls.Add(Me.lblCurrentGrade)
        Me.Controls.Add(Me.lblMedication)
        Me.Controls.Add(Me.lblMedicalYN)
        Me.Controls.Add(Me.lblStudentID)
        Me.Controls.Add(Me.lblLicenceID)
        Me.Controls.Add(Me.lblGenerateLicenceID)
        Me.Controls.Add(Me.btnViewLicence)
        Me.Controls.Add(Me.btnSaveLicence)
        Me.Name = "frmNewLicence"
        Me.Text = "New Licence"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnSaveLicence As System.Windows.Forms.Button
    Friend WithEvents btnViewLicence As System.Windows.Forms.Button
    Friend WithEvents lblGenerateLicenceID As System.Windows.Forms.Label
    Friend WithEvents lblLicenceID As System.Windows.Forms.Label
    Friend WithEvents lblStudentID As System.Windows.Forms.Label
    Friend WithEvents lblMedicalYN As System.Windows.Forms.Label
    Friend WithEvents lblMedication As System.Windows.Forms.Label
    Friend WithEvents lblCurrentGrade As System.Windows.Forms.Label
    Friend WithEvents lblDateIssued As System.Windows.Forms.Label
    Friend WithEvents lblDateExpired As System.Windows.Forms.Label
    Friend WithEvents lblPaid As System.Windows.Forms.Label
    Friend WithEvents txtMedication As System.Windows.Forms.TextBox
    Friend WithEvents txtGrade As System.Windows.Forms.TextBox
    Friend WithEvents txtDateIssued As System.Windows.Forms.TextBox
    Friend WithEvents txtDateExpired As System.Windows.Forms.TextBox
    Friend WithEvents cmbStudentID As System.Windows.Forms.ComboBox
    Friend WithEvents radNo As System.Windows.Forms.RadioButton
    Friend WithEvents radYes As System.Windows.Forms.RadioButton
    Friend WithEvents ckbPaid As System.Windows.Forms.CheckBox
    Friend WithEvents txtMedicalProblems As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class

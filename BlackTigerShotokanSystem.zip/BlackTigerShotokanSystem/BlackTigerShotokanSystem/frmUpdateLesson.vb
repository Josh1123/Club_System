﻿Public Class frmUpdateLesson

    Private Sub frmUpdateLesson_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim LocationRecord As LocationType                              'Declares variable to store the record structire for locations
        Dim RecordPosition As Integer                                   'Declares a varaible to store and calculate the record position
        RecordPosition = 0                                              'Sets record position as 0
        FileOpen(4, "Location.dat", OpenMode.Random, , , Len(LocationRecord))   'Opens location file
        Do While Not EOF(4)                                             'Reapets until end of location file
            RecordPosition = RecordPosition + 1                         'Adds one to record position
            FileGet(4, LocationRecord, RecordPosition)                  'Gets location record at record position from location file
            cmbLocationID.Items.Add(LocationRecord.LocationID)          'Adds location ID to combo box
        Loop
        FileClose(4)                                                    'Closes location file
    End Sub

    Private Sub cmbLocationID_SelectedValueChanged(sender As Object, e As EventArgs) Handles cmbLocationID.SelectedValueChanged
        Dim LessonRecord As LessonType                                  'Declares a variable to store the record structure for my lessons
        Dim RecordPosition As Integer                                   'Declares a variable to store and calculate the record position
        RecordPosition = 0                                              'Sets record position as 0
        FileOpen(6, "Lesson.dat", OpenMode.Random, , , Len(LessonRecord))   'Opens Lesson file
        Do While Not EOF(6)                                             'Repeats until end of lesson file
            RecordPosition = RecordPosition + 1                         'Adds one to record position
            FileGet(6, LessonRecord, RecordPosition)                    'Gets lesson record from lesson file at record position
            If LessonRecord.LocationID = cmbLocationID.SelectedItem() Then  'If location IDs match
                With LessonRecord                                       'Saves having to enter in LessonRecord.etc
                    txtSession1.Text = .Session1                        'Displays Lesson Details
                    txtSession2.Text = .Session2                        'Displays Lesson Details
                    txtTimeStart1.Text = .TimeStart1                    'Displays Lesson Details
                    txtTimeStart2.Text = .TimeStart2                    'Displays Lesson Details
                    txtTimeFinish1.Text = .TimeFinish1                  'Displays Lesson Details
                    txtTimeFinish2.Text = .TimeFinish2                  'Displays Lesson Details
                End With
            End If
        Loop
        FileClose(6)                                                    'Closes lesson file
    End Sub

    Private Sub btnUpdateLesson_Click(sender As Object, e As EventArgs) Handles btnUpdateLesson.Click
        Dim LessonRecord As LessonType                                  'Declares a variable to store the record structure for my lessons
        Dim RecordPosition As Integer                                   'Declares a variable to store and calculate the record position
        Dim AllValid As Boolean                                         'Declares a variable to validate the lesson
        AllValid = ValidateLesson(txtTimeStart1, txtTimeStart2, txtTimeFinish1, txtTimeFinish2)
        If AllValid Then
            RecordPosition = 0                                              'Sets record position as 0
            FileOpen(6, "Lesson.dat", OpenMode.Random, , , Len(LessonRecord))   'Opens Lesson file
            Do While Not EOF(6)                                             'Repeats until end of lesson file
                RecordPosition = RecordPosition + 1                         'Adds one to record position
                FileGet(6, LessonRecord, RecordPosition)                    'Gets lesson record from lesson file at record position
                If LessonRecord.LocationID = cmbLocationID.SelectedItem() Then  'If location IDs match
                    With LessonRecord                                       'Saves having to enter in lessonRecord.etc
                        .Session1 = txtSession1.Text                        'Writes Details from form to record
                        .Session2 = txtSession2.Text                        'Writes Details from form to record
                        .TimeStart1 = txtTimeStart1.Text                    'Writes Details from form to record
                        .TimeStart2 = txtTimeStart2.Text                    'Writes Details from form to record
                        .TimeFinish1 = txtTimeFinish1.Text                  'Writes Details from form to record
                        .TimeFinish2 = txtTimeFinish2.Text                  'Writes Details from form to record
                    End With
                End If
            Loop
            MsgBox("Lesson has been updated")                           'Displays message sayiung that the lesson has been updated
            FilePut(6, LessonRecord, RecordPosition)                    'Writes LessonRecord to lesson file at record position
        End If
        FileClose(6)                                                    'Closes lesson file
    End Sub
End Class
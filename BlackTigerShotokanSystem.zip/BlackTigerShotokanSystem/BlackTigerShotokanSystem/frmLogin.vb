﻿Public Class frmLogin
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If txtUsername.Text <> "Black Tiger Shotokan" Then                                      'If the username entered does not match "Black Tiger Shotokan"
            MsgBox("Please enter the correct Username")                                         'Will display error message saying that the username is incorrrect
        End If
        If txtPassword.Text <> "kurotora" Then                                                  'If Password enetred does not match kurotora
            MsgBox("Please enter the correct Password")                                         'Will display error message
        End If
        If txtUsername.Text = "Black Tiger Shotokan" And txtPassword.Text = "kurotora" Then     'If username and password match hardcoded username and password
            frmMainMenu.Show()                                                                  'Opens main menu form                                   
        End If
    End Sub
End Class
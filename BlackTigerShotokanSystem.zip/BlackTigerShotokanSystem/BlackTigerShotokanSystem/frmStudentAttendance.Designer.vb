﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStudentAttendance
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblStudentID = New System.Windows.Forms.Label()
        Me.lblLocationStudentTrains = New System.Windows.Forms.Label()
        Me.lblSessionsAttended = New System.Windows.Forms.Label()
        Me.lblSessionCouldAttend = New System.Windows.Forms.Label()
        Me.lblPerecntageAttendace = New System.Windows.Forms.Label()
        Me.lblEligableToGrade = New System.Windows.Forms.Label()
        Me.lblDisplayStudentID = New System.Windows.Forms.Label()
        Me.lblDisplayLocationID = New System.Windows.Forms.Label()
        Me.lblDisplaySessionsAttended = New System.Windows.Forms.Label()
        Me.lblDisplayPossibleAttendace = New System.Windows.Forms.Label()
        Me.lblDisaplyPercentage = New System.Windows.Forms.Label()
        Me.lblDisaplyEligable = New System.Windows.Forms.Label()
        Me.btnGrade = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblStudentID
        '
        Me.lblStudentID.AutoSize = True
        Me.lblStudentID.Location = New System.Drawing.Point(34, 36)
        Me.lblStudentID.Name = "lblStudentID"
        Me.lblStudentID.Size = New System.Drawing.Size(58, 13)
        Me.lblStudentID.TabIndex = 0
        Me.lblStudentID.Text = "Student ID"
        '
        'lblLocationStudentTrains
        '
        Me.lblLocationStudentTrains.AutoSize = True
        Me.lblLocationStudentTrains.Location = New System.Drawing.Point(34, 88)
        Me.lblLocationStudentTrains.Name = "lblLocationStudentTrains"
        Me.lblLocationStudentTrains.Size = New System.Drawing.Size(120, 13)
        Me.lblLocationStudentTrains.TabIndex = 1
        Me.lblLocationStudentTrains.Text = "Location Student Trains"
        '
        'lblSessionsAttended
        '
        Me.lblSessionsAttended.AutoSize = True
        Me.lblSessionsAttended.Location = New System.Drawing.Point(34, 152)
        Me.lblSessionsAttended.Name = "lblSessionsAttended"
        Me.lblSessionsAttended.Size = New System.Drawing.Size(95, 13)
        Me.lblSessionsAttended.TabIndex = 2
        Me.lblSessionsAttended.Text = "Sessions Attended"
        '
        'lblSessionCouldAttend
        '
        Me.lblSessionCouldAttend.AutoSize = True
        Me.lblSessionCouldAttend.Location = New System.Drawing.Point(34, 219)
        Me.lblSessionCouldAttend.Name = "lblSessionCouldAttend"
        Me.lblSessionCouldAttend.Size = New System.Drawing.Size(189, 13)
        Me.lblSessionCouldAttend.TabIndex = 3
        Me.lblSessionCouldAttend.Text = "Possible Number of Sessions Attended"
        Me.lblSessionCouldAttend.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblPerecntageAttendace
        '
        Me.lblPerecntageAttendace.AutoSize = True
        Me.lblPerecntageAttendace.Location = New System.Drawing.Point(34, 281)
        Me.lblPerecntageAttendace.Name = "lblPerecntageAttendace"
        Me.lblPerecntageAttendace.Size = New System.Drawing.Size(120, 13)
        Me.lblPerecntageAttendace.TabIndex = 4
        Me.lblPerecntageAttendace.Text = "Percentage Attendance"
        '
        'lblEligableToGrade
        '
        Me.lblEligableToGrade.AutoSize = True
        Me.lblEligableToGrade.Location = New System.Drawing.Point(34, 339)
        Me.lblEligableToGrade.Name = "lblEligableToGrade"
        Me.lblEligableToGrade.Size = New System.Drawing.Size(90, 13)
        Me.lblEligableToGrade.TabIndex = 5
        Me.lblEligableToGrade.Text = "Eligible to Grade?"
        '
        'lblDisplayStudentID
        '
        Me.lblDisplayStudentID.BackColor = System.Drawing.Color.Gainsboro
        Me.lblDisplayStudentID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisplayStudentID.Location = New System.Drawing.Point(224, 36)
        Me.lblDisplayStudentID.Name = "lblDisplayStudentID"
        Me.lblDisplayStudentID.Size = New System.Drawing.Size(100, 23)
        Me.lblDisplayStudentID.TabIndex = 6
        '
        'lblDisplayLocationID
        '
        Me.lblDisplayLocationID.BackColor = System.Drawing.Color.Gainsboro
        Me.lblDisplayLocationID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisplayLocationID.Location = New System.Drawing.Point(224, 88)
        Me.lblDisplayLocationID.Name = "lblDisplayLocationID"
        Me.lblDisplayLocationID.Size = New System.Drawing.Size(100, 23)
        Me.lblDisplayLocationID.TabIndex = 7
        '
        'lblDisplaySessionsAttended
        '
        Me.lblDisplaySessionsAttended.BackColor = System.Drawing.Color.Gainsboro
        Me.lblDisplaySessionsAttended.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisplaySessionsAttended.Location = New System.Drawing.Point(224, 152)
        Me.lblDisplaySessionsAttended.Name = "lblDisplaySessionsAttended"
        Me.lblDisplaySessionsAttended.Size = New System.Drawing.Size(100, 23)
        Me.lblDisplaySessionsAttended.TabIndex = 8
        '
        'lblDisplayPossibleAttendace
        '
        Me.lblDisplayPossibleAttendace.BackColor = System.Drawing.Color.Gainsboro
        Me.lblDisplayPossibleAttendace.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisplayPossibleAttendace.Location = New System.Drawing.Point(224, 218)
        Me.lblDisplayPossibleAttendace.Name = "lblDisplayPossibleAttendace"
        Me.lblDisplayPossibleAttendace.Size = New System.Drawing.Size(100, 23)
        Me.lblDisplayPossibleAttendace.TabIndex = 9
        '
        'lblDisaplyPercentage
        '
        Me.lblDisaplyPercentage.BackColor = System.Drawing.Color.Gainsboro
        Me.lblDisaplyPercentage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisaplyPercentage.Location = New System.Drawing.Point(224, 281)
        Me.lblDisaplyPercentage.Name = "lblDisaplyPercentage"
        Me.lblDisaplyPercentage.Size = New System.Drawing.Size(100, 23)
        Me.lblDisaplyPercentage.TabIndex = 10
        '
        'lblDisaplyEligable
        '
        Me.lblDisaplyEligable.BackColor = System.Drawing.Color.Gainsboro
        Me.lblDisaplyEligable.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisaplyEligable.Location = New System.Drawing.Point(224, 339)
        Me.lblDisaplyEligable.Name = "lblDisaplyEligable"
        Me.lblDisaplyEligable.Size = New System.Drawing.Size(100, 23)
        Me.lblDisaplyEligable.TabIndex = 11
        '
        'btnGrade
        '
        Me.btnGrade.BackColor = System.Drawing.Color.Black
        Me.btnGrade.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnGrade.ForeColor = System.Drawing.Color.White
        Me.btnGrade.Location = New System.Drawing.Point(132, 435)
        Me.btnGrade.Name = "btnGrade"
        Me.btnGrade.Size = New System.Drawing.Size(97, 36)
        Me.btnGrade.TabIndex = 12
        Me.btnGrade.Text = "Grade"
        Me.btnGrade.UseVisualStyleBackColor = False
        '
        'frmStudentAttendance
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(392, 504)
        Me.Controls.Add(Me.btnGrade)
        Me.Controls.Add(Me.lblDisaplyEligable)
        Me.Controls.Add(Me.lblDisaplyPercentage)
        Me.Controls.Add(Me.lblDisplayPossibleAttendace)
        Me.Controls.Add(Me.lblDisplaySessionsAttended)
        Me.Controls.Add(Me.lblDisplayLocationID)
        Me.Controls.Add(Me.lblDisplayStudentID)
        Me.Controls.Add(Me.lblEligableToGrade)
        Me.Controls.Add(Me.lblPerecntageAttendace)
        Me.Controls.Add(Me.lblSessionCouldAttend)
        Me.Controls.Add(Me.lblSessionsAttended)
        Me.Controls.Add(Me.lblLocationStudentTrains)
        Me.Controls.Add(Me.lblStudentID)
        Me.Name = "frmStudentAttendance"
        Me.Text = "Student Attendance"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblStudentID As System.Windows.Forms.Label
    Friend WithEvents lblLocationStudentTrains As System.Windows.Forms.Label
    Friend WithEvents lblSessionsAttended As System.Windows.Forms.Label
    Friend WithEvents lblSessionCouldAttend As System.Windows.Forms.Label
    Friend WithEvents lblPerecntageAttendace As System.Windows.Forms.Label
    Friend WithEvents lblEligableToGrade As System.Windows.Forms.Label
    Friend WithEvents lblDisplayStudentID As System.Windows.Forms.Label
    Friend WithEvents lblDisplayLocationID As System.Windows.Forms.Label
    Friend WithEvents lblDisplaySessionsAttended As System.Windows.Forms.Label
    Friend WithEvents lblDisplayPossibleAttendace As System.Windows.Forms.Label
    Friend WithEvents lblDisaplyPercentage As System.Windows.Forms.Label
    Friend WithEvents lblDisaplyEligable As System.Windows.Forms.Label
    Friend WithEvents btnGrade As System.Windows.Forms.Button
End Class

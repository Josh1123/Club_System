﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRenewLicence
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmRenewLicence))
        Me.lblLicenceID = New System.Windows.Forms.Label()
        Me.lblGenerateLicenceID = New System.Windows.Forms.Label()
        Me.lblDisplayStudentID = New System.Windows.Forms.Label()
        Me.lblStudentID = New System.Windows.Forms.Label()
        Me.lblPostCode = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.lblDateOfBirth = New System.Windows.Forms.Label()
        Me.lblDateExpired = New System.Windows.Forms.Label()
        Me.lblDateIssued = New System.Windows.Forms.Label()
        Me.lblDisaplyLastName = New System.Windows.Forms.Label()
        Me.lblDisaplyFirstName = New System.Windows.Forms.Label()
        Me.lblDisaplyPostCode = New System.Windows.Forms.Label()
        Me.lblDisaplyAddress = New System.Windows.Forms.Label()
        Me.lblDisaplyDateIssued = New System.Windows.Forms.Label()
        Me.lblDisaplyDateOfBirth = New System.Windows.Forms.Label()
        Me.lblDisaplyDateExpires = New System.Windows.Forms.Label()
        Me.btnPrintPreview = New System.Windows.Forms.Button()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.PrintDialog1 = New System.Windows.Forms.PrintDialog()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.SuspendLayout()
        '
        'lblLicenceID
        '
        Me.lblLicenceID.AutoSize = True
        Me.lblLicenceID.Location = New System.Drawing.Point(12, 22)
        Me.lblLicenceID.Name = "lblLicenceID"
        Me.lblLicenceID.Size = New System.Drawing.Size(59, 13)
        Me.lblLicenceID.TabIndex = 5
        Me.lblLicenceID.Text = "Licence ID"
        '
        'lblGenerateLicenceID
        '
        Me.lblGenerateLicenceID.BackColor = System.Drawing.Color.Gainsboro
        Me.lblGenerateLicenceID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGenerateLicenceID.Location = New System.Drawing.Point(165, 22)
        Me.lblGenerateLicenceID.Name = "lblGenerateLicenceID"
        Me.lblGenerateLicenceID.Size = New System.Drawing.Size(120, 23)
        Me.lblGenerateLicenceID.TabIndex = 4
        '
        'lblDisplayStudentID
        '
        Me.lblDisplayStudentID.BackColor = System.Drawing.Color.Gainsboro
        Me.lblDisplayStudentID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisplayStudentID.Location = New System.Drawing.Point(165, 66)
        Me.lblDisplayStudentID.Name = "lblDisplayStudentID"
        Me.lblDisplayStudentID.Size = New System.Drawing.Size(120, 23)
        Me.lblDisplayStudentID.TabIndex = 8
        '
        'lblStudentID
        '
        Me.lblStudentID.AutoSize = True
        Me.lblStudentID.Location = New System.Drawing.Point(12, 66)
        Me.lblStudentID.Name = "lblStudentID"
        Me.lblStudentID.Size = New System.Drawing.Size(58, 13)
        Me.lblStudentID.TabIndex = 7
        Me.lblStudentID.Text = "Student ID"
        '
        'lblPostCode
        '
        Me.lblPostCode.AutoSize = True
        Me.lblPostCode.Location = New System.Drawing.Point(11, 213)
        Me.lblPostCode.Name = "lblPostCode"
        Me.lblPostCode.Size = New System.Drawing.Size(56, 13)
        Me.lblPostCode.TabIndex = 24
        Me.lblPostCode.Text = "Post Code"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(12, 181)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(45, 13)
        Me.lblAddress.TabIndex = 23
        Me.lblAddress.Text = "Address"
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.Location = New System.Drawing.Point(11, 130)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(58, 13)
        Me.lblLastName.TabIndex = 22
        Me.lblLastName.Text = "Last Name"
        '
        'lblFirstName
        '
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.Location = New System.Drawing.Point(12, 99)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(57, 13)
        Me.lblFirstName.TabIndex = 21
        Me.lblFirstName.Text = "First Name"
        '
        'lblDateOfBirth
        '
        Me.lblDateOfBirth.AutoSize = True
        Me.lblDateOfBirth.Location = New System.Drawing.Point(11, 254)
        Me.lblDateOfBirth.Name = "lblDateOfBirth"
        Me.lblDateOfBirth.Size = New System.Drawing.Size(66, 13)
        Me.lblDateOfBirth.TabIndex = 26
        Me.lblDateOfBirth.Text = "Date of Birth"
        '
        'lblDateExpired
        '
        Me.lblDateExpired.AutoSize = True
        Me.lblDateExpired.Location = New System.Drawing.Point(11, 331)
        Me.lblDateExpired.Name = "lblDateExpired"
        Me.lblDateExpired.Size = New System.Drawing.Size(109, 13)
        Me.lblDateExpired.TabIndex = 28
        Me.lblDateExpired.Text = "Date Licence Expired"
        '
        'lblDateIssued
        '
        Me.lblDateIssued.AutoSize = True
        Me.lblDateIssued.Location = New System.Drawing.Point(11, 292)
        Me.lblDateIssued.Name = "lblDateIssued"
        Me.lblDateIssued.Size = New System.Drawing.Size(105, 13)
        Me.lblDateIssued.TabIndex = 27
        Me.lblDateIssued.Text = "Date Licence Issued"
        '
        'lblDisaplyLastName
        '
        Me.lblDisaplyLastName.BackColor = System.Drawing.Color.Gainsboro
        Me.lblDisaplyLastName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisaplyLastName.Location = New System.Drawing.Point(165, 130)
        Me.lblDisaplyLastName.Name = "lblDisaplyLastName"
        Me.lblDisaplyLastName.Size = New System.Drawing.Size(120, 23)
        Me.lblDisaplyLastName.TabIndex = 30
        '
        'lblDisaplyFirstName
        '
        Me.lblDisaplyFirstName.BackColor = System.Drawing.Color.Gainsboro
        Me.lblDisaplyFirstName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisaplyFirstName.Location = New System.Drawing.Point(165, 99)
        Me.lblDisaplyFirstName.Name = "lblDisaplyFirstName"
        Me.lblDisaplyFirstName.Size = New System.Drawing.Size(120, 23)
        Me.lblDisaplyFirstName.TabIndex = 29
        '
        'lblDisaplyPostCode
        '
        Me.lblDisaplyPostCode.BackColor = System.Drawing.Color.Gainsboro
        Me.lblDisaplyPostCode.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisaplyPostCode.Location = New System.Drawing.Point(165, 213)
        Me.lblDisaplyPostCode.Name = "lblDisaplyPostCode"
        Me.lblDisaplyPostCode.Size = New System.Drawing.Size(120, 23)
        Me.lblDisaplyPostCode.TabIndex = 32
        '
        'lblDisaplyAddress
        '
        Me.lblDisaplyAddress.BackColor = System.Drawing.Color.Gainsboro
        Me.lblDisaplyAddress.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisaplyAddress.Location = New System.Drawing.Point(165, 181)
        Me.lblDisaplyAddress.Name = "lblDisaplyAddress"
        Me.lblDisaplyAddress.Size = New System.Drawing.Size(120, 23)
        Me.lblDisaplyAddress.TabIndex = 31
        '
        'lblDisaplyDateIssued
        '
        Me.lblDisaplyDateIssued.BackColor = System.Drawing.Color.Gainsboro
        Me.lblDisaplyDateIssued.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisaplyDateIssued.Location = New System.Drawing.Point(165, 292)
        Me.lblDisaplyDateIssued.Name = "lblDisaplyDateIssued"
        Me.lblDisaplyDateIssued.Size = New System.Drawing.Size(120, 23)
        Me.lblDisaplyDateIssued.TabIndex = 34
        '
        'lblDisaplyDateOfBirth
        '
        Me.lblDisaplyDateOfBirth.BackColor = System.Drawing.Color.Gainsboro
        Me.lblDisaplyDateOfBirth.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisaplyDateOfBirth.Location = New System.Drawing.Point(165, 254)
        Me.lblDisaplyDateOfBirth.Name = "lblDisaplyDateOfBirth"
        Me.lblDisaplyDateOfBirth.Size = New System.Drawing.Size(120, 23)
        Me.lblDisaplyDateOfBirth.TabIndex = 33
        '
        'lblDisaplyDateExpires
        '
        Me.lblDisaplyDateExpires.BackColor = System.Drawing.Color.Gainsboro
        Me.lblDisaplyDateExpires.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDisaplyDateExpires.Location = New System.Drawing.Point(165, 326)
        Me.lblDisaplyDateExpires.Name = "lblDisaplyDateExpires"
        Me.lblDisaplyDateExpires.Size = New System.Drawing.Size(120, 28)
        Me.lblDisaplyDateExpires.TabIndex = 35
        '
        'btnPrintPreview
        '
        Me.btnPrintPreview.BackColor = System.Drawing.Color.Red
        Me.btnPrintPreview.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPrintPreview.Location = New System.Drawing.Point(41, 376)
        Me.btnPrintPreview.Name = "btnPrintPreview"
        Me.btnPrintPreview.Size = New System.Drawing.Size(79, 32)
        Me.btnPrintPreview.TabIndex = 36
        Me.btnPrintPreview.Text = "Print Preview"
        Me.btnPrintPreview.UseVisualStyleBackColor = False
        '
        'btnPrint
        '
        Me.btnPrint.BackColor = System.Drawing.Color.Black
        Me.btnPrint.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPrint.ForeColor = System.Drawing.Color.White
        Me.btnPrint.Location = New System.Drawing.Point(165, 376)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(79, 32)
        Me.btnPrint.TabIndex = 37
        Me.btnPrint.Text = "Print"
        Me.btnPrint.UseVisualStyleBackColor = False
        '
        'PrintDialog1
        '
        Me.PrintDialog1.UseEXDialog = True
        '
        'PrintDocument1
        '
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'frmRenewLicence
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(308, 440)
        Me.Controls.Add(Me.btnPrint)
        Me.Controls.Add(Me.btnPrintPreview)
        Me.Controls.Add(Me.lblDisaplyDateExpires)
        Me.Controls.Add(Me.lblDisaplyDateIssued)
        Me.Controls.Add(Me.lblDisaplyDateOfBirth)
        Me.Controls.Add(Me.lblDisaplyPostCode)
        Me.Controls.Add(Me.lblDisaplyAddress)
        Me.Controls.Add(Me.lblDisaplyLastName)
        Me.Controls.Add(Me.lblDisaplyFirstName)
        Me.Controls.Add(Me.lblDateExpired)
        Me.Controls.Add(Me.lblDateIssued)
        Me.Controls.Add(Me.lblDateOfBirth)
        Me.Controls.Add(Me.lblPostCode)
        Me.Controls.Add(Me.lblAddress)
        Me.Controls.Add(Me.lblLastName)
        Me.Controls.Add(Me.lblFirstName)
        Me.Controls.Add(Me.lblDisplayStudentID)
        Me.Controls.Add(Me.lblStudentID)
        Me.Controls.Add(Me.lblLicenceID)
        Me.Controls.Add(Me.lblGenerateLicenceID)
        Me.Name = "frmRenewLicence"
        Me.Text = "Renew Licence"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblLicenceID As System.Windows.Forms.Label
    Friend WithEvents lblGenerateLicenceID As System.Windows.Forms.Label
    Friend WithEvents lblDisplayStudentID As System.Windows.Forms.Label
    Friend WithEvents lblStudentID As System.Windows.Forms.Label
    Friend WithEvents lblPostCode As System.Windows.Forms.Label
    Friend WithEvents lblAddress As System.Windows.Forms.Label
    Friend WithEvents lblLastName As System.Windows.Forms.Label
    Friend WithEvents lblFirstName As System.Windows.Forms.Label
    Friend WithEvents lblDateOfBirth As System.Windows.Forms.Label
    Friend WithEvents lblDateExpired As System.Windows.Forms.Label
    Friend WithEvents lblDateIssued As System.Windows.Forms.Label
    Friend WithEvents lblDisaplyLastName As System.Windows.Forms.Label
    Friend WithEvents lblDisaplyFirstName As System.Windows.Forms.Label
    Friend WithEvents lblDisaplyPostCode As System.Windows.Forms.Label
    Friend WithEvents lblDisaplyAddress As System.Windows.Forms.Label
    Friend WithEvents lblDisaplyDateIssued As System.Windows.Forms.Label
    Friend WithEvents lblDisaplyDateOfBirth As System.Windows.Forms.Label
    Friend WithEvents lblDisaplyDateExpires As System.Windows.Forms.Label
    Friend WithEvents btnPrintPreview As System.Windows.Forms.Button
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents PrintDialog1 As System.Windows.Forms.PrintDialog
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As System.Windows.Forms.PrintPreviewDialog
End Class

﻿Public Class frmListLicence

    Private Sub frmListLicence_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim LicenceRecord As LicenceType                                                    'Declares a variable to store the record structure
        Dim ColsFormat As String = "{0,-20} {1,-20} {2,-20} {3,-20} {4,-20} {5,-20}"        'Declares a variable to store the location for my headings
        Dim RecordPosition As Integer                                                       'Declares a variable to store and calculate the record position from file
        RecordPosition = 0                                                                  'Sets record position as 0
        lstListLicences.Items.Clear()                                                       'Clears the list box
        lstListLicences.Items.Add(String.Format(ColsFormat, "Licence ID", "Student ID", "Medical Problems", "Medication", "Date Issued", "Date Expired"))   'Adds heading to the list box
        FileOpen(2, "Licence.dat", OpenMode.Random, , , Len(LicenceRecord))                 'Opens Licence file
        Do While Not EOF(2)                                                                 'Repeats until end of licence file
            RecordPosition = RecordPosition + 1                                             'Adds 1 to record position
            FileGet(2, LicenceRecord, RecordPosition)                                       'Gets licence record from liecnce file at record position
            With LicenceRecord                                                              'Saves having to type licence record.ect
                lstListLicences.Items.Add(String.Format(ColsFormat, .LicenceID, .StudentID, .MedicalIssues, .Medication, .DateIssued.Day & "/" & .DateIssued.Month & "/" & .DateIssued.Year, .DateExpired.Day & "/" & .DateExpired.Month & "/" & .DateExpired.Year))    'Adds record details to list box
            End With
        Loop                                                                                'Ends the loop
        FileClose(2)                                                                        'Closes licence file
    End Sub

    Private Sub txtFilterByLicenceID_TextChanged(sender As Object, e As EventArgs) Handles txtFilterByLicenceID.TextChanged
        Dim LicenceRecord As LicenceType                                                    'Declares a variable to store the record structure
        Dim ColsFormat As String = "{0,-20} {1,-20} {2,-20} {3,-20} {4,-20} {5,-20}"        'Declares a variable to store the location for my headings
        Dim RecordPosition As Integer                                                       'Declares a variable to store and calculate the record position from file
        RecordPosition = 0                                                                  'Sets record position as 0
        lstListLicences.Items.Clear()                                                       'Clears the list box
        lstListLicences.Items.Add(String.Format(ColsFormat, "Licence ID", "Student ID", "Medical Problems", "Medication", "Date Issued", "Date Expired"))   'Adds heading to the list box
        FileOpen(2, "Licence.dat", OpenMode.Random, , , Len(LicenceRecord))                 'Opens Licence file
        Do While Not EOF(2)                                                                 'Repeats until end of licence file
            RecordPosition = RecordPosition + 1                                             'Adds 1 to record position
            FileGet(2, LicenceRecord, RecordPosition)                                       'Gets licence record from liecnce file at record position
            With LicenceRecord                                                              'Saves having to type licence record.ect
                If .LicenceID.Contains(txtFilterByLicenceID.Text) Then                      'If licence ID in record contain user entry
                    lstListLicences.Items.Add(String.Format(ColsFormat, .LicenceID, .StudentID, .MedicalIssues, .Medication, .DateIssued.Day & "/" & .DateIssued.Month & "/" & .DateIssued.Year, .DateExpired.Day & "/" & .DateExpired.Month & "/" & .DateExpired.Year))    'Adds record deatils to list box
                End If                                                                      'Ends the if statment
            End With
        Loop                                                                                'Ends loop
        FileClose(2)                                                                        'Closes licence file
    End Sub

    Private Sub lstListLicences_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstListLicences.SelectedIndexChanged
        frmRenewLicence.Show()                                                              'Displays renew licence form
    End Sub
End Class
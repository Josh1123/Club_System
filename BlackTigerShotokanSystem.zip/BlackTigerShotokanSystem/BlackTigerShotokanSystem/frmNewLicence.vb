﻿Public Class frmNewLicence
    Private Sub radYes_CheckedChanged(sender As Object, e As EventArgs) Handles radYes.CheckedChanged
        If radYes.Checked = True Then                           'If radio button Yes checked
            txtMedication.Enabled = True                        'Enables user entry to medical problems and medication
            txtMedicalProblems.Enabled = True
        End If
        If radNo.Checked = True Then                            'If Radio button No is checked
            txtMedication.Enabled = False                       'Disables user entry to medical problems and medication
            txtMedicalProblems.Enabled = False
        End If
    End Sub

    Private Sub radNo_CheckedChanged(sender As Object, e As EventArgs) Handles radNo.CheckedChanged
        If radNo.Checked = True Then                            'If Radio button No is checked
            txtMedicalProblems.Enabled = False                  'Disables user entry to medical problems and medication
            txtMedication.Enabled = False
        End If
        If radYes.Checked = True Then                           'If radio button Yes checked
            txtMedicalProblems.Enabled = True                   'Enables user entry to medical problems and medication
            txtMedication.Enabled = True
        End If
    End Sub

    Private Sub frmNewLicence_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim StudentRecord As StudentType                                    'Declares a variable to save the record structure of my students
        Dim RecordPosition As Integer                                       'Declares a variable to calulate and store the location of my students in the student file
        Dim SelectInd As Integer
        Dim Count As Integer
        SelectInd = 0
        RecordPosition = 0                                                  'Sets record position as 0
        FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord)) 'Opens student file
        Do While Not EOF(1)                                                 'Repeats until the end of my student file
            RecordPosition = RecordPosition + 1                             'Adds 1 to record position
            FileGet(1, StudentRecord, RecordPosition)                       'Reads student record from student file at record position
            If StudentRecord.Deleted = False Then                           'If studnet not deleted
                cmbStudentID.Items.Add(StudentRecord.StudentID)             'Adds student Id to combo box
            End If
        Loop                                                                'Ends loop
        FileClose(1)                                                        'Closes Student file
        RecordPosition = 0                                                  'Sets Record Position as 0
        FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord)) 'Opens Student file
        Count = cmbStudentID.Items.Count                                    'Count = number of items in combo box
        Do While Not Count = SelectInd                                      'Repeat until count = selectIN
            If frmMainMenu.lstExpiredLicences.SelectedItem.Contains(cmbStudentID.Items.Item(SelectInd)) Then 'If list box selected item contains item at selectInd in combo box
                cmbStudentID.SelectedIndex() = SelectInd                    'Combo box disaplays item at select ind
            End If
            SelectInd = SelectInd + 1                                       'Adds 1 to select ind
        Loop
        FileClose(1)                                                        'Closes Student file
        FileClose(2)                                                        'Closes Licence file
    End Sub

    Private Sub cmbStudentID_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbStudentID.SelectedIndexChanged
        lblGenerateLicenceID.Text = GenerateLicenceID(cmbStudentID)         'Calls Public function  generate licence ID
        FileClose(1)
    End Sub

    Private Sub btnViewLicence_Click(sender As Object, e As EventArgs) Handles btnViewLicence.Click
        frmListLicence.Show()                                               'Displays List licence form
        FileClose(1)                                                        'Closes student file
    End Sub

    Private Sub btnSaveLicence_Click(sender As Object, e As EventArgs) Handles btnSaveLicence.Click
        Dim LicenceRecord As LicenceType                                    'Declares a variable to save the record structure for my licences
        Dim LastRecordPosition As Integer                                   'Declares a variable to calculate the location of the last record in licence file 
        Dim AllValid As Boolean                                             'declares a variable to help validate my licences
        AllValid = ValidateLicence(txtGrade)                                'Calls public function to validate user entry
        LastRecordPosition = 0                                              'Sets last record position as 0
        FileOpen(2, "Licence.dat", OpenMode.Random, , , Len(LicenceRecord)) 'Opens Licence file
        If ckbPaid.Checked = False Then                                     'If check box paid not ticked
            MsgBox("Please ensure that they have paid before saving the licence")   'Display error message
            btnSaveLicence.Enabled = False                                  'Disables save button
        Else
            If AllValid Then                                                'If user entry passes validation
                With LicenceRecord                                          'Saves having to type LicenceRecord.
                    .LicenceID = lblGenerateLicenceID.Text                  'Adds details to licence record
                    .StudentID = cmbStudentID.SelectedItem()                'Adds details to licence record
                    If radNo.Checked Then                                   'If no mediacl problems
                        txtMedicalProblems.Text = "N/A"                     'Displays N/A for user entry
                        txtMedication.Text = "N/A"                          'Displays N/A for user entry
                    End If
                    .MedicalIssues = txtMedicalProblems.Text                'Adds details to licence record
                    .Medication = txtMedication.Text                        'Adds details to licence record
                    .Grade = txtGrade.Text                                  'Adds details to licence record
                    .DateIssued = txtDateIssued.Text                        'Adds details to licence record
                    .DateExpired = txtDateExpired.Text                      'Adds details to licence record
                End With
                LastRecordPosition = LOF(2) / Len(LicenceRecord)            'Finds the location of the last record in the licence file
                LastRecordPosition = LastRecordPosition + 1                 'Adds 1 to last rceord position
                FilePut(2, LicenceRecord, LastRecordPosition)               'Writes licence record to licence file at last record position
                MsgBox("The Licence has been added to the system")          'Displays message saying that the record has been saved
            End If
        End If
        FileClose(2)                                                        'Closes licence file
        FileClose(1)                                                        'Closes student file
    End Sub


    Private Sub txtDateIssued_TextChanged(sender As Object, e As EventArgs) Handles txtDateIssued.TextChanged
        If IsNumeric(Mid(txtDateIssued.Text, 1, 2)) And IsNumeric(Mid(txtDateIssued.Text, 4, 2)) And IsNumeric(Mid(txtDateIssued.Text, 8, 2)) Then      'If user entry is of date format
            txtDateExpired.Text = CDate(txtDateIssued.Text).Day & "/" & Format(CDate(txtDateIssued.Text).Month, "00") & "/" & (CDate(txtDateIssued.Text).Year + 1)  'Generates date expired for the user
        Else
            txtDateExpired.Text = ""                                                                                                                    'If not date format will not generate date
        End If
        FileClose(1)
    End Sub
End Class
﻿Module LicenceMOD
    Public Structure LicenceType
        <VBFixedString(7)> Dim LicenceID As String              'All the variables are self documenting so each store the data contains to its name
        <VBFixedString(6)> Dim StudentID As String
        <VBFixedString(20)> Dim MedicalIssues As String
        <VBFixedString(20)> Dim Medication As String
        <VBFixedString(8)> Dim Grade As String
        Dim DateIssued As Date
        Dim DateExpired As Date
        Dim CashPaid As Boolean
    End Structure
    Public Function GenerateLicenceID(ByVal StudID As ComboBox) As String       'Declares a function to generate my licence ID
        Dim LicenceRecord As LicenceType                        'Declares a variable to store the record structure for m licence
        Dim LicID As String                                     'Declares a variable to store the generated ID
        Dim Letters As String                                   'Declares a variable to store letter part of my licence
        Dim Max As Integer                                      'Declares a variable to store the number part of the generated licence
        Dim NumberPart As Integer                               'Declares a variable to store the number of times the letters appear in the licence file
        Max = 0                                                 'Sets Max as 0
        NumberPart = 0                                          'Sets Number part as 0
        Letters = Mid(StudID.SelectedItem(), 1, 3).ToUpper      'Set letters as letters from student ID
        FileOpen(2, "Licence.dat", OpenMode.Random, , , Len(LicenceRecord)) 'Opens Licence file
        Do While Not EOF(2)                                     'Repeats until end of licence file
            FileGet(2, LicenceRecord)                           'Reads licence record
            If Letters = Mid(LicenceRecord.LicenceID, 1, 3) Then    'If letters appear in licence file
                NumberPart = CInt(Mid(LicenceRecord.LicenceID, 4, 4))   'Sets number part as unmber part of licece record if letters match
                If NumberPart > Max Then                        'If number part greater tha max
                    Max = NumberPart                            'Sets Max as number part
                End If
            End If
        Loop
        FileClose(2)                                            'Closes licence file
        Max = Max + 1                                           'Adds 1 to Max
        LicID = Letters & Format(Max, "0000")                   'Generates Licence ID
        Return LicID                                            'Returns Licence ID to main program
    End Function
    Public Function ValidateLicence(ByVal Grade As TextBox) As Boolean      'Declares a function to validate user entry
        Dim Valid As Boolean                    'Declares a variable to help validate the user entry
        Valid = True                            'Sets Valid as false
        If Grade.Text = "" Then                 'If grade blank
            Valid = False                       'Set Valid as false
            MsgBox("Please enter the current grade of the Student") 'Displays error message
        End If
        Return Valid                            'Returns Valid to main programs
    End Function
End Module

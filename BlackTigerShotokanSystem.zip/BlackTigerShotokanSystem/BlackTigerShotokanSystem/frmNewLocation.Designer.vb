﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmNewLocation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtLocationID = New System.Windows.Forms.TextBox()
        Me.txtLocationName = New System.Windows.Forms.TextBox()
        Me.txtLocationAddress = New System.Windows.Forms.TextBox()
        Me.txtLocationPostCode = New System.Windows.Forms.TextBox()
        Me.btnSaveLocation = New System.Windows.Forms.Button()
        Me.btnNewLesson = New System.Windows.Forms.Button()
        Me.btnEditLocation = New System.Windows.Forms.Button()
        Me.lblLocationID = New System.Windows.Forms.Label()
        Me.lblLocationName = New System.Windows.Forms.Label()
        Me.lblLocationAddress = New System.Windows.Forms.Label()
        Me.lblLocationPostCode = New System.Windows.Forms.Label()
        Me.grpLocationDetails = New System.Windows.Forms.GroupBox()
        Me.grpLocationDetails.SuspendLayout()
        Me.SuspendLayout()
        '
        'txtLocationID
        '
        Me.txtLocationID.BackColor = System.Drawing.Color.Gainsboro
        Me.txtLocationID.Location = New System.Drawing.Point(146, 21)
        Me.txtLocationID.Name = "txtLocationID"
        Me.txtLocationID.Size = New System.Drawing.Size(145, 20)
        Me.txtLocationID.TabIndex = 4
        '
        'txtLocationName
        '
        Me.txtLocationName.BackColor = System.Drawing.Color.Gainsboro
        Me.txtLocationName.Location = New System.Drawing.Point(134, 13)
        Me.txtLocationName.Name = "txtLocationName"
        Me.txtLocationName.Size = New System.Drawing.Size(145, 20)
        Me.txtLocationName.TabIndex = 5
        '
        'txtLocationAddress
        '
        Me.txtLocationAddress.BackColor = System.Drawing.Color.Gainsboro
        Me.txtLocationAddress.Location = New System.Drawing.Point(134, 57)
        Me.txtLocationAddress.Name = "txtLocationAddress"
        Me.txtLocationAddress.Size = New System.Drawing.Size(145, 20)
        Me.txtLocationAddress.TabIndex = 6
        '
        'txtLocationPostCode
        '
        Me.txtLocationPostCode.BackColor = System.Drawing.Color.Gainsboro
        Me.txtLocationPostCode.Location = New System.Drawing.Point(134, 110)
        Me.txtLocationPostCode.Name = "txtLocationPostCode"
        Me.txtLocationPostCode.Size = New System.Drawing.Size(145, 20)
        Me.txtLocationPostCode.TabIndex = 7
        '
        'btnSaveLocation
        '
        Me.btnSaveLocation.BackColor = System.Drawing.Color.Red
        Me.btnSaveLocation.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnSaveLocation.Location = New System.Drawing.Point(27, 235)
        Me.btnSaveLocation.Name = "btnSaveLocation"
        Me.btnSaveLocation.Size = New System.Drawing.Size(87, 33)
        Me.btnSaveLocation.TabIndex = 8
        Me.btnSaveLocation.Text = "Save Location"
        Me.btnSaveLocation.UseVisualStyleBackColor = False
        '
        'btnNewLesson
        '
        Me.btnNewLesson.BackColor = System.Drawing.Color.Red
        Me.btnNewLesson.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnNewLesson.Location = New System.Drawing.Point(146, 235)
        Me.btnNewLesson.Name = "btnNewLesson"
        Me.btnNewLesson.Size = New System.Drawing.Size(88, 33)
        Me.btnNewLesson.TabIndex = 9
        Me.btnNewLesson.Text = "New Lesson"
        Me.btnNewLesson.UseVisualStyleBackColor = False
        '
        'btnEditLocation
        '
        Me.btnEditLocation.BackColor = System.Drawing.Color.Black
        Me.btnEditLocation.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnEditLocation.ForeColor = System.Drawing.Color.White
        Me.btnEditLocation.Location = New System.Drawing.Point(254, 235)
        Me.btnEditLocation.Name = "btnEditLocation"
        Me.btnEditLocation.Size = New System.Drawing.Size(87, 33)
        Me.btnEditLocation.TabIndex = 10
        Me.btnEditLocation.Text = "Edit Location"
        Me.btnEditLocation.UseVisualStyleBackColor = False
        '
        'lblLocationID
        '
        Me.lblLocationID.AutoSize = True
        Me.lblLocationID.Location = New System.Drawing.Point(24, 24)
        Me.lblLocationID.Name = "lblLocationID"
        Me.lblLocationID.Size = New System.Drawing.Size(62, 13)
        Me.lblLocationID.TabIndex = 0
        Me.lblLocationID.Text = "Location ID"
        '
        'lblLocationName
        '
        Me.lblLocationName.AutoSize = True
        Me.lblLocationName.Location = New System.Drawing.Point(12, 16)
        Me.lblLocationName.Name = "lblLocationName"
        Me.lblLocationName.Size = New System.Drawing.Size(35, 13)
        Me.lblLocationName.TabIndex = 1
        Me.lblLocationName.Text = "Name"
        '
        'lblLocationAddress
        '
        Me.lblLocationAddress.AutoSize = True
        Me.lblLocationAddress.Location = New System.Drawing.Point(12, 60)
        Me.lblLocationAddress.Name = "lblLocationAddress"
        Me.lblLocationAddress.Size = New System.Drawing.Size(45, 13)
        Me.lblLocationAddress.TabIndex = 2
        Me.lblLocationAddress.Text = "Address"
        '
        'lblLocationPostCode
        '
        Me.lblLocationPostCode.AutoSize = True
        Me.lblLocationPostCode.Location = New System.Drawing.Point(12, 113)
        Me.lblLocationPostCode.Name = "lblLocationPostCode"
        Me.lblLocationPostCode.Size = New System.Drawing.Size(56, 13)
        Me.lblLocationPostCode.TabIndex = 3
        Me.lblLocationPostCode.Text = "Post Code"
        '
        'grpLocationDetails
        '
        Me.grpLocationDetails.Controls.Add(Me.lblLocationAddress)
        Me.grpLocationDetails.Controls.Add(Me.lblLocationName)
        Me.grpLocationDetails.Controls.Add(Me.lblLocationPostCode)
        Me.grpLocationDetails.Controls.Add(Me.txtLocationName)
        Me.grpLocationDetails.Controls.Add(Me.txtLocationPostCode)
        Me.grpLocationDetails.Controls.Add(Me.txtLocationAddress)
        Me.grpLocationDetails.Location = New System.Drawing.Point(12, 62)
        Me.grpLocationDetails.Name = "grpLocationDetails"
        Me.grpLocationDetails.Size = New System.Drawing.Size(285, 141)
        Me.grpLocationDetails.TabIndex = 11
        Me.grpLocationDetails.TabStop = False
        Me.grpLocationDetails.Text = "Location Details"
        '
        'frmNewLocation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(353, 293)
        Me.Controls.Add(Me.btnEditLocation)
        Me.Controls.Add(Me.btnNewLesson)
        Me.Controls.Add(Me.btnSaveLocation)
        Me.Controls.Add(Me.txtLocationID)
        Me.Controls.Add(Me.lblLocationID)
        Me.Controls.Add(Me.grpLocationDetails)
        Me.Name = "frmNewLocation"
        Me.Text = "New Location"
        Me.grpLocationDetails.ResumeLayout(False)
        Me.grpLocationDetails.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtLocationID As System.Windows.Forms.TextBox
    Friend WithEvents txtLocationName As System.Windows.Forms.TextBox
    Friend WithEvents txtLocationAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtLocationPostCode As System.Windows.Forms.TextBox
    Friend WithEvents btnSaveLocation As System.Windows.Forms.Button
    Friend WithEvents btnNewLesson As System.Windows.Forms.Button
    Friend WithEvents btnEditLocation As System.Windows.Forms.Button
    Friend WithEvents lblLocationID As System.Windows.Forms.Label
    Friend WithEvents lblLocationName As System.Windows.Forms.Label
    Friend WithEvents lblLocationAddress As System.Windows.Forms.Label
    Friend WithEvents lblLocationPostCode As System.Windows.Forms.Label
    Friend WithEvents grpLocationDetails As System.Windows.Forms.GroupBox
End Class

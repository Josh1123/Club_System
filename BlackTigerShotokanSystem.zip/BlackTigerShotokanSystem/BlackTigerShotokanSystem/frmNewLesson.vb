﻿Public Class frmNewLesson

    Private Sub frmNewLesson_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim LocationRecord As LocationType                                          'Declares a variable to store the record structure for my locations
        Dim RecordPosition As Integer                                               'Declares a variable to calculate and save the record position of my locations
        RecordPosition = 0                                                          'Sets record position as 0
        FileOpen(4, "Location.dat", OpenMode.Random, , , Len(LocationRecord))       'Opens location file
        Do While Not EOF(4)                                                         'Repeats until the end of location file
            RecordPosition = RecordPosition + 1                                     'Adds 1 to Record Position 
            FileGet(4, LocationRecord, RecordPosition)                              'Reads location record from location file at record position
            cmbLocationID.Items.Add(LocationRecord.LocationID)                      'Adds location Id form location record to combo box
        Loop                                                                        'Ends loop
        FileClose(4)                                                                'Closes location file
    End Sub

    Private Sub btnSaveLesson_Click(sender As Object, e As EventArgs) Handles btnSaveLesson.Click
        Dim LessonRecord As LessonType                                              'Declares a variable to store the record structure for my lessons
        Dim AllValid As Boolean                                                     'Declares a variable to help validate my lessons
        Dim LastRecordPosition As Integer                                           'Declares a varaible to find the position of the last record in the file
        LastRecordPosition = 0                                                      'Sets last record position as 0
        FileOpen(6, "Lesson.dat", OpenMode.Random, , , Len(LessonRecord))           'Opens lesson file
        AllValid = ValidateLesson(txtTimeStart1, txtTimeStart2, txtTimeFinish1, txtTimeFinish2) 'Calls the public Function validate Lesson
        If AllValid Then                                                            'If user entry passes validation
            With LessonRecord                                                       'Saves typing in LessonRecord.etc
                .LocationID = cmbLocationID.SelectedItem                            'Adds details from form to lesson record
                .Session1 = txtSession1.Text                                        'Adds details from form to lesson record
                .Session2 = txtSession2.Text                                        'Adds details from form to lesson record
                .TimeStart1 = txtTimeStart1.Text                                    'Adds details from form to lesson record
                .TimeStart2 = txtTimeStart2.Text                                    'Adds details from form to lesson record
                .TimeFinish1 = txtTimeFinish1.Text                                  'Adds details from form to lesson record
                .TimeFinish2 = txtTimeFinish2.Text                                  'Adds details from form to lesson record
            End With
            LastRecordPosition = LOF(6) / Len(LessonRecord)                         'Finds the location of the lat record in the lesson file
            LastRecordPosition = LastRecordPosition + 1                             'Adds 1 to last record position to find the best place to save the new record
            MsgBox("Lesson has been Saved")                                         'Deisplays a message saynig that the record has been saved
            FilePut(6, LessonRecord, LastRecordPosition)                            'Writes lesson record to lesson file at last record position
        End If
        FileClose(6)                                                                'Closes Lesson File
    End Sub
End Class
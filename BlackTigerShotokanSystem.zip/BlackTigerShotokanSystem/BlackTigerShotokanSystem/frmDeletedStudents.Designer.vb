﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDeletedStudents
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnPerDelete = New System.Windows.Forms.Button()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.lblMobileNumber = New System.Windows.Forms.Label()
        Me.lblTeleNumber = New System.Windows.Forms.Label()
        Me.lblPostCode = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblDateOfBirth = New System.Windows.Forms.Label()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.lblStudentID = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtMobileNumber = New System.Windows.Forms.TextBox()
        Me.txtTeleNumber = New System.Windows.Forms.TextBox()
        Me.txtPostCode = New System.Windows.Forms.TextBox()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.txtDateOfBirth = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.btnReAddStudent = New System.Windows.Forms.Button()
        Me.cmbDeletedStudents = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'btnPerDelete
        '
        Me.btnPerDelete.BackColor = System.Drawing.Color.Black
        Me.btnPerDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnPerDelete.ForeColor = System.Drawing.Color.White
        Me.btnPerDelete.Location = New System.Drawing.Point(171, 443)
        Me.btnPerDelete.Name = "btnPerDelete"
        Me.btnPerDelete.Size = New System.Drawing.Size(113, 56)
        Me.btnPerDelete.TabIndex = 67
        Me.btnPerDelete.Text = "Delete Student"
        Me.btnPerDelete.UseVisualStyleBackColor = False
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Location = New System.Drawing.Point(12, 410)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(32, 13)
        Me.lblEmail.TabIndex = 65
        Me.lblEmail.Text = "Email"
        '
        'lblMobileNumber
        '
        Me.lblMobileNumber.AutoSize = True
        Me.lblMobileNumber.Location = New System.Drawing.Point(12, 373)
        Me.lblMobileNumber.Name = "lblMobileNumber"
        Me.lblMobileNumber.Size = New System.Drawing.Size(78, 13)
        Me.lblMobileNumber.TabIndex = 64
        Me.lblMobileNumber.Text = "Mobile Number"
        '
        'lblTeleNumber
        '
        Me.lblTeleNumber.AutoSize = True
        Me.lblTeleNumber.Location = New System.Drawing.Point(12, 330)
        Me.lblTeleNumber.Name = "lblTeleNumber"
        Me.lblTeleNumber.Size = New System.Drawing.Size(98, 13)
        Me.lblTeleNumber.TabIndex = 63
        Me.lblTeleNumber.Text = "Telephone Number"
        '
        'lblPostCode
        '
        Me.lblPostCode.AutoSize = True
        Me.lblPostCode.Location = New System.Drawing.Point(12, 260)
        Me.lblPostCode.Name = "lblPostCode"
        Me.lblPostCode.Size = New System.Drawing.Size(56, 13)
        Me.lblPostCode.TabIndex = 62
        Me.lblPostCode.Text = "Post Code"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(12, 213)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(45, 13)
        Me.lblAddress.TabIndex = 61
        Me.lblAddress.Text = "Address"
        '
        'lblDateOfBirth
        '
        Me.lblDateOfBirth.AutoSize = True
        Me.lblDateOfBirth.Location = New System.Drawing.Point(12, 121)
        Me.lblDateOfBirth.Name = "lblDateOfBirth"
        Me.lblDateOfBirth.Size = New System.Drawing.Size(66, 13)
        Me.lblDateOfBirth.TabIndex = 60
        Me.lblDateOfBirth.Text = "Date of Birth"
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.Location = New System.Drawing.Point(12, 84)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(58, 13)
        Me.lblLastName.TabIndex = 59
        Me.lblLastName.Text = "Last Name"
        '
        'lblFirstName
        '
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.Location = New System.Drawing.Point(11, 53)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(57, 13)
        Me.lblFirstName.TabIndex = 58
        Me.lblFirstName.Text = "First Name"
        '
        'lblStudentID
        '
        Me.lblStudentID.AutoSize = True
        Me.lblStudentID.Location = New System.Drawing.Point(12, 19)
        Me.lblStudentID.Name = "lblStudentID"
        Me.lblStudentID.Size = New System.Drawing.Size(58, 13)
        Me.lblStudentID.TabIndex = 57
        Me.lblStudentID.Text = "Student ID"
        '
        'txtEmail
        '
        Me.txtEmail.BackColor = System.Drawing.Color.Gainsboro
        Me.txtEmail.Location = New System.Drawing.Point(171, 407)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(100, 20)
        Me.txtEmail.TabIndex = 56
        '
        'txtMobileNumber
        '
        Me.txtMobileNumber.BackColor = System.Drawing.Color.Gainsboro
        Me.txtMobileNumber.Location = New System.Drawing.Point(171, 370)
        Me.txtMobileNumber.Name = "txtMobileNumber"
        Me.txtMobileNumber.Size = New System.Drawing.Size(100, 20)
        Me.txtMobileNumber.TabIndex = 55
        '
        'txtTeleNumber
        '
        Me.txtTeleNumber.BackColor = System.Drawing.Color.Gainsboro
        Me.txtTeleNumber.Location = New System.Drawing.Point(171, 327)
        Me.txtTeleNumber.Name = "txtTeleNumber"
        Me.txtTeleNumber.Size = New System.Drawing.Size(100, 20)
        Me.txtTeleNumber.TabIndex = 54
        '
        'txtPostCode
        '
        Me.txtPostCode.BackColor = System.Drawing.Color.Gainsboro
        Me.txtPostCode.Location = New System.Drawing.Point(171, 253)
        Me.txtPostCode.Name = "txtPostCode"
        Me.txtPostCode.Size = New System.Drawing.Size(100, 20)
        Me.txtPostCode.TabIndex = 53
        '
        'txtAddress
        '
        Me.txtAddress.BackColor = System.Drawing.Color.Gainsboro
        Me.txtAddress.Location = New System.Drawing.Point(171, 210)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(100, 20)
        Me.txtAddress.TabIndex = 52
        '
        'txtDateOfBirth
        '
        Me.txtDateOfBirth.BackColor = System.Drawing.Color.Gainsboro
        Me.txtDateOfBirth.Location = New System.Drawing.Point(171, 118)
        Me.txtDateOfBirth.Name = "txtDateOfBirth"
        Me.txtDateOfBirth.Size = New System.Drawing.Size(100, 20)
        Me.txtDateOfBirth.TabIndex = 51
        '
        'txtLastName
        '
        Me.txtLastName.BackColor = System.Drawing.Color.Gainsboro
        Me.txtLastName.Location = New System.Drawing.Point(171, 81)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(100, 20)
        Me.txtLastName.TabIndex = 50
        '
        'txtFirstName
        '
        Me.txtFirstName.BackColor = System.Drawing.Color.Gainsboro
        Me.txtFirstName.Location = New System.Drawing.Point(171, 50)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(100, 20)
        Me.txtFirstName.TabIndex = 49
        '
        'btnReAddStudent
        '
        Me.btnReAddStudent.BackColor = System.Drawing.Color.Red
        Me.btnReAddStudent.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnReAddStudent.Location = New System.Drawing.Point(15, 443)
        Me.btnReAddStudent.Name = "btnReAddStudent"
        Me.btnReAddStudent.Size = New System.Drawing.Size(113, 56)
        Me.btnReAddStudent.TabIndex = 48
        Me.btnReAddStudent.Text = "Re-Add Student"
        Me.btnReAddStudent.UseVisualStyleBackColor = False
        '
        'cmbDeletedStudents
        '
        Me.cmbDeletedStudents.BackColor = System.Drawing.Color.Gainsboro
        Me.cmbDeletedStudents.FormattingEnabled = True
        Me.cmbDeletedStudents.Location = New System.Drawing.Point(150, 12)
        Me.cmbDeletedStudents.Name = "cmbDeletedStudents"
        Me.cmbDeletedStudents.Size = New System.Drawing.Size(121, 21)
        Me.cmbDeletedStudents.TabIndex = 68
        '
        'frmDeletedStudents
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(309, 524)
        Me.Controls.Add(Me.cmbDeletedStudents)
        Me.Controls.Add(Me.btnPerDelete)
        Me.Controls.Add(Me.lblEmail)
        Me.Controls.Add(Me.lblMobileNumber)
        Me.Controls.Add(Me.lblTeleNumber)
        Me.Controls.Add(Me.lblPostCode)
        Me.Controls.Add(Me.lblAddress)
        Me.Controls.Add(Me.lblDateOfBirth)
        Me.Controls.Add(Me.lblLastName)
        Me.Controls.Add(Me.lblFirstName)
        Me.Controls.Add(Me.lblStudentID)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.txtMobileNumber)
        Me.Controls.Add(Me.txtTeleNumber)
        Me.Controls.Add(Me.txtPostCode)
        Me.Controls.Add(Me.txtAddress)
        Me.Controls.Add(Me.txtDateOfBirth)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.btnReAddStudent)
        Me.Name = "frmDeletedStudents"
        Me.Text = "frmDeletedStudents"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnPerDelete As System.Windows.Forms.Button
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents lblMobileNumber As System.Windows.Forms.Label
    Friend WithEvents lblTeleNumber As System.Windows.Forms.Label
    Friend WithEvents lblPostCode As System.Windows.Forms.Label
    Friend WithEvents lblAddress As System.Windows.Forms.Label
    Friend WithEvents lblDateOfBirth As System.Windows.Forms.Label
    Friend WithEvents lblLastName As System.Windows.Forms.Label
    Friend WithEvents lblFirstName As System.Windows.Forms.Label
    Friend WithEvents lblStudentID As System.Windows.Forms.Label
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtMobileNumber As System.Windows.Forms.TextBox
    Friend WithEvents txtTeleNumber As System.Windows.Forms.TextBox
    Friend WithEvents txtPostCode As System.Windows.Forms.TextBox
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtDateOfBirth As System.Windows.Forms.TextBox
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents btnReAddStudent As System.Windows.Forms.Button
    Friend WithEvents cmbDeletedStudents As System.Windows.Forms.ComboBox
End Class

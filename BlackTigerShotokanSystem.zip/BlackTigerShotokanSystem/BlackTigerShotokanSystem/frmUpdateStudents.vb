﻿Public Class frmUpdateStudents

    Private Sub frmUpdateStudents_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim StudentRecord As StudentType                    'Declares a variable to store the record structure of my students
        Dim RecordPosition As Integer                       'Declares a variable to calculate and store the location of the studnet to be found at
        RecordPosition = 0                                  'Sets Record position as 0

        lblGenerateID.Enabled = False                       'Disables User entry
        txtFirstName.Enabled = False                        'Disables User entry
        txtLastName.Enabled = False                         'Disables User entry

        FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord)) 'Opens student file
        Do While Not EOF(1)                                                 'Repeats until end of student file
            RecordPosition = RecordPosition + 1                             'Adds 1 to record position
            FileGet(1, StudentRecord, RecordPosition)                       'Reads student record from student file at record position
            If frmListStudent.lstListStudents.SelectedItem.Contains(StudentRecord.StudentID) Then   'If student Id from list student form contains student Id from student record
                With StudentRecord                                          'Saves having to type StudentRecord.etc
                    lblGenerateID.Text = .StudentID.Trim                    'Dispalys details from student record to the form
                    txtFirstName.Text = .FirstName.Trim                     'Dispalys details from student record to the form                 
                    txtLastName.Text = .LastName.Trim                       'Dispalys details from student record to the form
                    txtDateOfBirth.Text = FormatDateTime(.DateOfBirth)      'Dispalys details from student record to the form
                    txtAddress.Text = .Address.Trim                         'Dispalys details from student record to the form
                    txtPostCode.Text = .PostCode.Trim                       'Dispalys details from student record to the form
                    txtTeleNumber.Text = .HomeNumber.Trim                   'Dispalys details from student record to the form
                    txtMobileNumber.Text = .MobileNumber.Trim               'Dispalys details from student record to the form
                    txtEmail.Text = .Email.Trim                             'Dispalys details from student record to the form
                End With
            End If
        Loop                                                                'Ends loop
        FileClose(1)                                                        'Closes student file
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim StudentRecord As StudentType                    'Declares a variable to store the record structure of my students
        Dim RecordPosition As Integer                       'Declares a variable to calculate and store the location of the studnet to be found at
        Dim StudentFound As Boolean                         'Declares a variable to see if a student has been found
        Dim AllValid As Boolean                             'Declares a varaible to help validate user entry
        AllValid = ValidateStudent(txtFirstName, txtLastName, txtDateOfBirth.Text, txtAddress, txtPostCode, txtMobileNumber, txtEmail)  'Calls the public function Validate Student
        StudentFound = False                                'Sets Student Found as False
        RecordPosition = 0                                  'Sets Record position as 0
        FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord)) 'Opens student file
        Do While Not EOF(1) And Not StudentFound            'Repeat until end of student file and Student found
            RecordPosition = RecordPosition + 1             'Adds 1 to record position
            FileGet(1, StudentRecord, RecordPosition)       'Reads student record from student file at record position
            If lblGenerateID.Text = StudentRecord.StudentID Then    'If Id from student record = Student ID displayed
                StudentFound = True                         'Student found = true
            End If
        Loop                                                'End loop
        If StudentFound Then                                'If student found
            If AllValid Then                                'If user entry passes validation
                With StudentRecord                          'Saves having to type StudentRecord.etc
                    .DateOfBirth = txtDateOfBirth.Text      'Adds details from form to student record
                    .Address = txtAddress.Text              'Adds details from form to student record
                    .PostCode = txtPostCode.Text            'Adds details from form to student record
                    .HomeNumber = txtTeleNumber.Text        'Adds details from form to student record
                    .MobileNumber = txtMobileNumber.Text    'Adds details from form to student record
                    .Email = txtEmail.Text                  'Adds details from form to student record
                End With
                FilePut(1, StudentRecord, RecordPosition)   'Writes student record to student file at rceord position
                MsgBox("Student Record has been Updated")   'Displays message saying that the student rceord has been updated
            End If
        Else
            MsgBox("Student Not Found in Student File")     'Displays error message saying teh student has not been found
        End If
        FileClose(1)                                        'Closes Student file
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim StudentRecord As StudentType                    'Declares a variable to store the record structure of my students
        Dim RecordPosition As Integer                       'Declares a varaible to calculate and store the location of the studnet to be found at
        Dim StudentFound As Boolean                         'Declares a variable to see if a student has been found
        StudentFound = False                                'Sets Student Found as False
        RecordPosition = 0                                  'Sets Record position as 0
        FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord)) 'Opens Student file
        Do While Not EOF(1) And Not StudentFound            'Repeat until end of student file and Student found
            RecordPosition = RecordPosition + 1             'Adds 1 to record position
            FileGet(1, StudentRecord, RecordPosition)       'Reads student record from student file at record position
            If lblGenerateID.Text = StudentRecord.StudentID Then    'If Id from student record = Student ID displayed
                StudentFound = True                         'Student found = true
            End If
        Loop                                                'End loop
        If StudentFound Then                                'If Student found
            With StudentRecord                              'Saves having to type StudentRecord.etc
                .Deleted = True                             'Sets StudentRecord.Deleted as true
                FilePut(1, StudentRecord, RecordPosition)   'Writes student record to student file at rceord position
                MsgBox("Record has been Deleted")           'Disaplys message saying the record has been deleted
            End With
        Else
            MsgBox("Student Record Not Found in Student File")  'Dispalys error message saying teh student has not been found
        End If
        FileClose(1)                                        'Closes Student file
    End Sub
End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.StudentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewStudentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ListStudentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateAndDeleteStudentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LicenseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewLicenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewLicenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LocationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewLocationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditAndDeleteLocationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LessonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewLessonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UpdateAndDeleteLessonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AttendanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AttendLessonToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewAttendanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lstExpiredLicences = New System.Windows.Forms.ListBox()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentToolStripMenuItem, Me.LicenseToolStripMenuItem, Me.LocationToolStripMenuItem, Me.LessonToolStripMenuItem, Me.AttendanceToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1279, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'StudentToolStripMenuItem
        '
        Me.StudentToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewStudentToolStripMenuItem, Me.ListStudentToolStripMenuItem, Me.UpdateAndDeleteStudentsToolStripMenuItem})
        Me.StudentToolStripMenuItem.Name = "StudentToolStripMenuItem"
        Me.StudentToolStripMenuItem.Size = New System.Drawing.Size(60, 20)
        Me.StudentToolStripMenuItem.Text = "Student"
        '
        'NewStudentToolStripMenuItem
        '
        Me.NewStudentToolStripMenuItem.Name = "NewStudentToolStripMenuItem"
        Me.NewStudentToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.NewStudentToolStripMenuItem.Text = "New Student"
        '
        'ListStudentToolStripMenuItem
        '
        Me.ListStudentToolStripMenuItem.Name = "ListStudentToolStripMenuItem"
        Me.ListStudentToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.ListStudentToolStripMenuItem.Text = "List Student"
        '
        'UpdateAndDeleteStudentsToolStripMenuItem
        '
        Me.UpdateAndDeleteStudentsToolStripMenuItem.Name = "UpdateAndDeleteStudentsToolStripMenuItem"
        Me.UpdateAndDeleteStudentsToolStripMenuItem.Size = New System.Drawing.Size(166, 22)
        Me.UpdateAndDeleteStudentsToolStripMenuItem.Text = " Deleted Students"
        '
        'LicenseToolStripMenuItem
        '
        Me.LicenseToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewLicenceToolStripMenuItem, Me.ViewLicenceToolStripMenuItem})
        Me.LicenseToolStripMenuItem.Name = "LicenseToolStripMenuItem"
        Me.LicenseToolStripMenuItem.Size = New System.Drawing.Size(59, 20)
        Me.LicenseToolStripMenuItem.Text = "Licence"
        '
        'NewLicenceToolStripMenuItem
        '
        Me.NewLicenceToolStripMenuItem.Name = "NewLicenceToolStripMenuItem"
        Me.NewLicenceToolStripMenuItem.Size = New System.Drawing.Size(142, 22)
        Me.NewLicenceToolStripMenuItem.Text = "New Licence"
        '
        'ViewLicenceToolStripMenuItem
        '
        Me.ViewLicenceToolStripMenuItem.Name = "ViewLicenceToolStripMenuItem"
        Me.ViewLicenceToolStripMenuItem.Size = New System.Drawing.Size(142, 22)
        Me.ViewLicenceToolStripMenuItem.Text = "View Licence"
        '
        'LocationToolStripMenuItem
        '
        Me.LocationToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewLocationToolStripMenuItem, Me.EditAndDeleteLocationToolStripMenuItem})
        Me.LocationToolStripMenuItem.Name = "LocationToolStripMenuItem"
        Me.LocationToolStripMenuItem.Size = New System.Drawing.Size(65, 20)
        Me.LocationToolStripMenuItem.Text = "Location"
        '
        'NewLocationToolStripMenuItem
        '
        Me.NewLocationToolStripMenuItem.Name = "NewLocationToolStripMenuItem"
        Me.NewLocationToolStripMenuItem.Size = New System.Drawing.Size(204, 22)
        Me.NewLocationToolStripMenuItem.Text = "New Location"
        '
        'EditAndDeleteLocationToolStripMenuItem
        '
        Me.EditAndDeleteLocationToolStripMenuItem.Name = "EditAndDeleteLocationToolStripMenuItem"
        Me.EditAndDeleteLocationToolStripMenuItem.Size = New System.Drawing.Size(204, 22)
        Me.EditAndDeleteLocationToolStripMenuItem.Text = "Edit And Delete Location"
        '
        'LessonToolStripMenuItem
        '
        Me.LessonToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewLessonToolStripMenuItem, Me.UpdateAndDeleteLessonToolStripMenuItem})
        Me.LessonToolStripMenuItem.Name = "LessonToolStripMenuItem"
        Me.LessonToolStripMenuItem.Size = New System.Drawing.Size(55, 20)
        Me.LessonToolStripMenuItem.Text = "Lesson"
        '
        'NewLessonToolStripMenuItem
        '
        Me.NewLessonToolStripMenuItem.Name = "NewLessonToolStripMenuItem"
        Me.NewLessonToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.NewLessonToolStripMenuItem.Text = "New Lesson"
        '
        'UpdateAndDeleteLessonToolStripMenuItem
        '
        Me.UpdateAndDeleteLessonToolStripMenuItem.Name = "UpdateAndDeleteLessonToolStripMenuItem"
        Me.UpdateAndDeleteLessonToolStripMenuItem.Size = New System.Drawing.Size(209, 22)
        Me.UpdateAndDeleteLessonToolStripMenuItem.Text = "Update And DeleteLesson"
        '
        'AttendanceToolStripMenuItem
        '
        Me.AttendanceToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AttendLessonToolStripMenuItem, Me.ViewAttendanceToolStripMenuItem})
        Me.AttendanceToolStripMenuItem.Name = "AttendanceToolStripMenuItem"
        Me.AttendanceToolStripMenuItem.Size = New System.Drawing.Size(80, 20)
        Me.AttendanceToolStripMenuItem.Text = "Attendance"
        '
        'AttendLessonToolStripMenuItem
        '
        Me.AttendLessonToolStripMenuItem.Name = "AttendLessonToolStripMenuItem"
        Me.AttendLessonToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.AttendLessonToolStripMenuItem.Text = "Attend Lesson"
        '
        'ViewAttendanceToolStripMenuItem
        '
        Me.ViewAttendanceToolStripMenuItem.Name = "ViewAttendanceToolStripMenuItem"
        Me.ViewAttendanceToolStripMenuItem.Size = New System.Drawing.Size(163, 22)
        Me.ViewAttendanceToolStripMenuItem.Text = "View Attendance"
        '
        'lstExpiredLicences
        '
        Me.lstExpiredLicences.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstExpiredLicences.FormattingEnabled = True
        Me.lstExpiredLicences.ItemHeight = 14
        Me.lstExpiredLicences.Location = New System.Drawing.Point(12, 204)
        Me.lstExpiredLicences.Name = "lstExpiredLicences"
        Me.lstExpiredLicences.Size = New System.Drawing.Size(1255, 116)
        Me.lstExpiredLicences.TabIndex = 1
        '
        'frmMainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1279, 337)
        Me.Controls.Add(Me.lstExpiredLicences)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frmMainMenu"
        Me.Text = "Main Menu"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents StudentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LicenseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LocationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LessonToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AttendanceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lstExpiredLicences As System.Windows.Forms.ListBox
    Friend WithEvents NewStudentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ListStudentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateAndDeleteStudentsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewLicenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewLicenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewLocationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditAndDeleteLocationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewLessonToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateAndDeleteLessonToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AttendLessonToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewAttendanceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class

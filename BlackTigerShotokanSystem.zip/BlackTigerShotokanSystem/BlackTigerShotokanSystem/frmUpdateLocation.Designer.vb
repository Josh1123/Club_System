﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmUpdateLocation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnEditLesson = New System.Windows.Forms.Button()
        Me.btnUpdateLocation = New System.Windows.Forms.Button()
        Me.lblLocationID = New System.Windows.Forms.Label()
        Me.grpLocationDetails = New System.Windows.Forms.GroupBox()
        Me.lblLocationAddress = New System.Windows.Forms.Label()
        Me.lblLocationName = New System.Windows.Forms.Label()
        Me.lblLocationPostCode = New System.Windows.Forms.Label()
        Me.txtLocationName = New System.Windows.Forms.TextBox()
        Me.txtLocationPostCode = New System.Windows.Forms.TextBox()
        Me.txtLocationAddress = New System.Windows.Forms.TextBox()
        Me.btnDeleteLocation = New System.Windows.Forms.Button()
        Me.cmbLocationID = New System.Windows.Forms.ComboBox()
        Me.grpLocationDetails.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnEditLesson
        '
        Me.btnEditLesson.BackColor = System.Drawing.Color.Black
        Me.btnEditLesson.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnEditLesson.ForeColor = System.Drawing.Color.White
        Me.btnEditLesson.Location = New System.Drawing.Point(252, 220)
        Me.btnEditLesson.Name = "btnEditLesson"
        Me.btnEditLesson.Size = New System.Drawing.Size(87, 41)
        Me.btnEditLesson.TabIndex = 16
        Me.btnEditLesson.Text = "Edit Lesson"
        Me.btnEditLesson.UseVisualStyleBackColor = False
        '
        'btnUpdateLocation
        '
        Me.btnUpdateLocation.BackColor = System.Drawing.Color.Red
        Me.btnUpdateLocation.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnUpdateLocation.Location = New System.Drawing.Point(25, 220)
        Me.btnUpdateLocation.Name = "btnUpdateLocation"
        Me.btnUpdateLocation.Size = New System.Drawing.Size(87, 41)
        Me.btnUpdateLocation.TabIndex = 14
        Me.btnUpdateLocation.Text = "Update Location"
        Me.btnUpdateLocation.UseVisualStyleBackColor = False
        '
        'lblLocationID
        '
        Me.lblLocationID.AutoSize = True
        Me.lblLocationID.Location = New System.Drawing.Point(22, 9)
        Me.lblLocationID.Name = "lblLocationID"
        Me.lblLocationID.Size = New System.Drawing.Size(62, 13)
        Me.lblLocationID.TabIndex = 12
        Me.lblLocationID.Text = "Location ID"
        '
        'grpLocationDetails
        '
        Me.grpLocationDetails.Controls.Add(Me.lblLocationAddress)
        Me.grpLocationDetails.Controls.Add(Me.lblLocationName)
        Me.grpLocationDetails.Controls.Add(Me.lblLocationPostCode)
        Me.grpLocationDetails.Controls.Add(Me.txtLocationName)
        Me.grpLocationDetails.Controls.Add(Me.txtLocationPostCode)
        Me.grpLocationDetails.Controls.Add(Me.txtLocationAddress)
        Me.grpLocationDetails.Location = New System.Drawing.Point(10, 47)
        Me.grpLocationDetails.Name = "grpLocationDetails"
        Me.grpLocationDetails.Size = New System.Drawing.Size(285, 141)
        Me.grpLocationDetails.TabIndex = 17
        Me.grpLocationDetails.TabStop = False
        Me.grpLocationDetails.Text = "Location Details"
        '
        'lblLocationAddress
        '
        Me.lblLocationAddress.AutoSize = True
        Me.lblLocationAddress.Location = New System.Drawing.Point(12, 60)
        Me.lblLocationAddress.Name = "lblLocationAddress"
        Me.lblLocationAddress.Size = New System.Drawing.Size(45, 13)
        Me.lblLocationAddress.TabIndex = 2
        Me.lblLocationAddress.Text = "Address"
        '
        'lblLocationName
        '
        Me.lblLocationName.AutoSize = True
        Me.lblLocationName.Location = New System.Drawing.Point(12, 16)
        Me.lblLocationName.Name = "lblLocationName"
        Me.lblLocationName.Size = New System.Drawing.Size(35, 13)
        Me.lblLocationName.TabIndex = 1
        Me.lblLocationName.Text = "Name"
        '
        'lblLocationPostCode
        '
        Me.lblLocationPostCode.AutoSize = True
        Me.lblLocationPostCode.Location = New System.Drawing.Point(12, 113)
        Me.lblLocationPostCode.Name = "lblLocationPostCode"
        Me.lblLocationPostCode.Size = New System.Drawing.Size(56, 13)
        Me.lblLocationPostCode.TabIndex = 3
        Me.lblLocationPostCode.Text = "Post Code"
        '
        'txtLocationName
        '
        Me.txtLocationName.BackColor = System.Drawing.Color.Gainsboro
        Me.txtLocationName.Location = New System.Drawing.Point(116, 13)
        Me.txtLocationName.Name = "txtLocationName"
        Me.txtLocationName.Size = New System.Drawing.Size(163, 20)
        Me.txtLocationName.TabIndex = 5
        '
        'txtLocationPostCode
        '
        Me.txtLocationPostCode.BackColor = System.Drawing.Color.Gainsboro
        Me.txtLocationPostCode.Location = New System.Drawing.Point(116, 110)
        Me.txtLocationPostCode.Name = "txtLocationPostCode"
        Me.txtLocationPostCode.Size = New System.Drawing.Size(163, 20)
        Me.txtLocationPostCode.TabIndex = 7
        '
        'txtLocationAddress
        '
        Me.txtLocationAddress.BackColor = System.Drawing.Color.Gainsboro
        Me.txtLocationAddress.Location = New System.Drawing.Point(116, 57)
        Me.txtLocationAddress.Name = "txtLocationAddress"
        Me.txtLocationAddress.Size = New System.Drawing.Size(163, 20)
        Me.txtLocationAddress.TabIndex = 6
        '
        'btnDeleteLocation
        '
        Me.btnDeleteLocation.BackColor = System.Drawing.Color.Black
        Me.btnDeleteLocation.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnDeleteLocation.ForeColor = System.Drawing.Color.White
        Me.btnDeleteLocation.Location = New System.Drawing.Point(144, 220)
        Me.btnDeleteLocation.Name = "btnDeleteLocation"
        Me.btnDeleteLocation.Size = New System.Drawing.Size(87, 41)
        Me.btnDeleteLocation.TabIndex = 18
        Me.btnDeleteLocation.Text = "Delete Location"
        Me.btnDeleteLocation.UseVisualStyleBackColor = False
        '
        'cmbLocationID
        '
        Me.cmbLocationID.BackColor = System.Drawing.Color.Gainsboro
        Me.cmbLocationID.FormattingEnabled = True
        Me.cmbLocationID.Location = New System.Drawing.Point(144, 12)
        Me.cmbLocationID.Name = "cmbLocationID"
        Me.cmbLocationID.Size = New System.Drawing.Size(145, 21)
        Me.cmbLocationID.TabIndex = 19
        '
        'frmUpdateLocation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(352, 273)
        Me.Controls.Add(Me.cmbLocationID)
        Me.Controls.Add(Me.btnDeleteLocation)
        Me.Controls.Add(Me.btnEditLesson)
        Me.Controls.Add(Me.btnUpdateLocation)
        Me.Controls.Add(Me.lblLocationID)
        Me.Controls.Add(Me.grpLocationDetails)
        Me.Name = "frmUpdateLocation"
        Me.Text = "Update Location"
        Me.grpLocationDetails.ResumeLayout(False)
        Me.grpLocationDetails.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnEditLesson As System.Windows.Forms.Button
    Friend WithEvents btnUpdateLocation As System.Windows.Forms.Button
    Friend WithEvents lblLocationID As System.Windows.Forms.Label
    Friend WithEvents grpLocationDetails As System.Windows.Forms.GroupBox
    Friend WithEvents lblLocationAddress As System.Windows.Forms.Label
    Friend WithEvents lblLocationName As System.Windows.Forms.Label
    Friend WithEvents lblLocationPostCode As System.Windows.Forms.Label
    Friend WithEvents txtLocationName As System.Windows.Forms.TextBox
    Friend WithEvents txtLocationPostCode As System.Windows.Forms.TextBox
    Friend WithEvents txtLocationAddress As System.Windows.Forms.TextBox
    Friend WithEvents btnDeleteLocation As System.Windows.Forms.Button
    Friend WithEvents cmbLocationID As System.Windows.Forms.ComboBox
End Class

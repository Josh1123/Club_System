﻿Public Class frmNewLocation

    Private Sub btnEditLocation_Click(sender As Object, e As EventArgs) Handles btnEditLocation.Click
        frmUpdateLocation.Show()                                    'Displays Update location form
    End Sub

    Private Sub btnSaveLocation_Click(sender As Object, e As EventArgs) Handles btnSaveLocation.Click
        Dim LocationRecord As LocationType                          'Declares a variable to save the record structure for my locations
        Dim LastRecordPosition As Integer                           'Declares a variable to calculate and store the position of the last record in file
        Dim AllValid As Boolean                                     'Declares a varaible to help validate user entry
        AllValid = ValidateLocation(txtLocationID.Text, txtLocationName, txtLocationAddress, txtLocationPostCode)   'Calls public function Validate Location
        If AllValid Then                                            'If user entry passes user entry
            FileOpen(4, "Location.dat", OpenMode.Random, , , Len(LocationRecord))   'Opens location file
            With LocationRecord                                     'Saves having to type LocationRecord.etc
                .LocationID = txtLocationID.Text                    'Adds details from form to location record
                .Name = txtLocationName.Text                        'Adds details from form to location record
                .Address = txtLocationAddress.Text                  'Adds details from form to location record
                .PostCode = txtLocationPostCode.Text                'Adds details from form to location record
            End With
            LastRecordPosition = LOF(4) / Len(LocationRecord)       'Finds the position of the last record in the location file
            LastRecordPosition = LastRecordPosition + 1             'Adds 1 to last record position to find the location to save the new record
            FilePut(4, LocationRecord, LastRecordPosition)          'Writes location record to location file at last record position
            MsgBox("Location has been saved to file")               'Displays message saying the location record has been saved
        End If
        FileClose(4)                                                'Closes location file
    End Sub

    Private Sub btnNewLesson_Click(sender As Object, e As EventArgs) Handles btnNewLesson.Click
        frmNewLesson.Show()                                         'Displays new lesson form
    End Sub
End Class
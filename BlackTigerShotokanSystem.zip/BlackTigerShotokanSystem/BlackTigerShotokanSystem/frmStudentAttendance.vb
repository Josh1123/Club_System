﻿Public Class frmStudentAttendance

  

    Private Sub frmStudentAttendance_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim StudentRecord As StudentType                    'Declares a variable to store the record structure for my students
        Dim AttendanceRecord As AttendanceType              'Declares a variable to store the record structure for my Attendances
        Dim TempSessionRecord As AttendanceType             'Declares a variable to store the record structure for my Attendance temporarily 
        Dim StudentRecordPosition As Integer                'Declares a variable to calculate and store the location of my students 
        Dim AttendanceRecordPosition As Integer             'Declares a variable to calculate and store the location of my Attendance
        Dim NumberOfSessionsAttended As Integer             'Declares a variable to calculate the number of sessions a student has attended
        Dim PossibleNumberOfSessionsAttended As Integer     'Declares a variable to calculate the possible number of sessions a student has attended
        Dim TempSessionPosition As Integer                  'Declares a variable to calculate and store the location of my temporar attendances
        Dim StudentFound As Boolean                         'Declares a variable to help find a student in the student file
        Dim Date1 As Date                                   'Declares a variable to store the date a student attended a session
        Dim Date2 As Date                                   'Declares a variable to store the date a student attended a session
        Dim Session1 As String                              'Declares a variable to store the day a student attended a session
        Dim Session2 As String                              'Declares a variable to store the day a student attended a session
        Dim LengthOfTemp As Integer                         'Declares a variable to help find the length of m temporay file

        LengthOfTemp = 0                        'Sets Length of file as 0
        PossibleNumberOfSessionsAttended = 0    'Sets Possible number of sessions as 0
        TempSessionPosition = 1                 'Sets temp Session position as 0
        NumberOfSessionsAttended = 0            'Sets Number of sessions as 0
        StudentRecordPosition = 0               'Sets Student Record position as 0
        AttendanceRecordPosition = 0            'Sets Attendabe rceord positon as 0
        StudentFound = False                    'Sets Student foudn as false
        FileClose(7)                            'Ensures that the attendance file is closed
        FileClose(9)                            'Ensures that the Temp session file is closed
        FileClose(1)                            'Ensures that the student file file is closed
        FileOpen(9, "TempSession.dat", OpenMode.Random, , , Len(TempSessionRecord)) 'Opens Temp Sesison file
        FileOpen(7, "Attendance.dat", OpenMode.Random, , , Len(AttendanceRecord))   'Opens Attendance file
        FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord))         'Opens Student file
        Do While Not EOF(1) And Not StudentFound                'Repeat until end of student file and not student found
            StudentRecordPosition = StudentRecordPosition + 1   'Adds 1 to student record position
            FileGet(1, StudentRecord, StudentRecordPosition)    'Reads student record from student file at student record psotion
            If frmLocationStudentTrains.lstListStudents.SelectedItem.Contains(StudentRecord.StudentID) Then  'If selected item from list box contains student ID
                With StudentRecord                              'Saves having to type StudentRecord.etc
                    lblDisplayStudentID.Text = .StudentID       'Displas Student details
                    StudentFound = True                         'Sets Student foudn as true
                End With
            End If
        Loop
        lblDisplayLocationID.Text = frmLocationStudentTrains.cmbFindLocation.SelectedItem() 'Displays location ID

        Do While Not EOF(7)                                                             'Repeats until end of attendance file
            AttendanceRecordPosition = AttendanceRecordPosition + 1                     'Adds 1 to Attendance record position
            FileGet(7, AttendanceRecord, AttendanceRecordPosition)                      'Reads Attendance Record from Attendance file at Attendance record position
            If AttendanceRecord.StudentId = lblDisplayStudentID.Text Then               'If displayed student ID matches student ID from Attendance rceord
                With TempSessionRecord                              'Saves having to type TempSessionRecord.etc
                    .StudentId = AttendanceRecord.StudentId         'Takes details from attendace recod and addes them to Temp session file
                    .Session = AttendanceRecord.Session             'Takes details from attendace recod and addes them to Temp session file
                    .DateAttended = AttendanceRecord.DateAttended   'Takes details from attendace recod and addes them to Temp session file
                End With
                FilePut(9, TempSessionRecord, TempSessionPosition)  'Writes Temp Session Record to Temp Session file at Temp Session position
                TempSessionPosition = TempSessionPosition + 1       'Adds 1 to Temp Session Position
                NumberOfSessionsAttended = NumberOfSessionsAttended + 1 'Adds 1 to Number of Session attended
                LengthOfTemp = LengthOfTemp + 1                     'Adds 1 to length of Temp
            End If
        Loop
        If NumberOfSessionsAttended >= 24 Then                      'If Number of Session =>24
            lblDisaplyEligable.Text = "Yes"                         'Eligible = Yes
        Else
            lblDisaplyEligable.Text = "No"                          'Eligible = No
        End If
        FileClose(9)                                                'Closes Temp Session file
        TempSessionPosition = 0                                     'Sets Temp Session Position as 0
        lblDisplaySessionsAttended.Text = NumberOfSessionsAttended  'Displays Number of Session Attended

        FileOpen(9, "TempSession.dat", OpenMode.Random, , , Len(TempSessionRecord)) 'Opens Temp Session file
        If LengthOfTemp <> 1 Then                                   'If Length of Temp does not = 0
            Do While Not EOF(9)                                     'Repeat until end of TempSession file
                TempSessionPosition = TempSessionPosition + 1       'Adds 1 to Temp Session Position
                FileGet(9, TempSessionRecord, TempSessionPosition)  'Reads Temp Session Record from Temp Session file at Temp Session Position
                Date1 = TempSessionRecord.DateAttended              'Sets Date1 as Temp Session Record date attended
                Session1 = TempSessionRecord.Session                'Sets Session1 as Temp Session Record session
                TempSessionPosition = TempSessionPosition + 1       'Adds 1 to Temp Session Position

                FileGet(9, TempSessionRecord, TempSessionPosition)  'Reads Temp Session Record from Temp Session file at Temp Session Position
                Date2 = TempSessionRecord.DateAttended              'Sets Date2 as Temp Session Record date attended
                Session2 = TempSessionRecord.Session                'Sets Session2 as Temp Session Record session
                If Date2.Day - Date1.Day >= 28 Then                 'If Second date is 28 days ahead from first date
                    If Session1 = Session2 Then                     'If session1 and session 2 match
                        PossibleNumberOfSessionsAttended = PossibleNumberOfSessionsAttended + 4 'Adds 4 to possible session attended
                    Else
                        PossibleNumberOfSessionsAttended = PossibleNumberOfSessionsAttended + 5 'Adds 5 to possible session attended
                    End If
                ElseIf Date2.Day - Date1.Day >= 21 Then             'If Second date is 21 days ahead from first date
                    If Session1 = Session2 Then                     'If session1 and session 2 match
                        PossibleNumberOfSessionsAttended = PossibleNumberOfSessionsAttended + 3 'Adds 3 to possible session attended
                    Else
                        PossibleNumberOfSessionsAttended = PossibleNumberOfSessionsAttended + 4 'Adds 4 to possible session attended
                    End If
                ElseIf Date2.Day - Date1.Day >= 14 Then             'If Second date is 14 days ahead from first date
                    If Session1 = Session2 Then                     'If session1 and session 2 match
                        PossibleNumberOfSessionsAttended = PossibleNumberOfSessionsAttended + 2     'Adds 2 to possible session attended to possible session attended
                    Else
                        PossibleNumberOfSessionsAttended = PossibleNumberOfSessionsAttended + 3     'Adds 3 to possible session attended
                    End If
                ElseIf Date2.Day - Date1.Day >= 7 Then              'If Second date is 7 days ahead from first date
                    If Session1 = Session2 Then                     'If session1 and session 2 match
                        PossibleNumberOfSessionsAttended = PossibleNumberOfSessionsAttended + 1     'Adds 1 to possible session attended
                    Else
                        PossibleNumberOfSessionsAttended = PossibleNumberOfSessionsAttended + 2     'Adds 2 to possible session attended
                    End If
                End If
                TempSessionPosition = TempSessionPosition - 1       'Sebtracts 1 from Temp Session positin
            Loop
        Else
            lblDisplayPossibleAttendace.Text = NumberOfSessionsAttended + PossibleNumberOfSessionsAttended  'Diplays Possible number of sessions
            lblDisaplyPercentage.Text = CInt(lblDisplaySessionsAttended.Text) / CInt(lblDisplayPossibleAttendace.Text) * 100    'Calculates the percentage attendance and then displays it
        End If
        lblDisplayPossibleAttendace.Text = NumberOfSessionsAttended + PossibleNumberOfSessionsAttended  'Diplays Possible number of sessions
        lblDisaplyPercentage.Text = CInt(lblDisplaySessionsAttended.Text) / CInt(lblDisplayPossibleAttendace.Text) * 100    'Calculates the percentage attendance and then displays it
        FileClose(1)        'Closes Student file
        FileClose(7)        'Closes Attendance file
        FileClose(9)        'Closes Temp Session file
        If lblDisaplyEligable.Text = "No" Then  'If not Eligible
            btnGrade.Enabled = False                'Disables grade button
        End If
        Kill("TempSession.dat") 'Deletes Temp Session file
        FileClose(7)        'Closes Attendance file
        FileClose(9)        'Closes Temp Session file
    End Sub

    Private Sub btnGrade_Click(sender As Object, e As EventArgs) Handles btnGrade.Click
        Dim LicenceRecord As LicenceType                    'Declares a variable to store the record structure for my licences
        Dim StudentRecord As StudentType                    'Declares a variable to store the record structure for my students
        Dim LiceneRecordPosition As Integer                 'Declares a variable to calculate and store the location of my students
        Dim StudentRecordPosition As Integer                'Declares a variable to calculate and store the location of my students
        Dim LicenceFound As Boolean                         'Declares a variable to help find the licence that a student holds
        Dim Grade As String                                 'Declares a variable to store the grade of the student

        LiceneRecordPosition = 0                            'Sets Licence Record Psotions as 0
        StudentRecordPosition = 0                           'Sets Student Record position as 0
        LicenceFound = False                                'Sets Licence found as false

        FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord))     'Opens student file
        FileOpen(2, "Licence.dat", OpenMode.Random, , , Len(LicenceRecord))     'Opens licence file
        
        Do While Not EOF(1) And Not LicenceFound                'Repeats until the end of the student file and not licence found
            StudentRecordPosition = StudentRecordPosition + 1   'Adds 1 to student record position
            FileGet(1, StudentRecord, StudentRecordPosition)    'Reads Student record from studnt file at student record position
            If StudentRecord.StudentID = lblDisplayStudentID.Text Then  'If Student ID from Student record matches displayed stdent ID
                Do While Not EOF(2) And Not LicenceFound        'Repeats until End of licence file and not licence found
                    LiceneRecordPosition = LiceneRecordPosition + 1 'Adds 1 to Licence Record Position
                    FileGet(2, LicenceRecord, LiceneRecordPosition)  'Reads licence record from licence file at licence record position
                    If LicenceRecord.StudentID = StudentRecord.StudentID Then   'If Student ID from licence record matches student ID from Student Record
                        LicenceFound = True                     'Sets Licece found as true
                    End If
                Loop                                            'Ends loop
            End If

        Loop
        Grade = LicenceRecord.Grade                             'Grade = Grade from lience record
        If Mid(LicenceRecord.Grade, 5, 1).ToUpper = "K" Then    'If 5th character is a k
            If CInt(Mid(LicenceRecord.Grade, 1, 1)) = 1 Then    'If current grade number is 1
                LicenceRecord.Grade = "1st Dan"                 'Sets grade as 1st dan
                MsgBox("Student has been graded to 1st Dan")    'Displays message to user
            ElseIf CInt(Mid(LicenceRecord.Grade, 1, 1)) = 2 Then    'If current grade number is 2
                LicenceRecord.Grade = "1st KYU"""               'Sets grade as 1st kyu
                MsgBox("Student has been graded" & LicenceRecord.Grade)     'Displays message to user and the students grade
            ElseIf CInt(Mid(LicenceRecord.Grade, 1, 1)) = 3 Then    'If current grade number is 3
                LicenceRecord.Grade = "2nd KYU"""               'Sets grade as 2nd kyu
                MsgBox("Student has been graded" & LicenceRecord.Grade)     'Displays message to user and the students grade
            ElseIf CInt(Mid(LicenceRecord.Grade, 1, 1)) = 4 Then    'If current grade number is 4
                LicenceRecord.Grade = "3rd KYU"                 'Sets grade as 3rd kyu
                MsgBox("Student has been graded" & LicenceRecord.Grade)     'Displays message to user and the students grade
            Else
                LicenceRecord.Grade = CInt(Mid(LicenceRecord.Grade, 1, 1)) - 1 & "th" & " " & "Kyu" 'Subracts 1 from the number adds th to it and then adds  kyu
                MsgBox("Student has been graded " & LicenceRecord.Grade)    'Displays message to user and the students grade
            End If
        ElseIf Mid(LicenceRecord.Grade, 5, 1).ToUpper = "D" Then    'If 5th character is D
            If CInt(Mid(LicenceRecord.Grade, 1, 1)) = 1 Then        'If current grade number is 1
                LicenceRecord.Grade = "2nd Dan"                     'Sets Grade as 2nd Dan
                MsgBox("Student has been graded to 2nd Dan")        'Displays message to user
            ElseIf CInt(Mid(LicenceRecord.Grade, 1, 1)) = 2 Then    'If current grade number is 2
                LicenceRecord.Grade = "3rd Dan"""                   'Sets grade as 3rd Dan
                MsgBox("Student has been graded " & LicenceRecord.Grade)    'Displays message to user and the students grade
            Else
                LicenceRecord.Grade = CInt(Mid(LicenceRecord.Grade, 1, 1)) + 1 & "th" & " " & "Dan"     'Adds 1 from the number adds th to it and then adds  kyu
                MsgBox("Student has been graded " & LicenceRecord.Grade)    'Displays message to user and the students grade
            End If
        End If
        FilePut(2, LicenceRecord, LiceneRecordPosition)             'Writes Licence Record to Licence file at Licence Record position
        MsgBox("Student has been gradded " & LicenceRecord.Grade)    'Displays a message saying the student has been gradded and their grade
        FileClose(1)                                'Closes Student file
        FileClose(2)                                'Closes Licence file
    End Sub
End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAttendLesson
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnAttend = New System.Windows.Forms.Button()
        Me.lblSessionAtteded = New System.Windows.Forms.Label()
        Me.lblDateOFSession = New System.Windows.Forms.Label()
        Me.lblStudentID = New System.Windows.Forms.Label()
        Me.txtDateOfSession = New System.Windows.Forms.TextBox()
        Me.cmbSesison = New System.Windows.Forms.ComboBox()
        Me.cmbLocationID = New System.Windows.Forms.ComboBox()
        Me.lblLocationId = New System.Windows.Forms.Label()
        Me.cmbStudentID = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'btnAttend
        '
        Me.btnAttend.BackColor = System.Drawing.Color.Black
        Me.btnAttend.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnAttend.ForeColor = System.Drawing.Color.White
        Me.btnAttend.Location = New System.Drawing.Point(277, 83)
        Me.btnAttend.Name = "btnAttend"
        Me.btnAttend.Size = New System.Drawing.Size(83, 29)
        Me.btnAttend.TabIndex = 0
        Me.btnAttend.Text = "Attend"
        Me.btnAttend.UseVisualStyleBackColor = False
        '
        'lblSessionAtteded
        '
        Me.lblSessionAtteded.AutoSize = True
        Me.lblSessionAtteded.Location = New System.Drawing.Point(22, 66)
        Me.lblSessionAtteded.Name = "lblSessionAtteded"
        Me.lblSessionAtteded.Size = New System.Drawing.Size(90, 13)
        Me.lblSessionAtteded.TabIndex = 1
        Me.lblSessionAtteded.Text = "Session Attended"
        '
        'lblDateOFSession
        '
        Me.lblDateOFSession.AutoSize = True
        Me.lblDateOFSession.Location = New System.Drawing.Point(22, 113)
        Me.lblDateOFSession.Name = "lblDateOFSession"
        Me.lblDateOFSession.Size = New System.Drawing.Size(87, 13)
        Me.lblDateOFSession.TabIndex = 2
        Me.lblDateOFSession.Text = "Datre Of Session"
        '
        'lblStudentID
        '
        Me.lblStudentID.AutoSize = True
        Me.lblStudentID.Location = New System.Drawing.Point(22, 159)
        Me.lblStudentID.Name = "lblStudentID"
        Me.lblStudentID.Size = New System.Drawing.Size(58, 13)
        Me.lblStudentID.TabIndex = 3
        Me.lblStudentID.Text = "Student ID"
        '
        'txtDateOfSession
        '
        Me.txtDateOfSession.BackColor = System.Drawing.Color.Gainsboro
        Me.txtDateOfSession.Location = New System.Drawing.Point(129, 110)
        Me.txtDateOfSession.Name = "txtDateOfSession"
        Me.txtDateOfSession.Size = New System.Drawing.Size(121, 20)
        Me.txtDateOfSession.TabIndex = 5
        '
        'cmbSesison
        '
        Me.cmbSesison.BackColor = System.Drawing.Color.Gainsboro
        Me.cmbSesison.FormattingEnabled = True
        Me.cmbSesison.Location = New System.Drawing.Point(129, 63)
        Me.cmbSesison.Name = "cmbSesison"
        Me.cmbSesison.Size = New System.Drawing.Size(121, 21)
        Me.cmbSesison.TabIndex = 7
        '
        'cmbLocationID
        '
        Me.cmbLocationID.BackColor = System.Drawing.Color.Gainsboro
        Me.cmbLocationID.FormattingEnabled = True
        Me.cmbLocationID.Location = New System.Drawing.Point(129, 21)
        Me.cmbLocationID.Name = "cmbLocationID"
        Me.cmbLocationID.Size = New System.Drawing.Size(121, 21)
        Me.cmbLocationID.TabIndex = 9
        '
        'lblLocationId
        '
        Me.lblLocationId.AutoSize = True
        Me.lblLocationId.Location = New System.Drawing.Point(22, 24)
        Me.lblLocationId.Name = "lblLocationId"
        Me.lblLocationId.Size = New System.Drawing.Size(62, 13)
        Me.lblLocationId.TabIndex = 8
        Me.lblLocationId.Text = "Location ID"
        '
        'cmbStudentID
        '
        Me.cmbStudentID.BackColor = System.Drawing.Color.Gainsboro
        Me.cmbStudentID.FormattingEnabled = True
        Me.cmbStudentID.Location = New System.Drawing.Point(129, 156)
        Me.cmbStudentID.Name = "cmbStudentID"
        Me.cmbStudentID.Size = New System.Drawing.Size(121, 21)
        Me.cmbStudentID.TabIndex = 10
        '
        'frmAttendLesson
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(391, 200)
        Me.Controls.Add(Me.cmbStudentID)
        Me.Controls.Add(Me.cmbLocationID)
        Me.Controls.Add(Me.lblLocationId)
        Me.Controls.Add(Me.cmbSesison)
        Me.Controls.Add(Me.txtDateOfSession)
        Me.Controls.Add(Me.lblStudentID)
        Me.Controls.Add(Me.lblDateOFSession)
        Me.Controls.Add(Me.lblSessionAtteded)
        Me.Controls.Add(Me.btnAttend)
        Me.Name = "frmAttendLesson"
        Me.Text = "Attend Lesson"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnAttend As System.Windows.Forms.Button
    Friend WithEvents lblSessionAtteded As System.Windows.Forms.Label
    Friend WithEvents lblDateOFSession As System.Windows.Forms.Label
    Friend WithEvents lblStudentID As System.Windows.Forms.Label
    Friend WithEvents txtDateOfSession As System.Windows.Forms.TextBox
    Friend WithEvents cmbSesison As System.Windows.Forms.ComboBox
    Friend WithEvents cmbLocationID As System.Windows.Forms.ComboBox
    Friend WithEvents lblLocationId As System.Windows.Forms.Label
    Friend WithEvents cmbStudentID As System.Windows.Forms.ComboBox
End Class

﻿Public Class frmLocationAttendance

    Private Sub frmLocationAttendance_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim LocationRecord As LocationType                                      'Declares a variable to save and store the record structure of my locations
        Dim RecordPosition As Integer                                           'Declares a variable to calculate and store the location of my locations
        Dim ColsFormat As String = "{0,-20} {1,-30} {2,-40} {3,-50}"            'Declares a varaible to store the format for my headings
        RecordPosition = 0                                                      'Sets rceord position as 0
        lstListLocation.Items.Clear()                                           'Clears list box
        lstListLocation.Items.Add(String.Format(ColsFormat, "Location ID", "Location Name", "Location Address", "Location Post Code"))  'Adds headings to list box in correct positions
        FileOpen(4, "Location.dat", OpenMode.Random, , , Len(LocationRecord))   'Opens location file
        Do While Not EOF(4)                                                     'Loops through Location File until End of the file
            With LocationRecord                                                 'Saves having to type LocationRecord.etc
                RecordPosition = RecordPosition + 1                             'Adds 1 to record position
                FileGet(4, LocationRecord, RecordPosition)                      'Reads location record from location file at record position
                lstListLocation.Items.Add(String.Format(ColsFormat, .LocationID, .Name, .Address, .PostCode))   'Adds location record to list box
            End With
        Loop                                                                    'Ends loop
        FileClose(4)                                                            'Closes Location file
    End Sub

    Private Sub btnViewAttendance_Click(sender As Object, e As EventArgs) Handles btnViewAttendance.Click
        frmLocationStudentTrains.Show()                                 'Displays Location Student Trains form to user
        FileClose(4)                                                    'Closes Location File
    End Sub
End Class
﻿Module StudentMOD
    Public Structure StudentType
        <VBFixedString(6)> Dim StudentID As String      'All the variables are self documenting so each store the data contains to its name
        <VBFixedString(20)> Dim FirstName As String
        <VBFixedString(30)> Dim LastName As String
        Dim Gender As Char
        Dim DateOfBirth As Date
        Dim Deleted As Boolean
        <VBFixedString(30)> Dim Address As String
        <VBFixedString(6)> Dim PostCode As String
        <VBFixedString(11)> Dim HomeNumber As String
        <VBFixedString(11)> Dim MobileNumber As String
        <VBFixedString(20)> Dim Email As String
    End Structure
    Public Function GenerateStudentID(ByVal FirstName As String, ByVal LastName As String) As String    'Declares a function to generate a student ID
        Dim StudentRecord As StudentType                'Declares a variable to store the rerd structure of my students
        Dim Max As Integer                              'Declares a variable to store the number part for the generated ID
        Dim NumberPart As Integer                       'Declaers a variable to find the biggest number that appears in the licence record
        Dim Letters As String                           'Declares a variable to store the letters for my genertaed ID
        Dim ID As String                                'Declares a variable to store the generated ID
        Max = 0                                         'Sets Max as 0
        Letters = Mid(LastName, 1, 2).ToUpper & Mid(FirstName, 1, 1).ToUpper    'Letters = first 2 characters of the last name and the firt character of the first name
        FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord))     'Open student file
        Do While Not EOF(1)                             'Repeat until end of student file
            FileGet(1, StudentRecord)                   'Reads through student file
            If Letters = Mid(StudentRecord.StudentID, 1, 3) Then    'If letters match Letters from student ID
                NumberPart = CInt(Mid(StudentRecord.StudentID, 4, 3))   'Number part = Number part of student ID
                If NumberPart > Max Then                'If number part greater then Mam
                    Max = NumberPart                    'Sets Max as Number part
                End If
            End If
        Loop
        FileClose(1)                                    'Closes Student file
        Max = Max + 1                                   'Adds 1 to Max
        ID = Letters & Format(Max, "000")               'Generates Student ID
        Return ID                                       'Returns Generated ID to main program
    End Function
    Public Function ValidateStudent(ByVal FirstNam As TextBox, ByVal LastNam As TextBox, ByVal DOB As Date, ByVal Addres As TextBox, ByVal PostCod As TextBox, ByVal MobileNum As TextBox, ByVal Email As TextBox) As Boolean 'Declares a function to validate user entry
        Dim Valid As Boolean = True                 'Declares a variable to help validate user entry 
        If Len(FirstNam.Text) < 1 Then              'If length of first name less than 1
            Valid = False                           'Sets Valid as false
            MsgBox("First Name Must have 1 or letters") 'Displays Error message
        ElseIf Len(FirstNam.Text) > 20 Then         'If length of first name greater then 20
            Valid = False                           'Sets Valid as false
            MsgBox("First Name must be no more then 20 characters") 'Displays error message
        ElseIf Len(LastNam.Text) < 2 Then           'If length of Last name less than 2 
            Valid = False                           'Sets valid as false
            MsgBox("Last name must have at least 2 characters")     'Displays error message
        ElseIf Today.Year - DOB.Year < 5 Then       'If Student is youger then 5 years old
            Valid = False                           'Sets Valid as false
            MsgBox("Student must be at least 5 years of age")   'Displays error message
        ElseIf Len(PostCod.Text) <> 6 Then          'If Length of Post Code does not equal 6
            Valid = False                           'Sets valid as false
            MsgBox("Post Code must be 6 charaters long")    'Displays error message
        ElseIf IsNumeric(Mid(PostCod.Text, 1, 2)) = True Then   'If first 2 charcters are numbers
            Valid = False                           'Sets Valid as false
            MsgBox("Post Code must have the first two letters as letters")  'Displays error message
        ElseIf IsNumeric(Mid(PostCod.Text, 3, 2)) = False Then  'If middle 2 leters not numbers
            Valid = False                           'Sets valid as false
            MsgBox("The 3rd and 4th charaters in the Post Code must be Numbers")    'Displays error message
        ElseIf IsNumeric(Mid(PostCod.Text, 5, 2)) = True Then       'If Last 2 characters are numbers
            Valid = False                           'Sets valid as false
            MsgBox("The Last 2 Characters of the Post Code must be Letters")    'Displays error message
        ElseIf Addres.Text = "" Then                'If Address is blank
            Valid = False                           'Sets valid as false
            MsgBox("Address Must be Entered")       'Displays error message
        ElseIf MobileNum.Text = "" Then             'If Mobile nnumber is blank
            Valid = False                           'Sets valid as false
            MsgBox("Mobile Number must be entered into the system") 'Displays error message
        ElseIf Email.Text.Contains("@") = False Then    'If email does not contain a @
            Valid = False                           'Sets valid as false
            MsgBox("Emails must contain @") 'Displays error message
        End If
        Return Valid                        'Returns valid to main program
    End Function
End Module

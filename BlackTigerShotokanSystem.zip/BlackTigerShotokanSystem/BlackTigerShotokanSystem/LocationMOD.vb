﻿Module LocationMOD
    Public Structure LocationType
        <VBFixedString(6)> Dim LocationID As String         'All the variables are self documenting so each store the data contains to its name
        <VBFixedString(30)> Dim Name As String
        <VBFixedString(40)> Dim Address As String
        <VBFixedString(6)> Dim PostCode As String
    End Structure
    Public Function ValidateLocation(ByVal LocID As String, ByVal LocationName As TextBox, ByVal Adres As TextBox, ByVal PostCod As TextBox) As Boolean 'Declares a function to validate user enrty
        Dim LocationRecord As LocationType      'Declares a variable to store the record structure of my locations
        Dim Valid As Boolean                    'Declares a variable to help validate my locations
        Dim RecordPosition As Integer           'Declares a variable to calcluate and store the position a location is tored
        Dim LocationFound As Boolean            'Declares a variable to see if a location ID is already in the file
        LocationFound = False                   'Sets Location found as false
        RecordPosition = 0                      'Sets rceord position as 0
        Valid = True                            'Sets valid as true
        FileOpen(4, "Location.dat", OpenMode.Random, , , Len(LocationRecord))   'Opens Location file
        Do While Not EOF(4)                     'Repeats until end of location file
            RecordPosition = RecordPosition + 1 'Adds 1 to Record position
            FileGet(4, LocationRecord, RecordPosition)  'Reads location record from location file at record position
            If LocID = LocationRecord.LocationID Then   'If Location ID found in Location record
                LocationFound = True            'Sets Location found as true
            End If
        Loop
        FileClose(4)                            'Closes location file
        If LocationFound Then                   'If location found  
            Valid = False                       'Sets valid as false
            MsgBox("Location ID must be unique")    'Displays error message
        ElseIf Len(LocationName.Text) > 30 Then 'If length of location name > 30
            Valid = False                       'Sets valid as fale
            MsgBox("Location Name must be 30 characters or less in length") 'Displays error message
        ElseIf Adres.Text = "" Then             'If address is blank
            Valid = False                       'Sets Valid as False
            MsgBox("Address Must be Present")   'Displays error message
        ElseIf IsNumeric(Mid(PostCod.Text, 1, 2)) = True Then   'If first 2 characters are not letters
            Valid = False                       'Sets Valid as false
            MsgBox("Post Code must have the first two letters as letters")  'Displays error mesage
        ElseIf IsNumeric(Mid(PostCod.Text, 3, 2)) = False Then  'If 3rd and 4th characters not numbers
            Valid = False                       'Sets valid as false
            MsgBox("The 3rd and 4th charaters in the Post Code must be Numbers")    'Displays error message
        ElseIf IsNumeric(Mid(PostCod.Text, 5, 2)) = True Then       'If last 2 characters of post code are numbers
            Valid = False                       'Sets valid as false
            MsgBox("The Last 2 Characters of the Post Code must be Letters")    'Displas error message
        End If
        Return Valid                            'Returns Valid to the main program
    End Function
End Module

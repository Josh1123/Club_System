﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmUpdateLesson
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnUpdateLesson = New System.Windows.Forms.Button()
        Me.lblLocationID = New System.Windows.Forms.Label()
        Me.cmbLocationID = New System.Windows.Forms.ComboBox()
        Me.grpLessonDetails = New System.Windows.Forms.GroupBox()
        Me.txtSession1 = New System.Windows.Forms.TextBox()
        Me.lblTimeStart1 = New System.Windows.Forms.Label()
        Me.txtSession2 = New System.Windows.Forms.TextBox()
        Me.lblTimeFinish1 = New System.Windows.Forms.Label()
        Me.txtTimeFinish2 = New System.Windows.Forms.TextBox()
        Me.lblTimeFinish2 = New System.Windows.Forms.Label()
        Me.lblTimeStart2 = New System.Windows.Forms.Label()
        Me.txtTimeFinish1 = New System.Windows.Forms.TextBox()
        Me.lblSession1 = New System.Windows.Forms.Label()
        Me.txtTimeStart1 = New System.Windows.Forms.TextBox()
        Me.txtTimeStart2 = New System.Windows.Forms.TextBox()
        Me.lblSession2 = New System.Windows.Forms.Label()
        Me.grpLessonDetails.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnUpdateLesson
        '
        Me.btnUpdateLesson.BackColor = System.Drawing.Color.Red
        Me.btnUpdateLesson.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnUpdateLesson.Location = New System.Drawing.Point(191, 185)
        Me.btnUpdateLesson.Name = "btnUpdateLesson"
        Me.btnUpdateLesson.Size = New System.Drawing.Size(167, 34)
        Me.btnUpdateLesson.TabIndex = 13
        Me.btnUpdateLesson.Text = "Update Lesson"
        Me.btnUpdateLesson.UseVisualStyleBackColor = False
        '
        'lblLocationID
        '
        Me.lblLocationID.AutoSize = True
        Me.lblLocationID.Location = New System.Drawing.Point(22, 15)
        Me.lblLocationID.Name = "lblLocationID"
        Me.lblLocationID.Size = New System.Drawing.Size(62, 13)
        Me.lblLocationID.TabIndex = 11
        Me.lblLocationID.Text = "Location ID"
        '
        'cmbLocationID
        '
        Me.cmbLocationID.BackColor = System.Drawing.Color.Gainsboro
        Me.cmbLocationID.FormattingEnabled = True
        Me.cmbLocationID.Location = New System.Drawing.Point(92, 12)
        Me.cmbLocationID.Name = "cmbLocationID"
        Me.cmbLocationID.Size = New System.Drawing.Size(121, 21)
        Me.cmbLocationID.TabIndex = 10
        '
        'grpLessonDetails
        '
        Me.grpLessonDetails.Controls.Add(Me.txtSession1)
        Me.grpLessonDetails.Controls.Add(Me.lblTimeStart1)
        Me.grpLessonDetails.Controls.Add(Me.txtSession2)
        Me.grpLessonDetails.Controls.Add(Me.lblTimeFinish1)
        Me.grpLessonDetails.Controls.Add(Me.txtTimeFinish2)
        Me.grpLessonDetails.Controls.Add(Me.lblTimeFinish2)
        Me.grpLessonDetails.Controls.Add(Me.lblTimeStart2)
        Me.grpLessonDetails.Controls.Add(Me.txtTimeFinish1)
        Me.grpLessonDetails.Controls.Add(Me.lblSession1)
        Me.grpLessonDetails.Controls.Add(Me.txtTimeStart1)
        Me.grpLessonDetails.Controls.Add(Me.txtTimeStart2)
        Me.grpLessonDetails.Controls.Add(Me.lblSession2)
        Me.grpLessonDetails.Location = New System.Drawing.Point(16, 54)
        Me.grpLessonDetails.Name = "grpLessonDetails"
        Me.grpLessonDetails.Size = New System.Drawing.Size(543, 106)
        Me.grpLessonDetails.TabIndex = 12
        Me.grpLessonDetails.TabStop = False
        Me.grpLessonDetails.Text = "Lesson Details"
        '
        'txtSession1
        '
        Me.txtSession1.BackColor = System.Drawing.Color.Gainsboro
        Me.txtSession1.Location = New System.Drawing.Point(65, 18)
        Me.txtSession1.Name = "txtSession1"
        Me.txtSession1.Size = New System.Drawing.Size(100, 20)
        Me.txtSession1.TabIndex = 9
        '
        'lblTimeStart1
        '
        Me.lblTimeStart1.AutoSize = True
        Me.lblTimeStart1.Location = New System.Drawing.Point(172, 21)
        Me.lblTimeStart1.Name = "lblTimeStart1"
        Me.lblTimeStart1.Size = New System.Drawing.Size(64, 13)
        Me.lblTimeStart1.TabIndex = 7
        Me.lblTimeStart1.Text = "Time Start 1"
        '
        'txtSession2
        '
        Me.txtSession2.BackColor = System.Drawing.Color.Gainsboro
        Me.txtSession2.Location = New System.Drawing.Point(65, 69)
        Me.txtSession2.Name = "txtSession2"
        Me.txtSession2.Size = New System.Drawing.Size(100, 20)
        Me.txtSession2.TabIndex = 10
        '
        'lblTimeFinish1
        '
        Me.lblTimeFinish1.AutoSize = True
        Me.lblTimeFinish1.Location = New System.Drawing.Point(362, 21)
        Me.lblTimeFinish1.Name = "lblTimeFinish1"
        Me.lblTimeFinish1.Size = New System.Drawing.Size(69, 13)
        Me.lblTimeFinish1.TabIndex = 5
        Me.lblTimeFinish1.Text = "Time Finish 1"
        '
        'txtTimeFinish2
        '
        Me.txtTimeFinish2.BackColor = System.Drawing.Color.Gainsboro
        Me.txtTimeFinish2.Location = New System.Drawing.Point(437, 69)
        Me.txtTimeFinish2.Name = "txtTimeFinish2"
        Me.txtTimeFinish2.Size = New System.Drawing.Size(100, 20)
        Me.txtTimeFinish2.TabIndex = 11
        '
        'lblTimeFinish2
        '
        Me.lblTimeFinish2.AutoSize = True
        Me.lblTimeFinish2.Location = New System.Drawing.Point(362, 72)
        Me.lblTimeFinish2.Name = "lblTimeFinish2"
        Me.lblTimeFinish2.Size = New System.Drawing.Size(69, 13)
        Me.lblTimeFinish2.TabIndex = 4
        Me.lblTimeFinish2.Text = "Time Finish 2"
        '
        'lblTimeStart2
        '
        Me.lblTimeStart2.AutoSize = True
        Me.lblTimeStart2.Location = New System.Drawing.Point(172, 72)
        Me.lblTimeStart2.Name = "lblTimeStart2"
        Me.lblTimeStart2.Size = New System.Drawing.Size(64, 13)
        Me.lblTimeStart2.TabIndex = 6
        Me.lblTimeStart2.Text = "Time Start 2"
        '
        'txtTimeFinish1
        '
        Me.txtTimeFinish1.BackColor = System.Drawing.Color.Gainsboro
        Me.txtTimeFinish1.Location = New System.Drawing.Point(437, 18)
        Me.txtTimeFinish1.Name = "txtTimeFinish1"
        Me.txtTimeFinish1.Size = New System.Drawing.Size(100, 20)
        Me.txtTimeFinish1.TabIndex = 12
        '
        'lblSession1
        '
        Me.lblSession1.AutoSize = True
        Me.lblSession1.Location = New System.Drawing.Point(6, 21)
        Me.lblSession1.Name = "lblSession1"
        Me.lblSession1.Size = New System.Drawing.Size(53, 13)
        Me.lblSession1.TabIndex = 3
        Me.lblSession1.Text = "Session 1"
        '
        'txtTimeStart1
        '
        Me.txtTimeStart1.BackColor = System.Drawing.Color.Gainsboro
        Me.txtTimeStart1.Location = New System.Drawing.Point(242, 18)
        Me.txtTimeStart1.Name = "txtTimeStart1"
        Me.txtTimeStart1.Size = New System.Drawing.Size(100, 20)
        Me.txtTimeStart1.TabIndex = 13
        '
        'txtTimeStart2
        '
        Me.txtTimeStart2.BackColor = System.Drawing.Color.Gainsboro
        Me.txtTimeStart2.Location = New System.Drawing.Point(242, 69)
        Me.txtTimeStart2.Name = "txtTimeStart2"
        Me.txtTimeStart2.Size = New System.Drawing.Size(100, 20)
        Me.txtTimeStart2.TabIndex = 14
        '
        'lblSession2
        '
        Me.lblSession2.AutoSize = True
        Me.lblSession2.Location = New System.Drawing.Point(6, 72)
        Me.lblSession2.Name = "lblSession2"
        Me.lblSession2.Size = New System.Drawing.Size(53, 13)
        Me.lblSession2.TabIndex = 2
        Me.lblSession2.Text = "Session 2"
        '
        'frmUpdateLesson
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(571, 240)
        Me.Controls.Add(Me.btnUpdateLesson)
        Me.Controls.Add(Me.lblLocationID)
        Me.Controls.Add(Me.cmbLocationID)
        Me.Controls.Add(Me.grpLessonDetails)
        Me.Name = "frmUpdateLesson"
        Me.Text = "Update Lesson"
        Me.grpLessonDetails.ResumeLayout(False)
        Me.grpLessonDetails.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnUpdateLesson As System.Windows.Forms.Button
    Friend WithEvents lblLocationID As System.Windows.Forms.Label
    Friend WithEvents cmbLocationID As System.Windows.Forms.ComboBox
    Friend WithEvents grpLessonDetails As System.Windows.Forms.GroupBox
    Friend WithEvents txtSession1 As System.Windows.Forms.TextBox
    Friend WithEvents lblTimeStart1 As System.Windows.Forms.Label
    Friend WithEvents txtSession2 As System.Windows.Forms.TextBox
    Friend WithEvents lblTimeFinish1 As System.Windows.Forms.Label
    Friend WithEvents txtTimeFinish2 As System.Windows.Forms.TextBox
    Friend WithEvents lblTimeFinish2 As System.Windows.Forms.Label
    Friend WithEvents lblTimeStart2 As System.Windows.Forms.Label
    Friend WithEvents txtTimeFinish1 As System.Windows.Forms.TextBox
    Friend WithEvents lblSession1 As System.Windows.Forms.Label
    Friend WithEvents txtTimeStart1 As System.Windows.Forms.TextBox
    Friend WithEvents txtTimeStart2 As System.Windows.Forms.TextBox
    Friend WithEvents lblSession2 As System.Windows.Forms.Label
End Class

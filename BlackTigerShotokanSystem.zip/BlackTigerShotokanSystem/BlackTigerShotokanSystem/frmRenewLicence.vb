﻿Public Class frmRenewLicence

    Private Sub frmRenewLicence_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim StudentRecord As StudentType            'Declares a variable to store the record structure for my students
        Dim LicenceRecord As LicenceType            'Declares a variable to store the record structure for my licences
        Dim StudentRecordPosition As Integer        'Declares a variable to calculate a variable to Find the location in the student file where a student can be found
        Dim LicenceRecordPosition As Integer        'Declares a variable to calculate a variable to Find the location in the licence file where a licence can be found
        Dim LicenceFound As Boolean                 'Declares a variable to help find a selected licence

        StudentRecordPosition = 0                   'Sets student record position as 0
        LicenceRecordPosition = 0                   'Sets Licence record position as 0
        LicenceFound = False                        'Sets licence found as false

        FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord)) 'Opens student file
        FileOpen(2, "Licence.dat", OpenMode.Random, , , Len(LicenceRecord)) 'Opens licence file
        Do While Not EOF(2) And Not LicenceFound                            'Repeats until end of licence file and licence not found
            LicenceRecordPosition = LicenceRecordPosition + 1               'Adds 1 to licence rceord position
            FileGet(2, LicenceRecord, LicenceRecordPosition)                'Reads licence record from licence file at licence record position
            If frmListLicence.lstListLicences.SelectedItem.Contains(LicenceRecord.StudentID) And frmListLicence.lstListLicences.SelectedItem.Contains(LicenceRecord.LicenceID) Then
                Do While Not EOF(1) And Not LicenceFound                        'Repaets until end of student file and not licence found
                    StudentRecordPosition = StudentRecordPosition + 1           'Adds 1 to Student rceord position
                    FileGet(1, StudentRecord, StudentRecordPosition)            'Reads student record from student file at student rceord position
                    If StudentRecord.StudentID = LicenceRecord.StudentID Then   'if student id from student record matches licence rceord student id
                        LicenceFound = True                                     'Licence has been found
                    End If
                Loop
            End If
        Loop
        If LicenceFound Then                                                'If licence found
            lblDisplayStudentID.Text = StudentRecord.StudentID              'Populates form with details from file
            lblDisaplyFirstName.Text = StudentRecord.FirstName              'Populates form with details from file
            lblDisaplyLastName.Text = StudentRecord.LastName                'Populates form with details from file
            lblDisaplyAddress.Text = StudentRecord.Address                  'Populates form with details from file
            lblDisaplyDateOfBirth.Text = CDate(StudentRecord.DateOfBirth).Day & "/" & CDate(StudentRecord.DateOfBirth).Month & "/" & CDate(StudentRecord.DateOfBirth).Year  'Populates form with details from file
            lblDisaplyPostCode.Text = StudentRecord.PostCode                'Populates form with details from file
            lblDisaplyDateExpires.Text = LicenceRecord.DateExpired          'Populates form with details from file
            lblGenerateLicenceID.Text = LicenceRecord.LicenceID             'Populates form with details from file
            lblDisaplyDateIssued.Text = LicenceRecord.DateIssued            'Populates form with details from file
        End If
        FileClose(1)                                                        'Closes Student file
        FileClose(2)                                                        'Closes Licence file
    End Sub

    Private Sub btnPrintPreview_Click(sender As Object, e As EventArgs) Handles btnPrintPreview.Click
        PrintPreviewDialog1.Document = PrintDocument1                       'Declares whihc document is the print preview
        PrintPreviewDialog1.Show()                                          'Shows print privew from dialogue
    End Sub

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        Dim Result As DialogResult = PrintDialog1.ShowDialog            'Declares a variable to store the results of the print dialogue
        PrintDialog1.Document = PrintDocument1                          'Decalres which document is to be printed
        If Result = DialogResult.OK Then                                'If document is okay to print
            PrintDocument1.Print()                                      'Prints document
        End If
    End Sub

    Private Sub PrintDocument1_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim HeadingFont As New Font("Arial", 24, FontStyle.Bold)        'Declares the main heading font style
        Dim MainFont As New Font("Microsoft Sans Serif", 14, FontStyle.Regular) 'Declares the main body font style

        e.Graphics.DrawString("English Karate Federation", HeadingFont, Brushes.DarkRed, 200, 10)   'Adds details to document
        e.Graphics.DrawString("Licence ID", MainFont, Brushes.Black, 50, 150)                       'Adds details to document
        e.Graphics.DrawString("Student ID", MainFont, Brushes.Black, 50, 200)                       'Adds details to document
        e.Graphics.DrawString("First Name", MainFont, Brushes.Black, 50, 250)                       'Adds details to document
        e.Graphics.DrawString("Last Name", MainFont, Brushes.Black, 50, 300)                        'Adds details to document
        e.Graphics.DrawString("Address", MainFont, Brushes.Black, 50, 350)                          'Adds details to document
        e.Graphics.DrawString("Post Code", MainFont, Brushes.Black, 50, 500)                        'Adds details to document
        e.Graphics.DrawString("Date Of Birth", MainFont, Brushes.Black, 50, 550)                    'Adds details to document
        e.Graphics.DrawString("Issue Date", MainFont, Brushes.Black, 50, 600)                       'Adds details to document
        e.Graphics.DrawString("Date Expires", MainFont, Brushes.Black, 50, 650)                     'Adds details to document
        e.Graphics.DrawString(lblGenerateLicenceID.Text, MainFont, Brushes.Black, 200, 150)         'Adds details  from form to document
        e.Graphics.DrawString(lblDisplayStudentID.Text, MainFont, Brushes.Black, 200, 200)          'Adds details  from form to document
        e.Graphics.DrawString(lblDisaplyFirstName.Text, MainFont, Brushes.Black, 200, 250)          'Adds details  from form to document
        e.Graphics.DrawString(lblDisaplyLastName.Text, MainFont, Brushes.Black, 200, 300)           'Adds details  from form to document
        e.Graphics.DrawString(lblDisaplyAddress.Text, MainFont, Brushes.Black, 200, 350)            'Adds details  from form to document
        e.Graphics.DrawString(lblDisaplyPostCode.Text, MainFont, Brushes.Black, 200, 500)           'Adds details  from form to document
        e.Graphics.DrawString(lblDisaplyDateOfBirth.Text, MainFont, Brushes.Black, 200, 550)        'Adds details  from form to document
        e.Graphics.DrawString(lblDisaplyDateIssued.Text, MainFont, Brushes.Black, 200, 600)         'Adds details  from form to document
        e.Graphics.DrawString(lblDisaplyDateExpires.Text, MainFont, Brushes.Black, 200, 650)        'Adds details  from form to document
    End Sub
End Class
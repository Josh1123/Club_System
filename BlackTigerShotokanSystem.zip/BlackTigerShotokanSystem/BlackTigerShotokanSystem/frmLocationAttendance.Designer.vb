﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLocationAttendance
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstListLocation = New System.Windows.Forms.ListBox()
        Me.btnViewAttendance = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lstListLocation
        '
        Me.lstListLocation.BackColor = System.Drawing.Color.Gainsboro
        Me.lstListLocation.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstListLocation.FormattingEnabled = True
        Me.lstListLocation.ItemHeight = 14
        Me.lstListLocation.Location = New System.Drawing.Point(12, 12)
        Me.lstListLocation.Name = "lstListLocation"
        Me.lstListLocation.Size = New System.Drawing.Size(795, 270)
        Me.lstListLocation.TabIndex = 0
        '
        'btnViewAttendance
        '
        Me.btnViewAttendance.BackColor = System.Drawing.Color.Red
        Me.btnViewAttendance.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnViewAttendance.Location = New System.Drawing.Point(344, 310)
        Me.btnViewAttendance.Name = "btnViewAttendance"
        Me.btnViewAttendance.Size = New System.Drawing.Size(75, 43)
        Me.btnViewAttendance.TabIndex = 1
        Me.btnViewAttendance.Text = "View Attendance"
        Me.btnViewAttendance.UseVisualStyleBackColor = False
        '
        'frmLocationAttendance
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(829, 384)
        Me.Controls.Add(Me.btnViewAttendance)
        Me.Controls.Add(Me.lstListLocation)
        Me.Name = "frmLocationAttendance"
        Me.Text = "Location Attendance"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lstListLocation As System.Windows.Forms.ListBox
    Friend WithEvents btnViewAttendance As System.Windows.Forms.Button
End Class

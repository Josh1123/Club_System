﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmUpdateStudents
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblGenerateID = New System.Windows.Forms.Label()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.lblMobileNumber = New System.Windows.Forms.Label()
        Me.lblTeleNumber = New System.Windows.Forms.Label()
        Me.lblPostCode = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblDateOfBirth = New System.Windows.Forms.Label()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.lblStudentID = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.txtMobileNumber = New System.Windows.Forms.TextBox()
        Me.txtTeleNumber = New System.Windows.Forms.TextBox()
        Me.txtPostCode = New System.Windows.Forms.TextBox()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.txtDateOfBirth = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblGenerateID
        '
        Me.lblGenerateID.BackColor = System.Drawing.Color.Gainsboro
        Me.lblGenerateID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblGenerateID.Location = New System.Drawing.Point(171, 19)
        Me.lblGenerateID.Name = "lblGenerateID"
        Me.lblGenerateID.Size = New System.Drawing.Size(100, 23)
        Me.lblGenerateID.TabIndex = 46
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Location = New System.Drawing.Point(12, 411)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(32, 13)
        Me.lblEmail.TabIndex = 43
        Me.lblEmail.Text = "Email"
        '
        'lblMobileNumber
        '
        Me.lblMobileNumber.AutoSize = True
        Me.lblMobileNumber.Location = New System.Drawing.Point(12, 374)
        Me.lblMobileNumber.Name = "lblMobileNumber"
        Me.lblMobileNumber.Size = New System.Drawing.Size(78, 13)
        Me.lblMobileNumber.TabIndex = 42
        Me.lblMobileNumber.Text = "Mobile Number"
        '
        'lblTeleNumber
        '
        Me.lblTeleNumber.AutoSize = True
        Me.lblTeleNumber.Location = New System.Drawing.Point(12, 331)
        Me.lblTeleNumber.Name = "lblTeleNumber"
        Me.lblTeleNumber.Size = New System.Drawing.Size(98, 13)
        Me.lblTeleNumber.TabIndex = 41
        Me.lblTeleNumber.Text = "Telephone Number"
        '
        'lblPostCode
        '
        Me.lblPostCode.AutoSize = True
        Me.lblPostCode.Location = New System.Drawing.Point(12, 261)
        Me.lblPostCode.Name = "lblPostCode"
        Me.lblPostCode.Size = New System.Drawing.Size(56, 13)
        Me.lblPostCode.TabIndex = 40
        Me.lblPostCode.Text = "Post Code"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(12, 214)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(45, 13)
        Me.lblAddress.TabIndex = 39
        Me.lblAddress.Text = "Address"
        '
        'lblDateOfBirth
        '
        Me.lblDateOfBirth.AutoSize = True
        Me.lblDateOfBirth.Location = New System.Drawing.Point(12, 122)
        Me.lblDateOfBirth.Name = "lblDateOfBirth"
        Me.lblDateOfBirth.Size = New System.Drawing.Size(66, 13)
        Me.lblDateOfBirth.TabIndex = 37
        Me.lblDateOfBirth.Text = "Date of Birth"
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.Location = New System.Drawing.Point(12, 85)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(58, 13)
        Me.lblLastName.TabIndex = 36
        Me.lblLastName.Text = "Last Name"
        '
        'lblFirstName
        '
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.Location = New System.Drawing.Point(11, 54)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(57, 13)
        Me.lblFirstName.TabIndex = 35
        Me.lblFirstName.Text = "First Name"
        '
        'lblStudentID
        '
        Me.lblStudentID.AutoSize = True
        Me.lblStudentID.Location = New System.Drawing.Point(12, 20)
        Me.lblStudentID.Name = "lblStudentID"
        Me.lblStudentID.Size = New System.Drawing.Size(58, 13)
        Me.lblStudentID.TabIndex = 34
        Me.lblStudentID.Text = "Student ID"
        '
        'txtEmail
        '
        Me.txtEmail.BackColor = System.Drawing.Color.Gainsboro
        Me.txtEmail.Location = New System.Drawing.Point(171, 408)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(100, 20)
        Me.txtEmail.TabIndex = 33
        '
        'txtMobileNumber
        '
        Me.txtMobileNumber.BackColor = System.Drawing.Color.Gainsboro
        Me.txtMobileNumber.Location = New System.Drawing.Point(171, 371)
        Me.txtMobileNumber.Name = "txtMobileNumber"
        Me.txtMobileNumber.Size = New System.Drawing.Size(100, 20)
        Me.txtMobileNumber.TabIndex = 32
        '
        'txtTeleNumber
        '
        Me.txtTeleNumber.BackColor = System.Drawing.Color.Gainsboro
        Me.txtTeleNumber.Location = New System.Drawing.Point(171, 328)
        Me.txtTeleNumber.Name = "txtTeleNumber"
        Me.txtTeleNumber.Size = New System.Drawing.Size(100, 20)
        Me.txtTeleNumber.TabIndex = 31
        '
        'txtPostCode
        '
        Me.txtPostCode.BackColor = System.Drawing.Color.Gainsboro
        Me.txtPostCode.Location = New System.Drawing.Point(171, 254)
        Me.txtPostCode.Name = "txtPostCode"
        Me.txtPostCode.Size = New System.Drawing.Size(100, 20)
        Me.txtPostCode.TabIndex = 30
        '
        'txtAddress
        '
        Me.txtAddress.BackColor = System.Drawing.Color.Gainsboro
        Me.txtAddress.Location = New System.Drawing.Point(171, 211)
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(100, 20)
        Me.txtAddress.TabIndex = 29
        '
        'txtDateOfBirth
        '
        Me.txtDateOfBirth.BackColor = System.Drawing.Color.Gainsboro
        Me.txtDateOfBirth.Location = New System.Drawing.Point(171, 119)
        Me.txtDateOfBirth.Name = "txtDateOfBirth"
        Me.txtDateOfBirth.Size = New System.Drawing.Size(100, 20)
        Me.txtDateOfBirth.TabIndex = 28
        '
        'txtLastName
        '
        Me.txtLastName.BackColor = System.Drawing.Color.Gainsboro
        Me.txtLastName.Location = New System.Drawing.Point(171, 82)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(100, 20)
        Me.txtLastName.TabIndex = 27
        '
        'txtFirstName
        '
        Me.txtFirstName.BackColor = System.Drawing.Color.Gainsboro
        Me.txtFirstName.Location = New System.Drawing.Point(171, 51)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(100, 20)
        Me.txtFirstName.TabIndex = 26
        '
        'btnUpdate
        '
        Me.btnUpdate.BackColor = System.Drawing.Color.Red
        Me.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnUpdate.Location = New System.Drawing.Point(15, 444)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(113, 56)
        Me.btnUpdate.TabIndex = 25
        Me.btnUpdate.Text = "Update Student"
        Me.btnUpdate.UseVisualStyleBackColor = False
        '
        'btnDelete
        '
        Me.btnDelete.BackColor = System.Drawing.Color.Black
        Me.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnDelete.ForeColor = System.Drawing.Color.White
        Me.btnDelete.Location = New System.Drawing.Point(171, 444)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(113, 56)
        Me.btnDelete.TabIndex = 47
        Me.btnDelete.Text = "Delete Student"
        Me.btnDelete.UseVisualStyleBackColor = False
        '
        'frmUpdateStudents
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(323, 551)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.lblGenerateID)
        Me.Controls.Add(Me.lblEmail)
        Me.Controls.Add(Me.lblMobileNumber)
        Me.Controls.Add(Me.lblTeleNumber)
        Me.Controls.Add(Me.lblPostCode)
        Me.Controls.Add(Me.lblAddress)
        Me.Controls.Add(Me.lblDateOfBirth)
        Me.Controls.Add(Me.lblLastName)
        Me.Controls.Add(Me.lblFirstName)
        Me.Controls.Add(Me.lblStudentID)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.txtMobileNumber)
        Me.Controls.Add(Me.txtTeleNumber)
        Me.Controls.Add(Me.txtPostCode)
        Me.Controls.Add(Me.txtAddress)
        Me.Controls.Add(Me.txtDateOfBirth)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.btnUpdate)
        Me.Name = "frmUpdateStudents"
        Me.Text = "Update Students"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblGenerateID As System.Windows.Forms.Label
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents lblMobileNumber As System.Windows.Forms.Label
    Friend WithEvents lblTeleNumber As System.Windows.Forms.Label
    Friend WithEvents lblPostCode As System.Windows.Forms.Label
    Friend WithEvents lblAddress As System.Windows.Forms.Label
    Friend WithEvents lblDateOfBirth As System.Windows.Forms.Label
    Friend WithEvents lblLastName As System.Windows.Forms.Label
    Friend WithEvents lblFirstName As System.Windows.Forms.Label
    Friend WithEvents lblStudentID As System.Windows.Forms.Label
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents txtMobileNumber As System.Windows.Forms.TextBox
    Friend WithEvents txtTeleNumber As System.Windows.Forms.TextBox
    Friend WithEvents txtPostCode As System.Windows.Forms.TextBox
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtDateOfBirth As System.Windows.Forms.TextBox
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents btnDelete As System.Windows.Forms.Button
End Class

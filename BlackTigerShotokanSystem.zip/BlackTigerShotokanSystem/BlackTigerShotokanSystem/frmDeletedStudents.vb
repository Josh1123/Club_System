﻿Public Class frmDeletedStudents
    Dim StudentRecordPosition As Integer
    Private Sub frmDeletedStudents_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim StudentRecord As StudentType                                    'Declares a varaible to store my student record structure
        Dim RecordPosition As Integer                                       'Declares a varaiable to help me calculate and use the position a record can be found in
        RecordPosition = 0                                                  'Sets record position as 0
        FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord)) 'Opens student file
        Do While Not EOF(1)                                                 'Loops until end of student file
            RecordPosition = RecordPosition + 1                             'Adds one to record position
            FileGet(1, StudentRecord, RecordPosition)                       'Reads student record from student file at record position
            If StudentRecord.Deleted = True Then                            'If the field deleted is true
                cmbDeletedStudents.Items.Add(StudentRecord.StudentID)       'Adds student rceord to list box
            End If
        Loop                                                                'End loop
        FileClose(1)                                                        'Closes student file

        txtFirstName.Enabled = False                                        'Disables first name entry
        txtLastName.Enabled = False                                         'Disables last name entry
    End Sub

    Private Sub cmbDeletedStudents_SelectedValueChanged(sender As Object, e As EventArgs) Handles cmbDeletedStudents.SelectedValueChanged
        Dim StudentRecord As StudentType                                    'Declares a varaible to store my student record structure
        Dim RecordPosition As Integer                                       'Declares a varaiable to help me calculate and use the position a record can be found in
        StudentRecordPosition = 0                                           'Sets the global varaible of student record psoition as 0
        RecordPosition = 0                                                  'Sets record position as 0

        FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord)) 'Opens student file
        Do While Not EOF(1)                                                 'Loops through
            RecordPosition = RecordPosition + 1                             'Adds one to record position
            FileGet(1, StudentRecord, RecordPosition)                       'Reads student record from student file at rceord position
            If cmbDeletedStudents.SelectedItem.Contains(StudentRecord.StudentID) = True Then    'If Id from combo box matches student ID from record
                StudentRecordPosition = RecordPosition                      'Global varaible student record position = record position
                With StudentRecord                                          'Saves having ti type studentrecord.etc
                    txtFirstName.Text = .FirstName                          'Displays details from student record at record position
                    txtLastName.Text = .LastName                            'Displays details from student record at record position
                    txtDateOfBirth.Text = .DateOfBirth                      'Displays details from student record at record position
                    txtAddress.Text = .Address                              'Displays details from student record at record position
                    txtPostCode.Text = .PostCode                            'Displays details from student record at record position
                    txtTeleNumber.Text = .HomeNumber                        'Displays details from student record at record position
                    txtMobileNumber.Text = .MobileNumber                    'Displays details from student record at record position
                    txtEmail.Text = .Email                                  'Displays details from student record at record position
                End With
            End If
        Loop
        FileClose(1)                                                        'Closes Student File
    End Sub


    Private Sub btnReAddStudent_Click(sender As Object, e As EventArgs) Handles btnReAddStudent.Click
        Dim StudentRecord As StudentType                                    'Declares a varaible to store my student record structure
        Dim RecordPosition As Integer                                       'Declares a varaiable to help me calculate and use the position a record can be found in
        Dim StudentFound As Boolean                                         'Declares a variable to say when a student has been found in the student file
        RecordPosition = 0                                                  'Sets record psotion as 0
        StudentFound = False                                                'Sets found as false

        FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord)) 'Opens student file
        Do While Not EOF(1) And Not StudentFound                            'Loops until end of student file or student found
            RecordPosition = RecordPosition + 1                             'Adds one to record position
            FileGet(1, StudentRecord, RecordPosition)                       'Gets student record from student file at record position
            If StudentRecord.StudentID = cmbDeletedStudents.SelectedItem Then   'If student Id from student record matches student id in combo box
                StudentFound = True                                         'Student has been found
            End If
        Loop                                                                'End loop
        If StudentFound Then                                                'If student has been found
            With StudentRecord                                              'Saves having to type student record.etc
                .FirstName = txtFirstName.Text                              'Stores the deatails in the text box to the student record
                .LastName = txtLastName.Text                                'Stores the deatails in the text box to the student record
                .DateOfBirth = txtDateOfBirth.Text                          'Stores the deatails in the text box to the student record
                .Address = txtAddress.Text                                  'Stores the deatails in the text box to the student record
                .PostCode = txtPostCode.Text                                'Stores the deatails in the text box to the student record
                .HomeNumber = txtTeleNumber.Text                            'Stores the deatails in the text box to the student record
                .MobileNumber = txtMobileNumber.Text                        'Stores the deatails in the text box to the student record
                .Email = txtEmail.Text                                      'Stores the deatails in the text box to the student record
                .Deleted = False                                            'Sets the field deleted to false and stores the field in student record
            End With
            FilePut(1, StudentRecord, RecordPosition)                       'Writes student record to student file at record position
            MsgBox("Student Record has been Re-Added")                      'Dispalys a message saying taht the rceord has been re-added to the file
        End If
        FileClose(1)                                                        'Closes student file
        cmbDeletedStudents.SelectedItem = ""                                'Clears form
        txtAddress.Text = ""                                                'Clears form
        txtDateOfBirth.Text = ""                                            'Clears form
        txtEmail.Text = ""                                                  'Clears form
        txtFirstName.Text = ""                                              'Clears form
        txtLastName.Text = ""                                               'Clears form
        txtMobileNumber.Text = ""                                           'Clears form
        txtPostCode.Text = ""                                               'Clears form
        txtTeleNumber.Text = ""                                             'Clears form
    End Sub

    Private Sub btnPerDelete_Click(sender As Object, e As EventArgs) Handles btnPerDelete.Click
        Dim StudentRecord As StudentType                                    'Declares a varaible to store my student record structure
        Dim OldRecordNumber As Integer                                      'Declares a variable to store the record position of the record that needs to be deleted
        Dim TempRecordNumber As Integer                                     'Declares a variable to store the record position for the records to be saved to to prevent them being deleted
        OldRecordNumber = 1                                                 'Sets old record position as 1
        TempRecordNumber = 1                                                'Sets Temp record position as 1
        FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord)) 'Opens student file
        FileOpen(2, "TempFile.dat", OpenMode.Random, , , Len(StudentRecord)) 'Opens a temporary file to store all the record atht are not being deleted
        Do While Not EOF(1)                                                 'Loops until teh end of the student file
            FileGet(1, StudentRecord)                                       'Reads from student file
            If OldRecordNumber <> StudentRecordPosition Then                'If old record number does not matches global variable student record position
                FilePut(2, StudentRecord, TempRecordNumber)                 'Writes record to temporary file at temp record position
                TempRecordNumber = TempRecordNumber + 1                     'Adds 1 to temp record position
            End If
            OldRecordNumber = OldRecordNumber + 1                           'Adds 1 to old record position
        Loop                                                                'Ends loop
        FileClose(1)                                                        'Closes student file        
        FileClose(2)                                                        'Closes temporary file
        Kill("Student.dat")                                                 'Deletes student file
        Rename("TempFile.dat", "Student.dat")                               'Renames temp file to student file
        MsgBox("The Student Record has Been Deleted")                       'Displays message saying that the student has been deleted
        Me.Close()                                                          'Closes the form
    End Sub
End Class
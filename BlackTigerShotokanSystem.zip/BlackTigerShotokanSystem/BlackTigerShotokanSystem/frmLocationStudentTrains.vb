﻿Public Class frmLocationStudentTrains

    Private Sub frmLocationStudentTrains_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim LocationRecord As LocationType                              'Declares a variable to save and store the record structure for my Locations
        Dim RecordPosition As Integer                                   'Declares a variable to calculate and save the record position of my locations
        Dim SelectInd As Integer                                        'Declares a varaible to help find the selected index where an item can be found
        Dim LocationFound As Boolean                                    'Declares a varaible to see if a location has been found or not
        SelectInd = 0                                                   'Sets SelectInd as 0
        RecordPosition = 0                                              'Sets record position as 0

        FileOpen(4, "Location.dat", OpenMode.Random, , , Len(LocationRecord))   'Opens location file
        Do While Not EOF(4)                                             'Repeats until end of location file
            RecordPosition = RecordPosition + 1                         'Adds 1 to record position
            FileGet(4, LocationRecord, RecordPosition)                  'Gets loaction record from location file at record position
            cmbFindLocation.Items.Add(LocationRecord.LocationID)        'Adds Location ID form location record to combo box
        Loop                                                            'Ends loop
        RecordPosition = 0                                              'Sets rceord position to 0
        FileClose(4)                                                    'Closes location file
        FileOpen(4, "Location.dat", OpenMode.Random, , , Len(LocationRecord))   'Opens location file
        Do While Not EOF(4)                                             'Repaets until the end of loaction file
            If frmLocationAttendance.lstListLocation.SelectedItem.Contains(cmbFindLocation.Items.Item(SelectInd)) Then      'If selected item from location attendance form contains item from combo box at selected index
                Do While Not LocationFound                              'Repeat until location found
                    RecordPosition = RecordPosition + 1                 'Adds 1 to record position
                    FileGet(4, LocationRecord, RecordPosition)          'Reads location record from location file at record position
                    If frmLocationAttendance.lstListLocation.SelectedItem.Contains(LocationRecord.LocationID) Then  'If Selected item from location attendance form matches conatins location ID from location record
                        cmbFindLocation.Items.Clear()                   'Clears combo Box
                        cmbFindLocation.Items.Add(LocationRecord.LocationID)    'Adds location Id from location record to combo box
                        cmbFindLocation.SelectedIndex = 0               'Shows item in combo box at selected index 0
                        LocationFound = True                            'Sets location found as true
                    End If
                Loop                                                    'Ends loop
            End If
            SelectInd = SelectInd + 1                                   'Adds 1 to SelectInd
        Loop                                                            'Ends loop
        FileClose(4)                                                    'Closes Location File
    End Sub

    Private Sub cmbFindLocation_SelectedValueChanged(sender As Object, e As EventArgs) Handles cmbFindLocation.SelectedValueChanged
        Dim StudentRecord As StudentType                    'Declares a variable to store the record structure for my students
        Dim RecordPosition As Integer                       'Declares a variable to store and calculate my student record position
        Dim AttendanceRecord As AttendanceType              'Declares a variable to store the record structure for my Attendances
        Dim LessonRecord As LessonType                      'Declares a variable to store the record structure for my Lessons 
        Dim TempAttendanceRecord As StudentType             'Declares a variable to store the recrd structure to help me create a register of students
        Dim AttendaceRecordPosition As Integer              'Declares a variable to store and calculate my Attendance record position
        Dim TempRecordPosition As Integer              'Declares a variable to store and calculate my Attendance record position
        Dim LessonFound As Boolean                          'Declares a variable to check to see if the lessons at that location has been found
        Dim LessonRecordPosition As Integer                 'Declares a variable to store and calculate my lesson record position
        Dim LastAttendancePosition As Integer
        Dim ColsFormat As String = "{0,-15} {1,-20} {2,-30} {3,-30} {4,-25} {5,-20} {6,-20} " 'Declares a varable to store the lcation of my headings to be displayed
        FileClose(6)
        FileClose(8)
        TempRecordPosition = 1
        AttendaceRecordPosition = 0                         'Sets attendance record position as 0
        LessonFound = False                                 'Sets Lessonfound as false
        RecordPosition = 0                                  'Sets record poition to 0
        LessonRecordPosition = 0                            'Sets lesson record position as 0

        lstListStudents.Items.Clear()                       'Clears the list box
        lstListStudents.Items.Add(String.Format(ColsFormat, "Student ID", "First Name", "Last Name", "Address", "Post Code", "Home Number", "Mobile Number"))     'Adds headings to list box
        FileOpen(6, "Lesson.dat", OpenMode.Random, , , Len(LessonRecord))       'Opens Lesson File
        FileOpen(7, "Attendance.dat", OpenMode.Random, , , Len(AttendanceRecord))   'Opens Attendance file
        FileOpen(8, "TempAttendance.dat", OpenMode.Random, , , Len(TempAttendanceRecord))   'Opens Temporary Attendance file
        FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord))  'Opens Student File
        Do While Not EOF(1)                                 'Repeats until the end of the student file
            RecordPosition = RecordPosition + 1             'Adds 1 to record position
            FileGet(1, StudentRecord, RecordPosition)       'Reads student record from student file at record position
            Do While Not EOF(7)                             'Repeats until end of Attendance
                AttendaceRecordPosition = AttendaceRecordPosition + 1   'Adds 1 to Attendance record position
                FileGet(7, AttendanceRecord, AttendaceRecordPosition)       'Reads attendance record from attendace fle at attendance rceord position
                If AttendanceRecord.StudentId = StudentRecord.StudentID Then            'If Student id from attendance rceord matches Student Id from Student Record
                    Do While Not EOF(6) And Not LessonFound                             'Repeats until end of lesson file and lesson not found
                        LessonRecordPosition = LessonRecordPosition + 1                 'Adds 1 to Lesson record position
                        FileGet(6, LessonRecord, LessonRecordPosition)                  'Reads lesson record from lesson file at lesson record position
                        If LessonRecord.LocationID = cmbFindLocation.SelectedItem() Then    'If LocationId from leson record matches Loation ID from combo box
                            LessonFound = True              'Sets lesson found as true
                        End If
                    Loop                                    'Ends loop
                    If AttendanceRecord.StudentId = StudentRecord.StudentID And AttendanceRecord.Session = LessonRecord.Session1 Or AttendanceRecord.StudentId = StudentRecord.StudentID And AttendanceRecord.Session = LessonRecord.Session2 Then 'If student Ids match and Sessions match
                        TempAttendanceRecord.StudentID = StudentRecord.StudentID    'Sets Temp Attendance Record Student ID as Student ID from Student file
                        FilePut(8, TempAttendanceRecord, TempRecordPosition)        'Writes Temp Attendace Record to Temp Attendance File at Temp Record position
                        TempRecordPosition = TempRecordPosition + 1                 'Adds 1 to Temp Attendance Record
                    End If
                End If

            Loop
            FileClose(8)
            FileOpen(8, "TempAttendance.dat", OpenMode.Random, , , Len(TempAttendanceRecord))   'Opens Temporary Attendance file
            FileClose(7)                                                                'Closes Attendance file
            FileOpen(7, "Attendance.dat", OpenMode.Random, , , Len(AttendanceRecord))   'Opens Attendance file
            AttendaceRecordPosition = 0   'Adds 1 to Attendance record position
            If TempRecordPosition > 1 Then                                  'If Temp Record position greater then 1
                LastAttendancePosition = LOF(8) / Len(TempAttendanceRecord) 'Finds the last record in the temp Attendance file
                FileGet(8, TempAttendanceRecord, LastAttendancePosition)    'Reads Temp Attendance Record from Temp Attendance file at Temp Attendance position
                If TempAttendanceRecord.StudentID = StudentRecord.StudentID Then    'If Student ID from Temp record matches Temp Student record
                    With StudentRecord                                      'Saves having to type StudentRecord.etc
                        lstListStudents.Items.Add(String.Format(ColsFormat, .StudentID, .FirstName, .LastName, .Address, .PostCode, .HomeNumber, .MobileNumber)) 'Adds record to list box
                    End With
                End If


                TempRecordPosition = 1  'Sets Temp Attendance Record as 1
                FileClose(8)            'Closes TempAttendance file
                Kill("TempAttendance.dat")  'Deletes Temp Attendance file
                FileOpen(8, "TempAttendance.dat", OpenMode.Random, , , Len(TempAttendanceRecord))   'Opens Temporary Attendance file
            End If
        Loop
        FileClose(1)        'Closes Student File
        FileClose(2)        'Closes Licence File
        FileClose(7)        'Closes Attendance file
        FileClose(8)        'Closes Temp Attendance file
        FileClose(6)        'Closes lesson file

    End Sub

    
    Private Sub txtFindStudentID_TextChanged(sender As Object, e As EventArgs) Handles txtFindStudentID.TextChanged
        Dim StudentRecord As StudentType                    'Declares a variable to store the record structure for my students
        Dim RecordPosition As Integer                       'Declares a variable to store and calculate my student record position
        Dim AttendanceRecord As AttendanceType              'Declares a variable to store the record structure for my Attendances
        Dim LessonRecord As LessonType                      'Declares a variable to store the record structure for my Lessons 
        Dim TempAttendanceRecord As StudentType             'Declares a variable to store the recrd structure to help me create a register of students
        Dim AttendaceRecordPosition As Integer              'Declares a variable to store and calculate my Attendance record position
        Dim TempRecordPosition As Integer              'Declares a variable to store and calculate my Attendance record position
        Dim LessonFound As Boolean                          'Declares a variable to check to see if the lessons at that location has been found
        Dim LessonRecordPosition As Integer                 'Declares a variable to store and calculate my lesson record position
        Dim LastAttendancePosition As Integer
        Dim ColsFormat As String = "{0,-15} {1,-20} {2,-30} {3,-30} {4,-25} {5,-20} {6,-20} " 'Declares a varable to store the lcation of my headings to be displayed
        FileClose(6)
        FileClose(8)
        TempRecordPosition = 1
        AttendaceRecordPosition = 0                         'Sets attendance record position as 0
        LessonFound = False                                 'Sets Lessonfound as false
        RecordPosition = 0                                  'Sets record poition to 0
        LessonRecordPosition = 0                            'Sets lesson record position as 0

        lstListStudents.Items.Clear()                       'Clears the list box
        lstListStudents.Items.Add(String.Format(ColsFormat, "Student ID", "First Name", "Last Name", "Address", "Post Code", "Home Number", "Mobile Number"))     'Adds headings to list box
        FileOpen(6, "Lesson.dat", OpenMode.Random, , , Len(LessonRecord))       'Opens Lesson File
        FileOpen(7, "Attendance.dat", OpenMode.Random, , , Len(AttendanceRecord))   'Opens Attendance file
        FileOpen(8, "TempAttendance.dat", OpenMode.Random, , , Len(TempAttendanceRecord))   'Opens Temporary Attendance file
        FileOpen(1, "Student.dat", OpenMode.Random, , , Len(StudentRecord))  'Opens Student File
        Do While Not EOF(1)                                 'Repeats until the end of the student file
            RecordPosition = RecordPosition + 1             'Adds 1 to record position
            FileGet(1, StudentRecord, RecordPosition)       'Reads student record from student file at record position
            Do While Not EOF(7)                             'Repeats until end of Attendance
                AttendaceRecordPosition = AttendaceRecordPosition + 1   'Adds 1 to Attendance record position
                FileGet(7, AttendanceRecord, AttendaceRecordPosition)       'Reads attendance record from attendace fle at attendance rceord position
                If AttendanceRecord.StudentId = StudentRecord.StudentID Then            'If Student id from attendance rceord matches Student Id from Student Record
                    Do While Not EOF(6) And Not LessonFound                             'Repeats until end of lesson file and lesson not found
                        LessonRecordPosition = LessonRecordPosition + 1                 'Adds 1 to Lesson record position
                        FileGet(6, LessonRecord, LessonRecordPosition)                  'Reads lesson record from lesson file at lesson record position
                        If LessonRecord.LocationID = cmbFindLocation.SelectedItem() Then    'If LocationId from leson record matches Loation ID from combo box
                            LessonFound = True              'Sets lesson found as true
                        End If
                    Loop                                    'Ends loop
                    If AttendanceRecord.StudentId = StudentRecord.StudentID And AttendanceRecord.Session = LessonRecord.Session1 Or AttendanceRecord.StudentId = StudentRecord.StudentID And AttendanceRecord.Session = LessonRecord.Session2 Then 'If student Ids match and Sessions match
                        TempAttendanceRecord.StudentID = StudentRecord.StudentID    'Sets Temp Attendance Record Student ID as Student ID from Student file
                        FilePut(8, TempAttendanceRecord, TempRecordPosition)        'Writes Temp Attendace Record to Temp Attendance File at Temp Record position
                        TempRecordPosition = TempRecordPosition + 1                 'Adds 1 to Temp Attendance Record
                    End If
                End If

            Loop
            FileClose(8)
            FileOpen(8, "TempAttendance.dat", OpenMode.Random, , , Len(TempAttendanceRecord))   'Opens Temporary Attendance file
            FileClose(7)                                                                'Closes Attendance file
            FileOpen(7, "Attendance.dat", OpenMode.Random, , , Len(AttendanceRecord))   'Opens Attendance file
            AttendaceRecordPosition = 0   'Adds 1 to Attendance record position
            If TempRecordPosition > 1 Then                                  'If Temp Record position greater then 1
                LastAttendancePosition = LOF(8) / Len(TempAttendanceRecord) 'Finds the last record in the temp Attendance file
                FileGet(8, TempAttendanceRecord, LastAttendancePosition)    'Reads Temp Attendance Record from Temp Attendance file at Temp Attendance position
                If TempAttendanceRecord.StudentID = StudentRecord.StudentID Then    'If Student ID from Temp record matches Temp Student record
                    If StudentRecord.StudentID.Contains(txtFindStudentID.Text) Then  'If Student record contains user entry
                        With StudentRecord                                      'Saves having to type StudentRecord.etc
                            lstListStudents.Items.Add(String.Format(ColsFormat, .StudentID, .FirstName, .LastName, .Address, .PostCode, .HomeNumber, .MobileNumber)) 'Adds record to list box
                        End With
                    End If
                End If

                TempRecordPosition = 1  'Sets Temp Attendance Record as 1
                FileClose(8)            'Closes TempAttendance file
                Kill("TempAttendance.dat")  'Deletes Temp Attendance file
                FileOpen(8, "TempAttendance.dat", OpenMode.Random, , , Len(TempAttendanceRecord))   'Opens Temporary Attendance file
            End If
        Loop
        FileClose(1)        'Closes Student File
        FileClose(2)        'Closes Licence File
        FileClose(7)        'Closes Attendance file
        FileClose(8)        'Closes Temp Attendance file
        FileClose(6)        'Closes lesson file

    End Sub
    Private Sub lstListStudents_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstListStudents.SelectedIndexChanged
        frmStudentAttendance.Show()                             'Displays Student Attendance form
    End Sub
End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmListLicence
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstListLicences = New System.Windows.Forms.ListBox()
        Me.lblFilterByLicenceID = New System.Windows.Forms.Label()
        Me.txtFilterByLicenceID = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lstListLicences
        '
        Me.lstListLicences.BackColor = System.Drawing.Color.Gainsboro
        Me.lstListLicences.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstListLicences.FormattingEnabled = True
        Me.lstListLicences.ItemHeight = 14
        Me.lstListLicences.Location = New System.Drawing.Point(12, 12)
        Me.lstListLicences.Name = "lstListLicences"
        Me.lstListLicences.Size = New System.Drawing.Size(943, 298)
        Me.lstListLicences.TabIndex = 0
        '
        'lblFilterByLicenceID
        '
        Me.lblFilterByLicenceID.AutoSize = True
        Me.lblFilterByLicenceID.Location = New System.Drawing.Point(12, 334)
        Me.lblFilterByLicenceID.Name = "lblFilterByLicenceID"
        Me.lblFilterByLicenceID.Size = New System.Drawing.Size(59, 13)
        Me.lblFilterByLicenceID.TabIndex = 1
        Me.lblFilterByLicenceID.Text = "Licence ID"
        '
        'txtFilterByLicenceID
        '
        Me.txtFilterByLicenceID.BackColor = System.Drawing.Color.Gainsboro
        Me.txtFilterByLicenceID.Location = New System.Drawing.Point(112, 331)
        Me.txtFilterByLicenceID.Name = "txtFilterByLicenceID"
        Me.txtFilterByLicenceID.Size = New System.Drawing.Size(100, 20)
        Me.txtFilterByLicenceID.TabIndex = 2
        '
        'frmListLicence
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(976, 390)
        Me.Controls.Add(Me.txtFilterByLicenceID)
        Me.Controls.Add(Me.lblFilterByLicenceID)
        Me.Controls.Add(Me.lstListLicences)
        Me.Name = "frmListLicence"
        Me.Text = "List Licence "
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lstListLicences As System.Windows.Forms.ListBox
    Friend WithEvents lblFilterByLicenceID As System.Windows.Forms.Label
    Friend WithEvents txtFilterByLicenceID As System.Windows.Forms.TextBox
End Class

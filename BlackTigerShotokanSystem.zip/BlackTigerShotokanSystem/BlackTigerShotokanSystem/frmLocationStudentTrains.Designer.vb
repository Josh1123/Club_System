﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLocationStudentTrains
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmbFindLocation = New System.Windows.Forms.ComboBox()
        Me.grpPickLocation = New System.Windows.Forms.GroupBox()
        Me.lblFindLocation = New System.Windows.Forms.Label()
        Me.lstListStudents = New System.Windows.Forms.ListBox()
        Me.lblStudentID = New System.Windows.Forms.Label()
        Me.txtFindStudentID = New System.Windows.Forms.TextBox()
        Me.grpPickLocation.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmbFindLocation
        '
        Me.cmbFindLocation.BackColor = System.Drawing.Color.Gainsboro
        Me.cmbFindLocation.FormattingEnabled = True
        Me.cmbFindLocation.Location = New System.Drawing.Point(153, 23)
        Me.cmbFindLocation.Name = "cmbFindLocation"
        Me.cmbFindLocation.Size = New System.Drawing.Size(121, 21)
        Me.cmbFindLocation.TabIndex = 0
        '
        'grpPickLocation
        '
        Me.grpPickLocation.BackColor = System.Drawing.Color.White
        Me.grpPickLocation.Controls.Add(Me.lblFindLocation)
        Me.grpPickLocation.Controls.Add(Me.cmbFindLocation)
        Me.grpPickLocation.Location = New System.Drawing.Point(12, 12)
        Me.grpPickLocation.Name = "grpPickLocation"
        Me.grpPickLocation.Size = New System.Drawing.Size(280, 64)
        Me.grpPickLocation.TabIndex = 1
        Me.grpPickLocation.TabStop = False
        Me.grpPickLocation.Text = "Pick Location"
        '
        'lblFindLocation
        '
        Me.lblFindLocation.AutoSize = True
        Me.lblFindLocation.Location = New System.Drawing.Point(6, 26)
        Me.lblFindLocation.Name = "lblFindLocation"
        Me.lblFindLocation.Size = New System.Drawing.Size(104, 13)
        Me.lblFindLocation.TabIndex = 1
        Me.lblFindLocation.Text = "Pick Location Via ID"
        '
        'lstListStudents
        '
        Me.lstListStudents.BackColor = System.Drawing.Color.Gainsboro
        Me.lstListStudents.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstListStudents.FormattingEnabled = True
        Me.lstListStudents.ItemHeight = 14
        Me.lstListStudents.Location = New System.Drawing.Point(21, 99)
        Me.lstListStudents.Name = "lstListStudents"
        Me.lstListStudents.Size = New System.Drawing.Size(1130, 172)
        Me.lstListStudents.TabIndex = 2
        '
        'lblStudentID
        '
        Me.lblStudentID.AutoSize = True
        Me.lblStudentID.Location = New System.Drawing.Point(18, 303)
        Me.lblStudentID.Name = "lblStudentID"
        Me.lblStudentID.Size = New System.Drawing.Size(58, 13)
        Me.lblStudentID.TabIndex = 3
        Me.lblStudentID.Text = "Student ID"
        '
        'txtFindStudentID
        '
        Me.txtFindStudentID.BackColor = System.Drawing.Color.Gainsboro
        Me.txtFindStudentID.Location = New System.Drawing.Point(131, 300)
        Me.txtFindStudentID.Name = "txtFindStudentID"
        Me.txtFindStudentID.Size = New System.Drawing.Size(100, 20)
        Me.txtFindStudentID.TabIndex = 4
        '
        'frmLocationStudentTrains
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1183, 350)
        Me.Controls.Add(Me.txtFindStudentID)
        Me.Controls.Add(Me.lblStudentID)
        Me.Controls.Add(Me.lstListStudents)
        Me.Controls.Add(Me.grpPickLocation)
        Me.Name = "frmLocationStudentTrains"
        Me.Text = "frmLocationStudentTrains"
        Me.grpPickLocation.ResumeLayout(False)
        Me.grpPickLocation.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmbFindLocation As System.Windows.Forms.ComboBox
    Friend WithEvents grpPickLocation As System.Windows.Forms.GroupBox
    Friend WithEvents lblFindLocation As System.Windows.Forms.Label
    Friend WithEvents lstListStudents As System.Windows.Forms.ListBox
    Friend WithEvents lblStudentID As System.Windows.Forms.Label
    Friend WithEvents txtFindStudentID As System.Windows.Forms.TextBox
End Class

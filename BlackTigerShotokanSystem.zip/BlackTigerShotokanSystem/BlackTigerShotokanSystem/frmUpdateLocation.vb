﻿Public Class frmUpdateLocation
    Dim LocationRecordPosition As Integer               'Declares a global variable to stopre the location of the selected location

    Private Sub frmUpdateLocation_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim LocationRecord As LocationType              'Declares a variable to save the record structure of my locations
        Dim RecordPosition As Integer                   'Declares a variable to calculate and store the location of the record is to be found
        RecordPosition = 0                              'Sets rceord position as 0

        FileOpen(4, "Location.dat", OpenMode.Random, , , Len(LocationRecord))       'Opens Location file
        Do While Not EOF(4)                             'Repaets until end of location file
            RecordPosition = RecordPosition + 1         'Adds 1 to Record position
            FileGet(4, LocationRecord, RecordPosition)  'Reads location record from location file at rceord position
            cmbLocationID.Items.Add(LocationRecord.LocationID)  'Populates combo box with location Id from location Record
        Loop
        FileClose(4)
    End Sub

    Private Sub btnUpdateLocation_Click(sender As Object, e As EventArgs) Handles btnUpdateLocation.Click
        Dim LocationRecord As LocationType              'Declares a variable to save the record structure of my locations
        Dim RecordPosition As Integer                   'Declares a variable to calculate and store the location of the record is to be found
        Dim Valid As Boolean                            'Declares a variable to help validate user entry
        RecordPosition = 0                              'Sets rceord position as 0
        Valid = True                                    'Sets valid as true

        If Len(txtLocationName.Text) > 30 Then                                  'Validates user Entry
            Valid = False                                                       'Sets Valid as False
            MsgBox("Location Name must be 30 characters or less in length")     'Disaplys the correct error message
        ElseIf txtLocationAddress.Text = "" Then                                'Validates user Entry
            Valid = False                                                       'Sets Valid as False
            MsgBox("Address Must be Present")                                   'Disaplys the correct error message
        ElseIf IsNumeric(Mid(txtLocationPostCode.Text, 1, 2)) = True Then       'Validates user Entry
            Valid = False                                                       'Sets Valid as False
            MsgBox("Post Code must have the first two letters as letters")      'Disaplys the correct error message
        ElseIf IsNumeric(Mid(txtLocationPostCode.Text, 3, 2)) = False Then      'Validates user Entry
            Valid = False                                                       'Sets Valid as False
            MsgBox("The 3rd and 4th charaters in the Post Code must be Numbers")    'Disaplys the correct error message
        ElseIf IsNumeric(Mid(txtLocationPostCode.Text, 5, 2)) = True Then       'Validates user Entry
            Valid = False                                                       'Sets Valid as False
            MsgBox("The Last 2 Characters of the Post Code must be Letters")    'Disaplys the correct error message
        End If

        If Valid Then                                                           'If user entry passes validation
            FileOpen(4, "Location.dat", OpenMode.Random, , , Len(LocationRecord))   'Opens location file
            Do While Not EOF(4)                                                 'Repeats until end of location file
                RecordPosition = RecordPosition + 1                             'Adds 1 to record position
                FileGet(4, LocationRecord, RecordPosition)                      'Gets location Record from Location File at rceord position
                With LocationRecord                                             'Saves having to type LocationRecord.etc
                    If cmbLocationID.SelectedItem = .LocationID Then            'If ID in combo box matches ID from location record
                        .Name = txtLocationName.Text                            'Adds deatils from form to location record
                        .Address = txtLocationAddress.Text                      'Adds deatils from form to location record
                        .PostCode = txtLocationPostCode.Text                    'Adds deatils from form to location record
                        MsgBox("Location has been Updated")                                 'Displays message saying the record has been updated
                        FilePut(4, LocationRecord, RecordPosition)                          'Writes location record to location file at record position
                    End If
                End With
            Loop

        End If
        FileClose(4)                                                            'Closes location file
    End Sub

    Private Sub cmbLocationID_SelectedValueChanged(sender As Object, e As EventArgs) Handles cmbLocationID.SelectedValueChanged
        Dim LocationRecord As LocationType              'Declares a variable to save the record structure of my locations
        Dim RecordPosition As Integer                   'Declares a variable to calculate and store the location of the record is to be found
        Dim LocationFound As Boolean                    'Declares a variable to see if the correct location has been found

        LocationFound = False                           'Sets location found as false
        RecordPosition = 0                              'Sets Record position as 0
        LocationRecordPosition = 0                      'Sets global variable location record position as 0

        FileOpen(4, "Location.dat", OpenMode.Random, , , Len(LocationRecord))   'Opens Location file
        Do While Not EOF(4) And Not LocationFound                          'Repeats until end of location file
            RecordPosition = RecordPosition + 1         'Adds 1 to rceord position
            FileGet(4, LocationRecord, RecordPosition)  'Reads location record from locatino file at record position
            With LocationRecord                         'Saves having to type LocationRecord.etc
                If cmbLocationID.SelectedItem = .LocationID Then    'If Location ID from combo box matches Location Id from Record
                    LocationFound = True                'Sets Location found as true
                End If
            End With
        Loop
        If LocationFound Then
            txtLocationAddress.Text = LocationRecord.Address.Trim         'Displays Details from location record
            txtLocationName.Text = LocationRecord.Name.Trim               'Displays Details from location record
            txtLocationPostCode.Text = LocationRecord.PostCode.Trim       'Displays Details from location record
            LocationRecordPosition = RecordPosition                       'Sets the loal varaible to the location of the selected location position in file
        End If
        FileClose(4)                                    'Closes Location file
    End Sub

    Private Sub btnEditLesson_Click(sender As Object, e As EventArgs) Handles btnEditLesson.Click
        frmUpdateLesson.Show()                          'Displays Update lesson form
    End Sub

    Private Sub btnDeleteLocation_Click(sender As Object, e As EventArgs) Handles btnDeleteLocation.Click
        Dim LocationRecord As LocationType                                  'Declares a variable to store the record data structure of my locations
        Dim OldRecordNumber As Integer                                      'Declares a variable to store the record position of the record that needs to be deleted
        Dim TempRecordNumber As Integer                                     'Declares a variable to store the record position for the records to be saved to to prevent them being deleted
        OldRecordNumber = 1                                                 'Sets Old record position as 1
        TempRecordNumber = 1                                                'Sets Temp record position as 1
        FileOpen(4, "Location.dat", OpenMode.Random, , , Len(LocationRecord))   'Opens location file
        FileOpen(5, "TempLocation.dat", OpenMode.Random, , , Len(LocationRecord))   'Opens Temp Location File
        Do While Not EOF(4)                                                 'Loops until the end of the Location file
            FileGet(4, LocationRecord)                                       'Reads from Location file
            If OldRecordNumber <> LocationRecordPosition Then               'If Old record Number does not = Location Record position
                FilePut(5, LocationRecord, TempRecordNumber)                'Writes location record to temp Location file at temp record position
                TempRecordNumber = TempRecordNumber + 1                     'Adds 1 to temp record position
            End If
            OldRecordNumber = OldRecordNumber + 1                           'Adds 1 to Old rceord position
        Loop                                                                'Ends loop
        FileClose(4)                                                        'Closes Location file
        FileClose(5)                                                        'Closes TempLocationfile
        Kill("Location.dat")                                                'Deletes Location File
        Rename("TempLocation.dat", "Location.dat")                          'Renames Temp Location file to Location file
        MsgBox("Location Has been removed from the system")                 'Displays a message saying the location has been removed from the system
        Me.Close()                                                          'Closes the form
    End Sub
End Class
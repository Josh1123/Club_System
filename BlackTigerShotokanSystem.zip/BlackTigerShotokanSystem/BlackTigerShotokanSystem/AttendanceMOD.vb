﻿Module AttendanceMOD
    Public Structure AttendanceType
        <VBFixedString(6)> Dim StudentId As String          'All the variables are self documenting so each store the data contains to its name
        <VBFixedString(9)> Dim Session As String
        Dim DateAttended As Date
    End Structure
    Public Function ValidateAttendance(ByVal StudID As ComboBox, ByRef DateOfSes As TextBox) As Boolean 'Declares a public function to help validate my attendance
        Dim Valid As Boolean                            'Declares a variable to help determind whether the user entry is valid
        Valid = True                                    'Sets Valids as false
        If StudID.SelectedItem() = "" Then              'If student ID user entry is blank
            Valid = False                               'Sets Valid as false
            MsgBox("Student ID Must be Present")        'Displays error message
        ElseIf DateOfSes.Text = "" Then                 'Displays error message
            Valid = False                               'Sets Valid as false
            MsgBox("Date Must be present")              'Displays error message
        End If
        Return Valid                                    'Returns valid to main program
    End Function
End Module
